SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [OPGC].[USP_Delete_Forecast_InvestmentDetails_DetailedView] --'',58,173,174,1,393
(
	 @userAlias NVARCHAR(250)
	,@fundId INT
	,@scenarioId INT
	,@investmentid INT
	,@investmentcashflowtypeid  INT
	,@InvestmentCashflowId INT
)

As
BEGIN

--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

BEGIN TRY

declare @InitialInvesmentCheck int = ( select COUNT(1) from [OPGC].[OpgcInvestmentCashFlow] where InvestmenCashflowId = @InvestmentCashflowId and InvestmentCashflowTypeId = @investmentcashflowtypeid  and Isdeleted = 0 )


DECLARE @ErrorText NVARCHAR(MAX) =''
 
 If @InitialInvesmentCheck >= 1
begin
SET @ErrorText = 'Initial Invesment Cannot be deleted'
RAISERROR (@ErrorText, 16, 1)
end
else
begin

update [OPGC].[OpgcInvestmentCashFlow]

set  isdeleted=1
    ,modifiedby = @userAlias
    ,modifiedon =getdate()
where FundId = @fundId and  ScenarioId = @scenarioId AND InvestmentId = @investmentid AND InvestmentCashflowTypeId = @investmentcashflowtypeid AND InvestmenCashflowId =@InvestmentCashflowId and Isdeleted = 0




declare @CheckInvestmentID int = ( select COUNT(1) from [OPGC].[OpgcInvestmentCashFlow] where FundId = @fundId and ScenarioId = @scenarioId and InvestmentId = @investmentid and Isdeleted = 0 )

if @CheckInvestmentID = 0

begin

  insert into [OPGC].[opgcInvestmentCashFlow]
  (
   FundId
  ,ScenarioId
  ,InvestmentCashflowTypeId
  ,InvestmentId
  ,Equity
  ,EventDate
  ,Isdeleted
  ,CreatedBy
  ,CreatedOn
  )
  select
   @fundId
  ,@scenarioId
  ,100
  ,@investmentID
  ,0
  ,GETDATE()
  ,0
  ,@userAlias
  ,GETDATE()


end     
end
----else 

----begin

--update [OPGC].[OpgcInvestmentCashFlow]

--set  isdeleted=1
--    ,modifiedby = @userAlias
--    ,modifiedon =getdate()
--where FundId = @fundId and  ScenarioId = @scenarioId AND InvestmentId = @investmentid AND InvestmentCashflowTypeId = @investmentcashflowtypeid AND InvestmenCashflowId =@InvestmentCashflowId

----end

	 
END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END         
END CATCH
END
