select distinct DB_NAME() AS DBName, schema_name(v.schema_id) as ViewSchemaName,
v.name as ViewName,
schema_name(o.schema_id) as ObjSchemaName,
o.name as ObjName,
o.type_desc as ObjType
from sys.views v WITH (NOLOCK)
join sys.sql_expression_dependencies d WITH (NOLOCK)
on d.referencing_id = v.object_id
and d.referenced_id is not null
join sys.objects o WITH (NOLOCK)
on o.object_id = d.referenced_id
order by ViewSchemaName,ViewName