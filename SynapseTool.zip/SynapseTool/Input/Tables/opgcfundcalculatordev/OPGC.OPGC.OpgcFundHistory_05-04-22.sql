SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OPGC.OpgcFundHistory_05-04-22](
	[FundId] [int] NOT NULL,
	[FundName​] [nvarchar](100) NOT NULL,
	[TotalInvestment​] [decimal](18, 2) NULL,
	[TotalRealized​] [decimal](18, 2) NULL,
	[TotalUnrealized​] [decimal](18, 2) NULL,
	[Description​] [nvarchar](500) NULL,
	[ExpenseCap​] [decimal](18, 2) NULL,
	[ManualStepdownDate​] [datetime] NULL,
	[LimitedPartnerPercent​] [decimal](18, 2) NULL,
	[ManagementFeePercent​] [decimal](18, 2) NULL,
	[CreatedBy​] [nvarchar](50) NOT NULL,
	[CreatedOn​] [datetime] NOT NULL,
	[ModifiedBy​] [nvarchar](50) NULL,
	[ModifiedOn​] [datetime] NULL,
	[ValidFrom] [datetime2](0) NOT NULL,
	[ValidTo] [datetime2](0) NOT NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)

