SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

Create PROCEDURE [OPGC].[USP_Update_Forecast_InvestmentDetails_DetailedView_V8] --'' ,3,8,2,2,'2021-12-20','Actual','',20000,'InVestment 2',23
(
	 @userAlias NVARCHAR(250)
	,@fundId INT
	,@scenarioId INT
	,@investmentID INT--
	,@investmentCashFlowTypeId INT
	,@date DATE
	,@status NVARCHAR(20)
	,@tag NVARCHAR(250)
	,@amount DECIMAL(18,2)
	,@investmentName  Nvarchar(250)
	,@InvestmentCashflowId INT
	,@recallableUntil DATE,
	 @recallBool BIT
	
)

As

BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

BEGIN TRY

declare @ErrorText Nvarchar(250) = ' '

--declare @CheckInvestmentName Nvarchar(250) = (select count(1) from [OPGC].[OpgcInvestment] A inner join [OPGC].[OpgcInvestmentCashFlow] B
--                                               on  A.InvestmentId = B.InvestmentId where A.InvestmentName = @investmentName and  B.FundId=@fundId 
--											     and B.ScenarioId=@scenarioId and B.InvestmentId=@investmentID and b.InvestmentCashflowTypeId =@investmentCashFlowTypeId
--												 AND B.InvestmenCashflowId =@InvestmentcashflowId)

Update  B
set 
    B.InvestmentName = @investmentName
   ,B.ModifiedBy = @userAlias
   ,B.ModifiedOn = getdate()
   from 
   [OPGC].[OpgcInvestmentCashFlow]  A
   Inner join [OPGC].[OpgcInvestment] B
   on A.InvestmentId = B.InvestmentId
   where  B.InvestmentId = @investmentID and B.Isdeleted = 0

--------------------------------------------------------------------------------------------------------------------------------------------------------------------

declare @Mindate date = (select min(Eventdate) from [OPGC].[OpgcInvestmentCashFlow] where FundId =3 and ScenarioId = 17 and InvestmentId = 5 and InvestmentCashFlowTypeId in ( 1,2,4,6))


if @investmentCashFlowTypeId in (1,2,4,6) 
begin
UPDATE [OPGC].[OpgcInvestmentCashFlow] 
SET EventDate =@date,
InvestmentCashflowTypeId=@investmentCashFlowTypeId
    ,Equity=@amount
   ,IsActual = CASE WHEN @status = 'Actual' THEN 1 ELSE 0 END 
   ,IsHypothetical = CASE WHEN @status = 'Actual' THEN 0 ELSE 1 END 
   ,Tag = @tag
   ,RecallableUntil =@recallableUntil
   ,IsRecallable=@recallBool
   ,ModifiedBy=@userAlias
   ,ModifiedOn=getdate()
    where FundId=@fundId and ScenarioId=@scenarioId and InvestmentId=@investmentID and InvestmenCashflowId =@InvestmentCashflowId and Isdeleted = 0 --and InvestmentCashflowTypeId=@investmentCashFlowTypeId 
end

else if @investmentCashFlowTypeId in (3,5,7) and @Mindate <= @date
begin
UPDATE [OPGC].[OpgcInvestmentCashFlow] 
SET EventDate =@date,
InvestmentCashflowTypeId=@investmentCashFlowTypeId
    ,Equity=@amount
   ,IsActual = CASE WHEN @status = 'Actual' THEN 1 ELSE 0 END 
   ,IsHypothetical = CASE WHEN @status = 'Actual' THEN 0 ELSE 1 END 
   ,Tag = @tag
   ,RecallableUntil =@recallableUntil
   ,IsRecallable=@recallBool
   ,ModifiedBy=@userAlias
   ,ModifiedOn=getdate()
    where FundId=@fundId and ScenarioId=@scenarioId and InvestmentId=@investmentID and InvestmenCashflowId =@InvestmentCashflowId and Isdeleted = 0 --and InvestmentCashflowTypeId=@investmentCashFlowTypeId 
end

else if @investmentCashFlowTypeId in (3,5,7) and @Mindate > @date
begin
SET @ErrorText = 'Date is less than Initial Invesment please Change Date'
RAISERROR (@ErrorText, 16, 1)
end 


	


---------------------------------------------------------------------------------

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	    IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END               
END CATCH
END




