SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcInvestmentCashFlowType](
	[InvestmentCashFlowTypeId] [int] IDENTITY(1,1) NOT NULL,
	[InvestmentCashFlowType] [nvarchar](100) NULL,
	[Isdeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[InvestmentCashFlowTypeId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcInvestmentCashFlowType] ADD  DEFAULT ((0)) FOR [Isdeleted]
