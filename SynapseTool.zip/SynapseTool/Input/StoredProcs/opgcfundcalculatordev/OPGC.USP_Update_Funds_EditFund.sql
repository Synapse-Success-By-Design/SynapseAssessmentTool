SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Update_Funds_EditFund]   --'admin','Axis Regular Saver Fund',1234567890,123456780,12345678,'wfrg3g','2022-04-20',null,1,2,3,4,'2022-04-20',43
(   

    @FundName​                       NVARCHAR(100),
    @CommittedCapital               DECIMAL(30,2),
    @OffsetsByQuarter               DECIMAL(30,2),
    @OtherPartnershipFeesByQuarter  DECIMAL(30,2),
    @Description​                    NVARCHAR(500),
    @FundInceptionDate              DATETIME,
    @ManualStepdownDate​             DATETIME,
	@LPPreferredReturnPercent       DECIMAL(5,2),
	@LPFinalSharePercent            DECIMAL(5,2),
	@GPPreferredReturnPercent       DECIMAL(5,2),
    @ManagementFeePercent​           DECIMAL(30,2),
	@UserAlias				        NVARCHAR(250),
	@FundId				            INT

    -- @TotalInvestment​       DECIMAL(30,2)  ,
    --@TotalRealized​          DECIMAL(30,2),    
    --@TotalUnrealized​        DECIMAL(30,2),
	-- @ExpenseCap​             DECIMAL(30,2),
	--@LimitedPartnerPercent​  DECIMAL(30,2),

)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Fund Details

Uses   
      [OPGC].[USP_Select_Funds_GetFundsListing]	    SP

Populates
      [OPGC].[Fund]			Table

**************************************************************************/
BEGIN TRY
 
Declare @FundNameCount int = (select count (1) from [OPGC].[OpgcFund] where  [FundName​] = @FundName )
Declare @ErrorText Nvarchar(MAx)
DECLARE @CurrentFundName NVARCHAR(MAX) = (Select [FundName​] from [opgc].[opgcfund] where FundId= @fundid)




If @FundNameCount > 0 and @CurrentFundName ! = @FundName
Begin

SET @ErrorText = 'Fund Name Already Exists'
RAISERROR (@ErrorText, 16, 1)

End

Else

Begin

   UPDATE  [OPGC].[OpgcFund]
   SET [FundName​]                       =   @FundName​
      ,[CommittedCapital]               =   @CommittedCapital             
      ,[OffsetsByQuarter]               =	@OffsetsByQuarter             
      ,[OtherPartnershipFeesByQuarter]	=	@OtherPartnershipFeesByQuarter     
	  ,[Description​]                    =   @Description​          ​   
	  ,[FundInceptionDate]              =   @FundInceptionDate
	  ,[ManualStepdownDate​]             =   @ManualStepdownDate​   ​
	  ,[LPPreferredReturnPercent]       =   @LPPreferredReturnPercent
	  ,[LPFinalSharePercent]	        =	@LPFinalSharePercent     
	  ,[GPPreferredReturnPercent]       =	@GPPreferredReturnPercent
	  ,[ManagementFeePercent​]           =   @ManagementFeePercent​ 
	  ,[ModifiedBy​]                     =   @userAlias
	  ,[ModifiedOn​]                     =   GETDATE()

   --   ,[TotalInvestment​]              =   @TotalInvestment​      
	  --,[TotalRealized​]                =   @TotalRealized​        
	  --,[TotalUnrealized​]              =   @TotalUnrealized​ 
	  --,[ExpenseCap​]                   =   @ExpenseCap
	  --,[LimitedPartnerPercent​]        =   @LimitedPartnerPercent
	  WHERE [FundId]=@FundId
End  						     
END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	    IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END          
END CATCH
END


