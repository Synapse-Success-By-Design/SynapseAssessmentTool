SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcFundCashFlow](
	[FundCashflowId] [int] IDENTITY(1,1) NOT NULL,
	[FundId] [int] NULL,
	[ScenarioId] [int] NULL,
	[FundCashflowTypeId] [int] NULL,
	[EventDate] [datetime] NOT NULL,
	[ValueAmount] [decimal](30, 2) NULL,
	[IsActual] [bit] NULL,
	[IsHypothetical] [bit] NULL,
	[Tag] [nvarchar](250) NULL,
	[Isdeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
	[ValidFrom] [datetime2](0) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](0) GENERATED ALWAYS AS ROW END NOT NULL,
	[LimitedPartnerPercent] [decimal](5, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[FundCashflowId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcFundCashFlow] ADD  DEFAULT ((0)) FOR [Isdeleted]
ALTER TABLE [OPGC].[OpgcFundCashFlow] ADD  CONSTRAINT [df_OpgcFundCashFlow_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
ALTER TABLE [OPGC].[OpgcFundCashFlow] ADD  CONSTRAINT [DF_ValidFrom_FundCashFlow1]  DEFAULT (dateadd(second,(-1),sysutcdatetime())) FOR [ValidFrom]
ALTER TABLE [OPGC].[OpgcFundCashFlow] ADD  CONSTRAINT [DF_ValidTo_FundCashFlow1]  DEFAULT ('9999.12.31 23:59:59.99') FOR [ValidTo]
ALTER TABLE [OPGC].[OpgcFundCashFlow]  WITH CHECK ADD FOREIGN KEY([FundCashflowTypeId])
REFERENCES [OPGC].[OpgcFundCashFlowType] ([FundCashFlowTypeId])
ALTER TABLE [OPGC].[OpgcFundCashFlow]  WITH CHECK ADD FOREIGN KEY([FundId])
REFERENCES [OPGC].[OpgcFund] ([FundId])
ALTER TABLE [OPGC].[OpgcFundCashFlow]  WITH CHECK ADD FOREIGN KEY([ScenarioId])
REFERENCES [OPGC].[OpgcScenario] ([ScenarioId])
