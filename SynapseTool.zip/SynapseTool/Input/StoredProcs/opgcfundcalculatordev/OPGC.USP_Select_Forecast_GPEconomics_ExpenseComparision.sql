SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_GPEconomics_ExpenseComparision] --'',7,31
(
	 @userAlias NVARCHAR(100)
    ,@FundId  INT
    ,@ScenarioId INT = NULL
	,@ActiveScenarioId int 
    --,@IndustryId INT = NULL,
    -- @CountryId  INT = NULL 
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Appointment Details


Uses   
      [USP_Select_Appointment_GetAppointmentDetails]	    SP

Populates
      [WWMG].[ConfirmedScheduleDetails]			Table
	  [WWMG].[LocationDetails]					Table
	  [WWMG].[UserFamilyDetails]				Table
	  [WWMG].[FamilyDetails_Relations]			Table
**************************************************************************/
BEGIN TRY

DECLARE @BaseLineScenarioID INT --= (SELECT ScenarioId FROM [OPGC].[OpgcScenario] WHERE FundID =@FundId AND IsBaseline=1  and Isdeleted = 0)
set @BaseLineScenarioID = @ActiveScenarioId

If coalesce ( @ScenarioId,'') = ''
begin

;with BaselineAmount as
(
SELECT FundId,ScenarioId ,sum (ValueAmount) as ExpenseAmount ,MAX(eventdate) AS EventDate,DATEPART(YYYY,EventDate) AS EventDateYear,
DATEPART(MM,EventDate) AS EventDateMonth,
FORMAT(EventDate, 'MMM') +' '+ CAST(RIGHT(Datepart(YY,EventDate),2) AS NVARCHAR(5)) AS TransactionMonth

FROM [OPGC].[OpgcFundCashFlow]  

WHERE FundId=@FundId AND ScenarioId=@BaseLineScenarioID and FundCashflowTypeId in (3,5)  and Isdeleted = 0
and cast(EventDate as date) between  CAST (DATEADD(YYYY,-1,GETDATE()) AS DATE) and cast (getdate() as date) 

group by FundId , ScenarioId , FundCashFlowTypeId,DATEPART(YYYY,EventDate) 
,DATEPART(MM,EventDate),FORMAT(EventDate, 'MMM') +' '+ CAST(RIGHT(Datepart(YY,EventDate),2) AS NVARCHAR(5)) 

)


,BaselineTotalAmount as (
select FundId , ScenarioId AS BaseleineScenarioId , 
SUM (ExpenseAmount)  AS BaseLineExpenseAmount 
,TransactionMonth
from BaselineAmount
group by FundId , ScenarioId,DATEPART(MM,EventDate) ,EventDate,TransactionMonth
order by EventDate
OFFSET 0 ROWS
)


select  A.FundId ,A.BaseleineScenarioId 
,CAST (0 AS INT) AS CompareScenarioId 
, A.BaseLineExpenseAmount 
,CAST (0 AS decimal(18,2)) AS CompareExpenseAmount,a.TransactionMonth
from BaselineTotalAmount A


END

ELSE 
BEGIN

;with BaselineAmount as
(
SELECT FundId,ScenarioId ,sum (ValueAmount) as ExpenseAmount ,MAX(eventdate) AS EventDate,DATEPART(YYYY,EventDate) AS EventDateYear,
DATEPART(MM,EventDate) AS EventDateMonth,
FORMAT(EventDate, 'MMM') +' '+ CAST(RIGHT(Datepart(YY,EventDate),2) AS NVARCHAR(5)) AS TransactionMonth

FROM [OPGC].[OpgcFundCashFlow]  

WHERE FundId=@FundId AND ScenarioId=@BaseLineScenarioID and FundCashflowTypeId in (3,5)  and Isdeleted = 0
and cast(EventDate as date) between  CAST (DATEADD(YYYY,-1,GETDATE()) AS DATE) and cast (getdate() as date) 

group by FundId , ScenarioId , FundCashFlowTypeId,DATEPART(YYYY,EventDate) 
,DATEPART(MM,EventDate),FORMAT(EventDate, 'MMM') +' '+ CAST(RIGHT(Datepart(YY,EventDate),2) AS NVARCHAR(5)) 

)


,BaselineTotalAmount as (
select FundId , ScenarioId AS BaseleineScenarioId , 
SUM (ExpenseAmount)  AS BaseLineExpenseAmount 
,TransactionMonth
from BaselineAmount
group by FundId , ScenarioId,DATEPART(MM,EventDate) ,EventDate,TransactionMonth
order by EventDate
OFFSET 0 ROWS
)



--select * from BaselineTotalAmount

----------------------------------------COMPARE NET MOIC -----------------------------------------------------------------

, CompareAmount as
(
SELECT FundId,ScenarioId ,sum (ValueAmount) as ExpenseAmount ,MAX(eventdate) AS EventDate,DATEPART(YYYY,EventDate) AS EventDateYear,
DATEPART(MM,EventDate) AS EventDateMonth,
FORMAT(EventDate, 'MMM') +' '+ CAST(RIGHT(Datepart(YY,EventDate),2) AS NVARCHAR(5)) AS TransactionMonth

FROM [OPGC].[OpgcFundCashFlow]  
WHERE FundId=@FundId AND ScenarioId=@ScenarioId and FundCashflowTypeId in (3,5)  and Isdeleted = 0
and cast(EventDate as date) between  CAST (DATEADD(YYYY,-1,GETDATE()) AS DATE) and cast (getdate() as date) 
group by FundId , ScenarioId , FundCashFlowTypeId,DATEPART(YYYY,EventDate) 
,DATEPART(MM,EventDate),FORMAT(EventDate, 'MMM') +' '+ CAST(RIGHT(Datepart(YY,EventDate),2) AS NVARCHAR(5)) 
)

, CompareTotalAmount as (
select FundId , ScenarioId AS CompareScenarioId , 
SUM (ExpenseAmount)  AS CompareExpenseAmount 
,TransactionMonth
from CompareAmount
group by FundId , ScenarioId,DATEPART(MM,EventDate) ,EventDate,TransactionMonth
order by EventDate
OFFSET 0 ROWS
)

,Final_CTE AS
(
SELECT FUNDID , BaseleineScenarioId AS ScenarioId,BaseLineExpenseAmount AS ExpenseAmount, TransactionMonth,1 AS IsBaseLine
from BaselineTotalAmount
UNION ALL
SELECT FUNDID , CompareScenarioId AS ScenarioId,CompareExpenseAmount AS ExpenseAmount, TransactionMonth, 0 AS IsBaseLine
from CompareTotalAmount
)

,CTE AS
(
SELECT @FundId AS FundId , @BaseLineScenarioID AS BaseLineScenarioId , @ScenarioId  AS CompareScenarioId ,TransactionMonth,
CASE WHEN IsBaseLine = 1 THEN SUM (ExpenseAmount) ELSE 0 END AS BaseLineExpenseAmount,
CASE WHEN IsBaseLine = 0 THEN SUM (ExpenseAmount) ELSE 0 END AS CompareExpenseAmount

FROM Final_CTE
GROUP BY TransactionMonth , IsBaseLine
)

SELECT FundId AS FundId  ,BaseLineScenarioId AS BaseleineScenarioId ,CompareScenarioId AS CompareScenarioId ,TransactionMonth AS TransactionMonth, max(BaseLineExpenseAmount) AS BaseLineExpenseAmount, max(CompareExpenseAmount) AS CompareExpenseAmount
FROM CTE
GROUP BY FundId ,BaseLineScenarioId,CompareScenarioId,TransactionMonth
ORDER BY RIGHT(TransactionMonth,2 ),Month(cast(LEFT (TransactionMonth,3) +'1 2020' as datetime))


--select  A.FundId ,A.BaseleineScenarioId , B.CompareScenarioId , A.BaseLineExpenseAmount , ISNULL(B.CompareExpenseAmount,0) AS CompareExpenseAmount
--,a.TransactionMonth
--from BaselineTotalAmount A
--left join CompareTotalAmount B 
--on A.FundId = B.FundId AND A.TransactionMonth=B.TransactionMonth
--INNER JOIN [OPGC].[OpgcFund] C
--ON A.FundId = C.FundId AND B.FundId = C.FundId 

END

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


