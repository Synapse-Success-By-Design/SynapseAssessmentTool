SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcUserRolePermissionRights](
	[OpgcUserRoleId] [int] NULL,
	[OpgcFeatureId] [int] NULL,
	[CanAccess] [bit] NULL,
	[CreatedBy] [nvarchar](250) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcUserRolePermissionRights] ADD  CONSTRAINT [df_OpgcUserRolePermissionRights_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
ALTER TABLE [OPGC].[OpgcUserRolePermissionRights]  WITH CHECK ADD FOREIGN KEY([OpgcFeatureId])
REFERENCES [OPGC].[OpgcFeature] ([OpgcFeatureId])
ALTER TABLE [OPGC].[OpgcUserRolePermissionRights]  WITH CHECK ADD FOREIGN KEY([OpgcUserRoleId])
REFERENCES [OPGC].[OpgcUserRole] ([OpgcUserRoleId])
