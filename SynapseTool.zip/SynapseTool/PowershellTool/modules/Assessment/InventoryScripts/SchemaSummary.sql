;WITH CountsByObjType as (
select schema_id,
(SUM(CASE WHEN type_desc='USER_TABLE' THEN 1 ELSE 0 END)) AS TablesCount,
SUM(CASE WHEN type_desc='External_Table'  THEN 1 ELSE 0 END) AS ExternalTablesCount,
SUM(CASE WHEN type_desc='INTERNAL_TABLE'THEN 1 ELSE 0 END) AS InternalTablesCount,
SUM(CASE WHEN type_desc='VIEW'   THEN 1 ELSE 0 END) AS ViewsCount,
SUM(CASE WHEN type_desc='SQL_STORED_PROCEDURE'  THEN 1 ELSE 0 END) AS StoredProceduresCount,
SUM(CASE WHEN type_desc='SQL_SCALAR_FUNCTION'  THEN 1 ELSE 0 END) AS ScalarFunctionsCount,
SUM(CASE WHEN type_desc='SQL_INLINE_TABLE_VALUED_FUNCTION'   THEN 1 ELSE 0 END) AS InlineTableFunctionsCount,
SUM(CASE WHEN type_desc='sql_trigger'  THEN 1 ELSE 0 END) AS TriggersCount
FROM sys.objects WITH(NOLOCK)
Group by schema_id
),
SchemaRowCounts as (
SELECT so.schema_id,
(SUM(p.rows)) as [RowCount]
FROM sys.objects so WITH(NOLOCK)
JOIN sys.partitions p WITH(NOLOCK)
ON so.object_id = p.object_id
Group By so.schema_id
)
SELECT 
DB_NAME() AS DBName,
SCHEMA_NAME(SO.schema_id) AS [Schema],
cast(((sum(a.in_row_data_page_count + a.lob_used_page_count + a.row_overflow_used_page_count)*8)*1.0/1024)/1024 as decimal (10,4)) as SizeInGB,
MAX(src.[RowCount]) as [RowCount],
MAX(oc.TablesCount) as [#Tables],
MAX(oc.ExternalTablesCount) as [#ExternalTables],
MAX(oc.InternalTablesCount) as [#InternalTables],
MAX(oc.ViewsCount) as [#Views],
MAX(oc.StoredProceduresCount) as [#StoredProcedures],
MAX(oc.ScalarFunctionsCount) as [#ScalarFunctions],
MAX(oc.InlineTableFunctionsCount) as [#InlineTableFunctions],
MAX(oc.TriggersCount) as [#Triggers],
'' AS [#TableIncompabilities],
'' AS [#ViewIncompabilities],
'' AS [#StoredProcIncompabilities],
'' AS [#TriggerIncompabilities],
'' AS [#OtherIncompabilities]
FROM  sys.objects SO WITH(NOLOCK)
LEFT JOIN CountsByObjType oc WITH(NOLOCK)
ON oc.schema_id=SO.schema_id
LEFT JOIN SchemaRowCounts src WITH(NOLOCK)	
ON src.schema_id=SO.schema_id
left join sys.partitions p WITH(NOLOCK)
ON p.object_id = SO.object_id
LEFT JOIN sys.dm_db_partition_stats a WITH(NOLOCK)
ON p.partition_id = a.partition_id
where (a.index_id is null or a.index_id < 2)
GROUP BY SO.schema_id
order by [RowCount] desc