SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcScenario_History](
	[ScenarioId] [int] NOT NULL,
	[ScenarioName] [nvarchar](150) NULL,
	[FundID] [int] NULL,
	[ScenarioDescription] [nvarchar](50) NULL,
	[IsBaseline] [bit] NULL,
	[CreatedBy] [nvarchar](50) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NULL,
	[Isdeleted] [bit] NULL,
	[SysStartTime] [datetime2](7) NOT NULL,
	[SysEndTime] [datetime2](7) NOT NULL,
	[CopiedFrom] [int] NULL,
	[CommittedCapital] [decimal](30, 2) NULL,
	[OffsetsByQuarter] [decimal](30, 2) NULL,
	[OtherPartnershipFeesByQuarter] [decimal](30, 2) NULL,
	[FundInceptionDate] [datetime] NULL,
	[ManualStepdownDate] [datetime] NULL,
	[LPPreferredReturnPercent] [decimal](5, 2) NULL,
	[LPFinalSharePercent] [decimal](5, 2) NULL,
	[GPPreferredReturnPercent] [decimal](5, 2) NULL,
	[ManagementFeePercent] [decimal](5, 2) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)

