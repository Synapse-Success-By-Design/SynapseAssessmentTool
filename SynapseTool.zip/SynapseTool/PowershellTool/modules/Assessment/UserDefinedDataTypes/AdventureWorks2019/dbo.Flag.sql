CREATE TYPE [dbo].[Flag] FROM [bit] NOT NULL
