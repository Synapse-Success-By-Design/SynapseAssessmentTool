# SynapseTool

Steps to run SynapseAssessmentTool 


1. Modify config.json file present under SynapseTool\PowerShellTool\modules\Assessment appropriately
2. Make sure "SkipExtraction" flag set to 0
3. Build the SQLExtractor and move files from \SQLObjectsExtractor\SQLObjectsExtractor\bin\Debug to \SynapseTool\SQLObjectsExtractor

Setting up:
    a. Open powershell as Administraotr mode and run the following commands:
    b. Install-Module -Name ImportExcel
    c. Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass, select Yes to All
    d. Install-Module -Name SqlServer -Scope CurrentUser

Running ps1 :
    Navigate to C:\SynapseTool\PowerShellTool\modules\Assessment and Run RunAssessment.ps1