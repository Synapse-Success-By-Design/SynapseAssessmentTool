SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [OPGC].[USP_Update_Forecast_InvestmentDetails_DetailedView] --'admin' ,58,173,74,7,'2022-04-25','Actual',null,3000.00,'BaseLine_5009',394,null,null,30
(
	 @userAlias NVARCHAR(250)
	,@fundId INT
	,@scenarioId INT
	,@investmentID INT--
	,@investmentCashFlowTypeId INT
	,@date DATE
	,@status NVARCHAR(20)
	,@tag NVARCHAR(250)
	,@amount DECIMAL(30,2)
	,@investmentName  Nvarchar(250)
	,@InvestmentCashflowId INT
	,@recallableUntil DATE
	,@recallBool BIT
	,@LimitedPartnerPercent DECIMAL (5,2)
)

As

BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

BEGIN TRY

declare @ErrorText Nvarchar(250) = ' '

--declare @CheckInvestmentName Nvarchar(250) = (select count(1) from [OPGC].[OpgcInvestment] A inner join [OPGC].[OpgcInvestmentCashFlow] B
--                                               on  A.InvestmentId = B.InvestmentId where A.InvestmentName = @investmentName and  B.FundId=@fundId 
--											     and B.ScenarioId=@scenarioId and B.InvestmentId=@investmentID and b.InvestmentCashflowTypeId =@investmentCashFlowTypeId
--												 AND B.InvestmenCashflowId =@InvestmentcashflowId)

Update  B
set 
    B.InvestmentName = @investmentName
   ,B.ModifiedBy = @userAlias
   ,B.ModifiedOn = getdate()
   from 
   [OPGC].[OpgcInvestmentCashFlow]  A
   Inner join [OPGC].[OpgcInvestment] B
   on A.InvestmentId = B.InvestmentId
   where  B.InvestmentId = @investmentID and B.Isdeleted = 0

--------------------------------------------------------------------------------------------------------------------------------------------------

declare @InitialInvesmentCheck int = (select COUNT(1) from [OPGC].[OpgcInvestmentCashFlow] where FundId =@fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID and InvestmentCashflowTypeId = 1 and Isdeleted = 0)
declare @FundMindate date = ( select FundInceptionDate from [OPGC].[OpgcScenario]  where FundId =@fundId and ScenarioId = @scenarioId)
--select @FundMindate as FundMindate
declare @Mindate date = (select min(Eventdate) from [OPGC].[OpgcInvestmentCashFlow] where FundId =@fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID and InvestmentCashFlowTypeId in ( 1) and Isdeleted = 0)
--select @Mindate as InvestMindate
declare @ExitCheck int = (select COUNT(1) from [OPGC].[OpgcInvestmentCashFlow] where FundId =@fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID and InvestmentCashflowTypeId = 3 and Isdeleted = 0)
declare @Exitdate date = (select Max(Eventdate) from [OPGC].[OpgcInvestmentCashFlow] where FundId =@fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID and InvestmentCashFlowTypeId in ( 3) and Isdeleted = 0)

declare @InvestmenCashflowIdCheck  int =  ( select InvestmenCashflowId from [OPGC].[OpgcInvestmentCashFlow] where FundId = @fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID 
                                              and InvestmentCashflowTypeId =1 and Isdeleted = 0 )

declare @ExitCashflowIdCheck  int =  ( select InvestmenCashflowId from [OPGC].[OpgcInvestmentCashFlow] where FundId = @fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID 
                                              and InvestmentCashflowTypeId =3 and Isdeleted = 0 )

declare @InitialdateCheck date = (select min(Eventdate) from [OPGC].[OpgcInvestmentCashFlow] where FundId =@fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID and InvestmentCashFlowTypeId not in ( 1 ,100)   and Isdeleted = 0)


if @InitialInvesmentCheck = 1 and @investmentCashFlowTypeId = 1 and @InvestmentCashflowId != @InvestmenCashflowIdCheck
begin
SET @ErrorText = 'Initial Invesment already exist'
RAISERROR (@ErrorText, 16, 1)
end 



else if @InitialInvesmentCheck = 1 and @investmentCashFlowTypeId in (2,3,4,5,6,7,8) and @InvestmentCashflowId = @InvestmenCashflowIdCheck
begin
SET @ErrorText = 'Initial Invesment cannot be change into other Invesment '
RAISERROR (@ErrorText, 16, 1)
end 

else if @InitialInvesmentCheck = 1 and @InitialdateCheck <= @date and @investmentCashFlowTypeId = 1 and @InvestmentCashflowId = @InvestmenCashflowIdCheck
begin
SET @ErrorText = 'Initial Investment Date cannot be greater than other CashFlow type '
RAISERROR (@ErrorText, 16, 1)
end 



else if @FundMindate > @date and @investmentCashFlowTypeId in (1,2,3,4,5,6,7,8)
begin
SET @ErrorText = 'Date is less than Fund Inception Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)
end 

else if   @FundMindate <= @date and @Mindate > @date   and @investmentCashFlowTypeId in (2,3,4,5,6,7,8)
begin
SET @ErrorText = 'Date is less than Initial Invesment Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)
end 

else if @ExitCheck = 1 and @investmentCashFlowTypeId = 3 and  @InvestmentCashflowId != @ExitCashflowIdCheck
begin
SET @ErrorText = 'Exit Invesment already exist'
RAISERROR (@ErrorText, 16, 1)
end 

--else if @ExitCheck = 1 and @investmentCashFlowTypeId in (1,2,4,5,6,7,8) and @InvestmentCashflowId = @ExitCashflowIdCheck
--begin
--SET @ErrorText = 'Exit Invesment cannot be change into other Invesment'
--RAISERROR (@ErrorText, 16, 1)
--end 



else if @Exitdate < @date and @investmentCashFlowTypeId in (1)
begin
SET @ErrorText = 'Date is greater than Exit Invesment Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)
end 

else
begin
--print 'true'

UPDATE [OPGC].[OpgcInvestmentCashFlow] 
SET EventDate =@date,
InvestmentCashflowTypeId=@investmentCashFlowTypeId
    ,Equity=@amount
   ,IsActual = CASE WHEN @status = 'Actual' THEN 1 ELSE 0 END 
   ,IsHypothetical = CASE WHEN @status = 'Actual' THEN 0 ELSE 1 END 
   ,LimitedPartnerPercent = @LimitedPartnerPercent
   ,Tag = @tag
   ,RecallableUntil =@recallableUntil
   ,IsRecallable=@recallBool
   ,ModifiedBy=@userAlias
   ,ModifiedOn=getdate()
    where FundId=@fundId and ScenarioId=@scenarioId and InvestmentId=@investmentID and InvestmenCashflowId =@InvestmentCashflowId and Isdeleted = 0 --and InvestmentCashflowTypeId=@investmentCashFlowTypeId 

end






	


---------------------------------------------------------------------------------

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	    IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END               
END CATCH
END




