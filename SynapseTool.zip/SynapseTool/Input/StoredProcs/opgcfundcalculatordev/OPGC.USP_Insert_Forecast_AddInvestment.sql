SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Insert_Forecast_AddInvestment]  --'System','Jupiter','',NULL,1001,1,4
(
	   @userAlias NVARCHAR(250)
	  ,@InvestmentName NVARCHAR(250)
	  ,@IndustryName Nvarchar(100)
	  ,@Address NVARCHAR(700)
	  ,@LocationId INT
	  ,@FundId INT 
	  ,@ScenarioId INT
	 	  
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 


BEGIN TRY
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DECLARE @ErrorText NVARCHAR(MAX) =''

DECLARE @IfInvestmentNameExist INT = (SELECT COUNT(*) FROM [OPGC].[OpgcInvestment] WHERE InvestmentName =@InvestmentName and Isdeleted=0)

declare @IndsutryIdExist int =  (select count([IndustryId​]) from [OPGC].[OpgcIndustry] where [IndustryName​] = case when @IndustryName is null then 'Not Available' else @IndustryName End and Isdeleted = 0 )




--declare @InvestmentFundCheck int = (select COUNT(1) FROM [OPGC].[OpgcInvestment] WHERE FundId = @FundId and  InvestmentName =@InvestmentName and Isdeleted=0 )

--If @IfInvestmentNameExist >=1 and @InvestmentFundCheck = 0

--begin
--SET @ErrorText = 'Investment already added to other Fund, Please Add New Investment'
--RAISERROR (@ErrorText, 16, 1)

--end


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


IF (@IfInvestmentNameExist >0)

BEGIN

Declare @InvestmentId int =  ( select InvestmentId from [OPGC].[OpgcInvestment] where FundID = @FundId and InvestmentName = @InvestmentName and Isdeleted = 0 )

Declare @ValidateEmptyRecord int = ( select count(InvestmentCashflowTypeId) from [OPGC].[opgcInvestmentCashFlow] where  FundId = @FundId and InvestmentCashflowTypeId in (100,1,2,3,4,5,6,7,8) 
                                      and InvestmentId = @InvestmentId and ScenarioId = @ScenarioId and Isdeleted=0 )

Declare @Getfundid int = ( select distinct FundId from [OPGC].[OpgcInvestment] where InvestmentName = @InvestmentName)

If @Getfundid != @FundId
begin
SET @ErrorText = 'Investment already added to other Fund , Please Add New Investment'
RAISERROR (@ErrorText, 16, 1)
end


If @ValidateEmptyRecord >= 1
begin

SET @ErrorText = 'Investment Name Already Exists'
RAISERROR (@ErrorText, 16, 1)

end






if @ValidateEmptyRecord = 0 
begin



insert into [OPGC].[opgcInvestmentCashFlow]
(
 FundId
,ScenarioId
,InvestmentCashflowTypeId
,InvestmentId
,Equity
,EventDate
,Isdeleted
,CreatedBy
,CreatedOn
)
select
 @FundId
,@ScenarioId
,100
,@InvestmentId
,0
,GETDATE()
,0
,@userAlias
,GETDATE()
end

--SET @ErrorText = 'Investment Name Already Exists'
--RAISERROR (@ErrorText, 16, 1)
END

ELSE


BEGIN



If @IndsutryIdExist = 0
begin

insert into [OPGC].[OpgcIndustry] ([IndustryName​],[CreatedBy​],[CreatedOn​])
select 
@IndustryName,
@userAlias,
getdate()

declare @IndsutryIdresult int = (select [IndustryId​] from [OPGC].[OpgcIndustry] where [IndustryName​] = @IndustryName and Isdeleted = 0)

INSERT INTO [OPGC].[OpgcInvestment]
(
 FundID
,InvestmentName
,[Address]
,IndustryId
,CountryId
,CreatedBy
,CreatedOn
)

select 
 @FundId
,@InvestmentName
,@Address
,@IndsutryIdresult
,case when @LocationId is null then 1001 else @LocationId end
,@userAlias
,GETDATE()

set @InvestmentId  =  ( select InvestmentId from [OPGC].[OpgcInvestment] where FundID = @FundId and InvestmentName = @InvestmentName and Isdeleted = 0 )


insert into [OPGC].[opgcInvestmentCashFlow]
(
 FundId
,ScenarioId
,InvestmentCashflowTypeId
,InvestmentId
,Equity
,EventDate
,Isdeleted
,CreatedBy
,CreatedOn
)
select
 @FundId
,@ScenarioId
,100
,@InvestmentId
,0
,GETDATE()
,0
,@userAlias
,GETDATE()



end

else
begin

declare @IndsutryIdresultExist int = (select [IndustryId​] from [OPGC].[OpgcIndustry]  where [IndustryName​] = case when @IndustryName is null then 'Not Available' else @IndustryName End and Isdeleted = 0)

INSERT INTO [OPGC].[OpgcInvestment]
(
 FundID
,InvestmentName
,[Address]
,IndustryId
,CountryId
,CreatedBy
,CreatedOn
)

select
 @FundId
,@InvestmentName
,@Address
,@IndsutryIdresultExist
,case when @LocationId is null then 1001 else @LocationId end
,@userAlias
,GETDATE()

declare @InvestmentId1 int

set @InvestmentId1  =  ( select InvestmentId from [OPGC].[OpgcInvestment] where FundID = @FundId and InvestmentName = @InvestmentName and Isdeleted = 0 )


insert into [OPGC].[opgcInvestmentCashFlow]
(
 FundId
,ScenarioId
,InvestmentCashflowTypeId
,InvestmentId
,Equity
,EventDate
,Isdeleted
,CreatedBy
,CreatedOn
)
select
 @FundId
,@ScenarioId
,100
,@InvestmentId1
,0
,GETDATE()
,0
,@userAlias
,GETDATE()


end



END









END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
							IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END         
END CATCH
END


