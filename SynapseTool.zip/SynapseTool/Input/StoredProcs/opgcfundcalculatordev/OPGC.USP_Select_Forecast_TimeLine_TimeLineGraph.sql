SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_TimeLine_TimeLineGraph]  --'',7,34,3
(
	@userAlias NVARCHAR(50),
	@FundId INT ,
	@ScenarioID INT,
	@InvestmentID INT
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

BEGIN TRY

SELECT 
max( B.InvestmentName ) as InvestmentName ,
A.EventDate,
A.InvestmentCashflowTypeId,
max( C.InvestmentCashFlowType) as InvestmentCashFlowType,
SUM (Equity) AS ValueAmount 
FROM [OPGC].[OpgcInvestmentCashFlow] A
JOIN [OPGC].[OpgcInvestment] B
ON A.InvestmentId=B.InvestmentId
JOIN [OPGC].[OpgcInvestmentCashFlowType] C
ON A.InvestmentCashflowTypeId =C.InvestmentCashFlowTypeId
where A.FundId = @FundId AND A.ScenarioId = @ScenarioID AND A.InvestmentId = @InvestmentID 
AND  A.Isdeleted=0 AND A.InvestmentCashflowTypeId IN (1,2,3)
group by A.EventDate,A.InvestmentCashflowTypeId


END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


