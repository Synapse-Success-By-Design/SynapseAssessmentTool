SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_Fund_CashFlowEventDetails_backup] --'admin',56,195
(
	   @userAlias NVARCHAR(250)
	  ,@fundId INT
	  ,@scenarioId INT
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

BEGIN TRY



--declare @FundId int  = 56
--Declare @ScenarioId int = 171

declare @InvesmentIdBase as table ( Id int)



;with investmentBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @fundid and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and 
  FundId = @fundid and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdBase
select A.InvestmentId from investmentBaseInitial A
join investmentBaseExit B
on A.InvestmentId =B.InvestmentId


-----------------Scenario Level ------------------------------------------------------------------------------------------------------------------------------

declare @CommittedCapital decimal(30,2) = (select CommittedCapital from   [OPGC].[OpgcScenario] where ScenarioId = @scenarioId and Isdeleted = 0 )
--select @CommittedCapital as CommittedCapital

declare @ManagementFeePercent decimal(30,5) = (select (ManagementFeePercent/100) from   [OPGC].[OpgcScenario] where ScenarioId = @scenarioId and Isdeleted = 0 )
--select @ManagementFeePercent as ManagementFeePercent

declare @OtherPartnershipFeesByQuarter decimal(30,2) = (select OtherPartnershipFeesByQuarter from   [OPGC].[OpgcScenario] where ScenarioId = @scenarioId and Isdeleted = 0 )
--select @OtherPartnershipFeesByQuarter as ManagementFeePercent

declare @OffsetByQuarter decimal(30,2) = (select OffsetsByQuarter from   [OPGC].[OpgcScenario] where ScenarioId = @scenarioId and Isdeleted = 0 )
--select @CurrentOffsetByQuarter as ManagementFeePercent


declare @SumOfNegativeInvestment decimal(30,2) = ( select SUM(Equity) from   [OPGC].[OpgcInvestmentCashFlow] where FundId =  @fundId and ScenarioId = @scenarioId and InvestmentId in ( select Id from @InvesmentIdBase) and InvestmentCashflowTypeId  in (1,2,4,6) and Isdeleted = 0 )
--select @SumOfNegativeInvestment as SumOfNegativeInvestment

declare @FundInceptionDate date  = (select FundInceptionDate from   [OPGC].[OpgcScenario] where ScenarioId = @scenarioId and Isdeleted = 0 )
--select @FundInceptionDate as FundInceptionDate

declare @ManualStepdownDate date  = (select ManualStepdownDate from   [OPGC].[OpgcScenario] where ScenarioId = @scenarioId and Isdeleted = 0 )
--select @ManualStepdownDate as ManualStepdownDate

declare @CalculatedManualStepdownDate date  = (select DATEADD(yy,5,FundInceptionDate) from   [OPGC].[OpgcScenario] where ScenarioId = @scenarioId and Isdeleted = 0 )
--select @CalculatedManualStepdownDate as CalculatedManualStepdownDate

Declare @MaxDateInvest date = ( select DATEADD(q, DATEDIFF(q, 0, Max(EventDate)), 0) from   [OPGC].[OpgcInvestmentCashFlow] where FundId =  @fundId and ScenarioId = @scenarioId and Isdeleted = 0 )
--select @MaxDateInvest

Declare @MaxDateFund date = ( select DATEADD(q, DATEDIFF(q, 0, Max(EventDate)), 0) from   [OPGC].[OpgcFundCashFlow] where FundId =  @fundId and ScenarioId = @scenarioId and Isdeleted = 0 )
--select @MaxDateFund

Declare @MinDateInvest date = ( select DATEADD(q, DATEDIFF(q, 0, min(EventDate)), 0) from   [OPGC].[OpgcInvestmentCashFlow] where FundId =  @fundId and ScenarioId = @scenarioId and Isdeleted = 0 )
--select @MinDateInvest


declare @InvesmnetInitialDate date = ( select DATEADD(q, DATEDIFF(q, 0, min(EventDate)), 0)  from  [OPGC].[OpgcInvestmentCashFlow] where FundId =  @fundId 
                                              and ScenarioId = @scenarioId and InvestmentCashflowTypeId = 1 and Isdeleted = 0)
--select @InvesmnetInitialDate as InvesmnetInitialDate

declare @InvesmentMaxDate date = ( select DATEADD(q, DATEDIFF(q, 0, Max(EventDate)), 0) from  [OPGC].[OpgcInvestmentCashFlow] where FundId =  @fundId 
                                          and ScenarioId = @scenarioId and InvestmentId in ( select Id from @InvesmentIdBase)  and Isdeleted =0 )
--select @InvesmentMaxDate as InvesmentMaxDate


declare @FundMaxDate date = ( select DATEADD(q, DATEDIFF(q, 0, Max(EventDate)), 0) from  [OPGC].[OpgcFundCashFlow] where FundId =  @fundId 
                                      and ScenarioId = @scenarioId and Isdeleted =0  )
--select @FundMaxDate as FundMaxDate

declare @PhantomCalculation as table 
(  
   FundId                      int,
   ScenarioId                  int,
   TypeId                      int,
   CashflowType                nvarchar(250),
   EventDate                   date ,
   LPCostContribution          decimal(30,2)
)

---------To Find Date  for Phantom ---------------------------------------------------------

If @FundMaxDate is not null
begin 


	;with ManagmentFees as
	(
	   select   1 r,@FundMaxDate s , 6 as TypeId , 'Managment Fees Contribution' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) ,6 as TypeId , 'Managment Fees Contribution' as CashflowType  from ManagmentFees where r<=datediff(qq,@FundMaxDate,@InvesmentMaxDate) 
	)




	insert into @PhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select @fundId , @scenarioId ,  
	TypeId, CashflowType , s from ManagmentFees 
	where  r not in(1)
	option (maxrecursion 1000)


-------------------------------------------------Other Partnership Expenses------------------------------------------------------------------

	;with OtherPartnerShipExpenses as
	(
	   select   1 r,@FundMaxDate s , 7 as TypeId , 'Other PartnerShip Expenses Contribution' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) , 7 as TypeId , 'Other PartnerShip Expenses Contribution' as CashflowType   from OtherPartnerShipExpenses where r<=datediff(qq,@FundMaxDate,@InvesmentMaxDate) 
	)

	insert into @PhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @fundId , @scenarioId ,  TypeId, CashflowType , s from OtherPartnerShipExpenses where  r not in(1)
	option (maxrecursion 1000)


-------------------------------------------------Offset By Quarter------------------------------------------------------------------

	;with OffsetByQuarter as
	(
	   select   1 r,@FundMaxDate s , 10 as TypeId , 'Offset By Quarter' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) , 10 as TypeId , 'Offset By Quarter' as CashflowType   from OffsetByQuarter where r<=datediff(qq,@FundMaxDate,@InvesmentMaxDate) 
	)

	insert into @PhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @fundId , @scenarioId ,  TypeId, CashflowType , s from OffsetByQuarter where  r not in(1)
	option (maxrecursion 1000)
-------------------------------------------------------------------------------------------------------------------------------------------------------


end
else 
begin



	;with ManagmentFees as
	(
	   select   1 r,@InvesmnetInitialDate s , 6 as TypeId , 'Managment Fees Contribution' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) ,6 as TypeId , 'Managment Fees Contribution' as CashflowType  from ManagmentFees where r<=datediff(qq,@InvesmnetInitialDate,@InvesmentMaxDate) 
	)

	insert into @PhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @fundId , @scenarioId ,  TypeId, CashflowType , s from ManagmentFees where  r not in(1)
	option (maxrecursion 1000)


-------------------------------------------------Other Partnership Expenses------------------------------------------------------------------

	;with OtherPartnerShipExpenses as
	(
	   select   1 r,@InvesmnetInitialDate s , 7 as TypeId , 'Other PartnerShip Expenses Contribution' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) , 7 as TypeId , 'Other PartnerShip Expenses Contribution' as CashflowType   from OtherPartnerShipExpenses where r<=datediff(qq,@InvesmnetInitialDate,@InvesmentMaxDate) 
	)

	insert into @PhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @fundId , @scenarioId ,  TypeId, CashflowType , s from OtherPartnerShipExpenses where  r not in(1)
	option (maxrecursion 1000)


-------------------------------------------------Offset BY Quarter------------------------------------------------------------------

	;with OffsetByQuarter as
	(
	   select   1 r,@InvesmnetInitialDate s , 10 as TypeId , 'Offset By Quarter' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) , 10 as TypeId , 'Offset By Quarter' as CashflowType   from OffsetByQuarter where r<=datediff(qq,@InvesmnetInitialDate,@InvesmentMaxDate) 
	)

	insert into @PhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @fundId , @scenarioId ,  TypeId, CashflowType , s from OffsetByQuarter where  r not in(1)
	option (maxrecursion 1000)

end

--select * from @PhantomCalculation

;with Phantom as
(

SELECT  A.FundId AS FundId
	   ,A.ScenarioId AS ScenarioId
       ,FundCashflowId AS FundCashFlowId 
       ,A.EventDate AS EventDate
	   ,B.FundCashFlowTypeId AS FundCashFlowTypeId
       ,B.FundCashFlowTypeName AS FundCashFlowTypeName
       --,A.ValueAmount AS ValueAmount
	   ,cast ( round (A.ValueAmount ,0) as decimal(30,0))  AS ValueAmount
	   ,CASE WHEN [IsActual] = 1 THEN 'Actual' ELSE 'Hypothetical' END AS [Status]
       ,A.[Tag] AS Tag
	   ,A.LimitedPartnerPercent
	    FROM [OPGC].[OpgcFundCashFlow] A
	    JOIN [OPGC].[OpgcFundCashFlowType] B
	    ON A.FundCashflowTypeId = B.FundCashFlowTypeId

WHERE A.FundId = @fundId and A.ScenarioId = @scenarioId and A.Isdeleted = 0

union all

select
FundId
,ScenarioId
, 0 as FunCAshFlowId
,EventDate
,TypeId
,CashflowType
, LPCostContribution = case when @ManualStepdownDate IS null and TypeId = 6  and  EventDate < @CalculatedManualStepdownDate
                                then  cast ( (@CommittedCapital * @ManagementFeePercent)/4 as decimal(30,2) )  -- -1 *
							When @ManualStepdownDate IS null and TypeId = 6 and  EventDate >= @CalculatedManualStepdownDate
                                then  cast ((@SumOfNegativeInvestment * @ManagementFeePercent)/4 as decimal(30,2) )
							When @ManualStepdownDate is not null and TypeId = 6 and  EventDate < @ManualStepdownDate
                                then  cast ((@CommittedCapital * @ManagementFeePercent)/4 as decimal(30,2))
							When @ManualStepdownDate is not null and TypeId = 6 and  EventDate >= @ManualStepdownDate
                                then  cast ((@SumOfNegativeInvestment * @ManagementFeePercent)/4  as decimal(30,2))
                            when TypeId = 7 then  cast ( @OtherPartnershipFeesByQuarter as decimal(30,2))
							when TypeId = 10 then  cast ( @OffsetByQuarter as decimal(30,2))
                       Else  LPCostContribution  end
, 'Forecast' as Status
,Null as Tag
,cast ( 100 as decimal(18,2)) as LimitedPartnerPercent
from @PhantomCalculation
order by EventDate , TypeId asc
offset 0 rows
)

select  FundId AS FundId
	   ,ScenarioId AS ScenarioId
       ,FundCashflowId  AS FundCashFlowId 
       ,EventDate AS EventDate
	   ,FundCashFlowTypeId  AS FundCashFlowTypeId
       ,FundCashFlowTypeName AS FundCashFlowTypeName
       --,A.ValueAmount AS ValueAmount
	   ,cast ( ValueAmount as Nvarchar(max)) ValueAmount
	   , [Status]
       ,[Tag] AS Tag
	   ,LimitedPartnerPercent from Phantom
order by EventDate --,FundCashFlowTypeId asc
--offset 0 rows

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END
