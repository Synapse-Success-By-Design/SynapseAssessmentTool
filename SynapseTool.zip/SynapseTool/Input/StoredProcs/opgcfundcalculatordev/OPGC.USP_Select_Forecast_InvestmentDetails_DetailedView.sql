SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_InvestmentDetails_DetailedView]  -- '',56,171
(
	 @userAlias NVARCHAR(250)
	,@fundId INT
	,@scenarioId INT
	
)

As

BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

BEGIN TRY

--;With investment as
--(
select A.InvestmenCashflowId, A.FundId  , A.ScenarioId , A.InvestmentId , B.InvestmentName ,A.InvestmentCashflowTypeId
--,Equity
, cast ( cast ( Equity as decimal(30,0)) as nvarchar(max) ) as Equity
, CAST(A.EventDate AS Date)  as EventDate 
--, case when  A.InvestmentCashflowTypeId in (1,2) then - A.Equity else Equity end as Equity
,case when  A.InvestmentCashflowTypeId =1  Then 1 Else 0 End as IsInitial 
, case when A.InvestmentCashflowTypeId in (2,4,6)  Then 1 Else 0 End as  IsFollowup
,case when  A.InvestmentCashflowTypeId in (3,5,7,8)  Then 1 Else 0 End as IsExitdate  

,case when  A.InvestmentCashflowTypeId =1  Then 'Intial Investment' Else 'NA' End as  IsInitialType 
, case when A.InvestmentCashflowTypeId in (2,4,6)  Then 'Follow on Investment' Else 'NA' End as  IsFollowOnType
,case when  A.InvestmentCashflowTypeId in (3,5,7,8)  Then 'Exit' Else 'NA' End as  IsExitType 
,CASE WHEN A.IsActual = 1 THEN 'Actual' ELSE 'Hypothetical' END AS [Status]
,A.LimitedPartnerPercent

  from [OPGC].[OpgcInvestmentCashFlow]  A
  inner join [OPGC].[OpgcInvestment] B
  on A.InvestmentId = B.InvestmentId
  where  A.FundId = @fundId and ScenarioId = @scenarioId and A.Isdeleted=0 and A.InvestmentCashflowTypeId in (1,2,3,4,5,6,7,8)
  order by EventDate--,InvestmentCashflowTypeId,InvestmentId



--select A.InvestmenCashflowId, A.FundId , A.ScenarioId , A.EventDate , A.InvestmentId, A.InvestmentName , A.Equity  , B.InvestmentCashFlowType , A.InvestmentCashflowTypeId

--from investment A
--inner join [OPGC].[OpgcInvestmentCashFlowType] B
--on A.InvestmentCashflowTypeId = B.InvestmentCashFlowTypeId

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END




