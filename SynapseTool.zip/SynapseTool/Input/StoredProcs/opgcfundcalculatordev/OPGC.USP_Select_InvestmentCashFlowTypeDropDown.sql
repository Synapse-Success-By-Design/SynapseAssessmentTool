SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_InvestmentCashFlowTypeDropDown]-- '',1,1,1,'Update'
(
	@userAlias NVARCHAR(50)
	--@FundId INT,             -- These parameter are commented as per client requirment (11th jan 22)
	--@ScenarioId INT,		   -- 
	--@InvestmentId INT,	   -- 
	--@Type NVARCHAR(10)	   -- 
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Appointment Details

Uses   
      [USP_Select_Appointment_GetAppointmentDetails]	    SP

Populates
      [WWMG].[ConfirmedScheduleDetails]			Table
	  [WWMG].[LocationDetails]					Table
	  [WWMG].[UserFamilyDetails]				Table
	  [WWMG].[FamilyDetails_Relations]			Table
**************************************************************************/
BEGIN TRY


--DECLARE @IfIntialInvestmentExist  INT =(SELECT COUNT(*) FROM [OPGC].[opgcInvestmentCashFlow] wHERE FundId= @FundId AND ScenarioId = @ScenarioId AND InvestmentId
--										=@InvestmentId AND InvestmentCashflowTypeId=1)


--IF @Type ='Add'
--BEGIN

--IF @IfIntialInvestmentExist !=0

--BEGIN

--SELECT 
--InvestmentCashFlowTypeId
--,InvestmentCashFlowType
--FROM [OPGC].[opgcInvestmentCashFlowType]
--where InvestmentCashFlowTypeId in (2,3) and Isdeleted=0

--END

--ELSE

--BEGIN


--SELECT 
--InvestmentCashFlowTypeId
--,InvestmentCashFlowType
--FROM [OPGC].[opgcInvestmentCashFlowType]
--where InvestmentCashFlowTypeId in (1,2,3) and Isdeleted=0

--END

--END

---------------------------------------------------------

----UPDATE DROP DOWN

--IF @Type ='Update'

--begin

--SELECT 
--InvestmentCashFlowTypeId
--,InvestmentCashFlowType
--FROM [OPGC].[opgcInvestmentCashFlowType]
--where InvestmentCashFlowTypeId in(2,3) and Isdeleted=0

--end


SELECT 
InvestmentCashFlowTypeId
,InvestmentCashFlowType
FROM [OPGC].[opgcInvestmentCashFlowType] where Isdeleted=0
--AND InvestmentCashFlowTypeId IN (1,2,3) 
and InvestmentCashFlowTypeId <> 100


END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


