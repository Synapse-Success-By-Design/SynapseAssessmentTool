SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

 --[OPGC].[USP_Select_FundDetailsByFundId] '',1

CREATE PROCEDURE [OPGC].[USP_Select_FundDetailsByFundId] --'1'
(
	@UserAlias NVARCHAR(50)
	,@FundId INT
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Fund Details

Uses   
      [OPGC].[USP_Select_Funds_GetFundsListing]	    SP

Populates
      [OPGC].[Fund]			Table

**************************************************************************/
BEGIN TRY

--declare @FundId int
--set @FundId = @UserAlias 

SELECT 
     FundId   ,            
     [FundName​]  as FundName​           
     --,[TotalInvestment​] TotalInvestment​      
     --,[TotalRealized​]   TotalRealized      
     ----,[TotalUnrealized​]  TotalUnrealized   
	 --,  cast ( CAST ([TotalInvestment​] AS Decimal(30,0)) AS nvarchar(max)) TotalInvestment      
  --   ,cast ( CAST([TotalRealized​] AS Decimal(30,0)) AS nvarchar(max))  TotalRealized​ 	 
	 -- ,cast ( CAST([TotalUnrealized​] AS Decimal(30,0)) AS nvarchar(max)) TotalUnrealized​  
	 ,cast ( CAST([CommittedCapital] AS Decimal(30,0)) AS nvarchar(max))   CommittedCapital
	 ,cast ( CAST([OffsetsByQuarter] AS Decimal(30,0)) AS nvarchar(max))   OffsetsByQuarter
	 ,cast ( CAST([OtherPartnershipFeesByQuarter] AS Decimal(30,0)) AS nvarchar(max))  OtherPartnershipFeesByQuarter
     ,[Description​]  Description​         
     --,cast ( CAST([ExpenseCap​] AS Decimal(30,0)) AS nvarchar(max))  ExpenseCap​     
	 ,[FundInceptionDate]   FundInceptionDate
     ,[ManualStepdownDate​]  ManualStepdownDate  
     --,[LimitedPartnerPercent​] LimitedPartnerPercent​
	 ,[LPPreferredReturnPercent]  LPPreferredReturnPercent
	 ,[LPFinalSharePercent]	 	  LPFinalSharePercent	 
	 ,[GPPreferredReturnPercent]  GPPreferredReturnPercent
     ,[ManagementFeePercent​]  ManagementFeePercent​
from [OPGC].[OpgcFund]	 
where FundId = @FundId

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


