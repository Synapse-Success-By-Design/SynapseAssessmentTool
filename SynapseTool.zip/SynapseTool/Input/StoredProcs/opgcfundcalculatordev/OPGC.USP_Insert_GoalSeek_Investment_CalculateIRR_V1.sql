SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [OPGC].[USP_Insert_GoalSeek_Investment_CalculateIRR_V1] --'DB Team' , 44 , 143 , 203,39,'2021-10-30',null
(  

@UserAlias      nvarchar(250),
@FundId         int,
@ScenarioId     int ,
@InvestmentId   int ,
@TargetIRR      decimal (18,2),
@TargetDate     date ,
@GSInvestmentId int out
   
)  
  
As  
  
BEGIN  

BEGIN TRY

declare @InitalDate date = ( select min(EventDate) from [OPGC].[OpgcInvestmentCashFlow]    where InvestmentCashflowTypeId  in (1,2,4,6) and  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  )

DECLARE @ErrorText NVARCHAR(MAX) =''

If  @TargetIRR <= 0 or @TargetIRR is null
begin
SET @ErrorText = 'Please enter valid Target IRR'
RAISERROR (@ErrorText, 16, 1)

end

If  @TargetDate is null  or @TargetDate <= @InitalDate
begin
SET @ErrorText = 'Please enter valid Target Date'
RAISERROR (@ErrorText, 16, 1)
end

Declare @target Decimal (18,2)

set @target = @TargetIRR

declare @Exitvallue Decimal (18,2)

declare @snapshotDate Datetime = Getdate()

---------------------------------InvestmentId----------------------------------------------------------------------
declare @InvesmentIdBase as table ( Id int)

declare @ExitValueCheck  int 

;with investmentBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId)

insert into @InvesmentIdBase
select A.InvestmentId from investmentBaseInitial A
join investmentBaseExit B
on A.InvestmentId =B.InvestmentId

--------insert target investment id --------------------------
insert into @InvesmentIdBase
select @InvestmentId
----------------------------------------------------------------------------------------------------------------------------------------------------------

DECLARE @Test [OPGC].[GIRRTableTEST]

DECLARE @cte AS table ([value] decimal (18,2), [Date] DATETIME, ID INT)
INSERT INTO @cte 

select case when InvestmentCashflowTypeId in (1,2,4,6) then  - Equity  else Equity end as [value] , EventDate  as [Date] 
       , case when InvestmentCashflowTypeId in (1,2,4,6) then 1 else 2 End as ID
 from [OPGC].[OpgcInvestmentCashFlow] 
 where FundId = @FundId and ScenarioId = @ScenarioId  and InvestmentId in ( select Id from @InvesmentIdBase ) 
       and Isdeleted = 0

SELECT @Exitvallue = (SELECT ABS(Sum([value]))* 1 FROM @cte WHERE Id = 1)

--select @Exitvallue  as ExitValue

--select * from @cte

INSERT INTO @Test
SELECT [value], [Date] FROM @cte
UNION 
SELECT @Exitvallue, @Targetdate FROM @cte

DECLARE @resulGirr  Decimal (18,2)
SELECT @resulGirr = CAST(ROUND([OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) --AS GIRR, @SnapshotDate as SnapshotDate

SELECT @resulGirr as ResultGirr

------------------------------------------------------------------------------------------------------------------------------------------------------------

--WHILE( @resulGirr + 0.75) <= @target
WHILE( @resulGirr + 0.50) <= @target
BEGIN 

SET @Exitvallue = @Exitvallue * 1.025
--SET @Exitvallue = @Exitvallue * 1.010
DELETE FROM @Test
INSERT INTO @Test
SELECT [value], [Date] FROM @cte
UNION 
SELECT @Exitvallue, @Targetdate FROM @cte

SELECT @resulGirr = CAST(ROUND([OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) --AS GIRR, @SnapshotDate as SnapshotDate

--IF ABS(@target-@resulGirr) <= 0.75
IF ABS(@target-@resulGirr) <= 0.50

BEGIN
INSERT INTO OPGC.TargetGIRRcalculation
SELECT  @Exitvallue,@snapshotDate,@resulGirr,@target,@TargetDate
END
END

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
WHILe( @resulGirr + 0.50) > @target
BEGIN 

SET @Exitvallue = @Exitvallue / 1.025
--SET @Exitvallue = @Exitvallue / 1.010
DELETE FROM @Test
INSERT INTO @Test
SELECT [value], [Date] FROM @cte
UNION 
SELECT @Exitvallue, @Targetdate FROM @cte

SELECT @resulGirr = CAST(ROUND([OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) --AS GIRR, @SnapshotDate as SnapshotDate

IF ABS(@target-@resulGirr) <= 0.50
--IF ABS(@target-@resulGirr) <= 0.25
BEGIN
INSERT INTO OPGC.TargetGIRRcalculation
SELECT  @Exitvallue,@snapshotDate,@resulGirr,@target,@TargetDate
END

END
DECLARE @searchvalue Decimal (18,2) = (SELECT MIN(ABS(CalulatedGIRR-TagetGIRR)) FROM OPGC.TargetGIRRcalculation WHERE Snapshotdate = @snapshotDate)
select @Exitvallue = (SELECT top 1 Exitvalue FROM OPGC.TargetGIRRcalculation  
WHERE Snapshotdate = @snapshotDate and ABS(CalulatedGIRR-TagetGIRR) = @searchvalue )

select @Exitvallue as ExitValue
----------------Inserting Goal Seek table ----------------------------------------------------

--insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
--(  
--FundId
--,ScenarioId
--,InvestmentId
--,IRR
--,ExitDate
--,Exitvalue 
--,CreatedBy
--,CreatedOn
--)
--select     
-- @FundId         
--,@ScenarioId     
--,@InvestmentId
--,@TargetIRR
--,@TargetDate   
--,@Exitvallue 
--,@UserAlias  
--,getdate()

------------------------------------------------------------------------------------------------------

--set @GSInvestmentId = ( select top 1 GsInvestmentId from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentID order by 1 desc )

--delete select * from OPGC.TargetGIRRcalculation  where Snapshotdate = @snapshotDate

END TRY  
BEGIN CATCH  
 DECLARE @ErrorNumber INT  
 DECLARE @Severity  INT  
 DECLARE @State   INT   
 DECLARE @Procedure  NVARCHAR(250)  
 DECLARE @LineNumber  INT  
 DECLARE @Message  NVARCHAR(MAX)  
 DECLARE @Originator NVARCHAR(250)   
 SELECT   
  @ErrorNumber = ERROR_NUMBER(),  
  @Severity = ERROR_SEVERITY(),  
  @State = ERROR_STATE(),   
  @Procedure = ERROR_PROCEDURE(),  
  @LineNumber = ERROR_LINE(),   
  @Message = ERROR_MESSAGE()     
 EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message,   
       'Database', null, null,null                
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END         
END CATCH
END



