SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Insert_Forecast_Fund_AddCashFlowEvent]  --1,1,'2021-03-14 00:00:00.000',1,'5000','Actual',NULL,''
(
	    @fundId INT
	   ,@scenarioId INT	
	   ,@eventDate DATE 
	   ,@fundCashFlowTypeID INT  
	   ,@valueAmount DECIMAL(30,2) 
	   ,@status NVARCHAR(50)
	   ,@tag NVARCHAR(250)
	   ,@userAlias NVARCHAR(250)
	   ,@LimitedPartnerPercent decimal (5,2)
	  
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 


BEGIN TRY


DECLARE @ErrorText NVARCHAR(MAX)

declare @CheckFundCashflowTypeId int = (select count(1) from [OPGC].[OpgcFundCashFlow] where  FundId =@fundId and ScenarioId =@scenarioId AND FundCashflowTypeId =1 and Isdeleted=0 )

--IF @CheckFundCashflowTypeId = 0 AND @fundCashFlowTypeID = 2
--BEGIN
--SET @ErrorText = 'Please Add Contribution'
--RAISERROR (@ErrorText, 16, 1)
--END

--Else
--BEGIN
declare @FundMindate date = ( select FundInceptionDate from [OPGC].[OpgcScenario]  where FundId =@fundId and ScenarioId =@scenarioId )


 if @FundMindate > @eventDate
begin
SET @ErrorText = 'Date is less than Fund Inception Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)
end 

	   INSERT INTO  [OPGC].[OpgcFundCashFlow] 
	    (
		FundId
		,ScenarioId
		,EventDate
	   ,FundCashflowTypeId
	   ,ValueAmount
	   ,IsActual
	   ,IsHypothetical
	   ,LimitedPartnerPercent
	   ,Tag
	   ,CreatedBy
       ,CreatedOn)
	   
	    SELECT 
		 @fundId
		,@scenarioId
		,@eventDate
		,@fundCashFlowTypeID
		,@valueAmount
		,CASE WHEN @status ='Actual' then 1 ELSE 0 END
		,CASE WHEN @status ='Hypothetical' then 1 ELSE 0 END
		,@LimitedPartnerPercent
		,@tag
		,@userAlias
		,GETDATE()
 
--END	


END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END   
END CATCH
END


