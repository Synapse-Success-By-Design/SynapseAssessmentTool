SELECT DB_NAME(s.database_id) AS DBName, SCHEMA_NAME(o.schema_id) AS SchemaName, OBJECT_NAME(s.OBJECT_ID) AS TableName,
MAX(last_user_seek) AS last_user_seek, 
MAX(last_user_scan) AS last_user_scan, 
MAX(last_user_lookup) AS last_user_lookup, 
MAX(last_user_update) AS last_user_update,
MAX(last_system_scan) AS last_system_scan,
MAX(last_system_update) AS last_system_update
FROM sys.dm_db_index_usage_stats s WITH (NOLOCK)
LEFT OUTER JOIN sys.objects o WITH (NOLOCK) ON s.object_id = o.object_id
WHERE s.database_id = DB_ID() 
GROUP BY s.database_id, o.schema_id, s.object_id 