SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [OPGC].[USP_Insert_GoalSeek_Investment_CalculateIRR_V7] --'DB Team' , 44 , 143 , 203,39,'2021-10-30',null
(  

@UserAlias      nvarchar(250),
@FundId         int,
@ScenarioId     int ,
@InvestmentId   int ,
@TargetIRR      decimal (18,2),
@TargetDate     date ,
@GSInvestmentId int out
 
   
)  
  
As  
  
BEGIN  

BEGIN TRY

--declare @FundId        int = 44
--Declare @ScenarioId    int = 143
--Declare @InvestmentId  int = 201
--declare @GSInvestmentId int
--declare @TargetIRR decimal (18,2) = 25
--declare @TargetDate date = '2026-03-31'


declare @InitalDate date = ( select min(EventDate) from [OPGC].[OpgcInvestmentCashFlow]    where InvestmentCashflowTypeId  in (1,2,4,6) and  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  )

DECLARE @ErrorText NVARCHAR(MAX) =''

If  @TargetIRR <= 0 or @TargetIRR is null
begin
SET @ErrorText = 'Please enter valid Target IRR'
RAISERROR (@ErrorText, 16, 1)

end

If  @TargetDate is null  or @TargetDate <= @InitalDate
begin
SET @ErrorText = 'Please enter valid Target Date'
RAISERROR (@ErrorText, 16, 1)
end


--declare @FundId        int = 2
--Declare @ScenarioId    int = 137
--Declare @InvestmentId  int = 209
--declare @GSInvestmentId int
--declare @TargetIRR decimal (18,2) = 45
--declare @TargetDate date = '2026-07-25'
----2026-03-31
----10,450,000

 
DECLARE @cashflowdetails as table (
 FundID INT
,ScenarioId INT
,InvestmentId INT
, InvestmentCashFlowTypeId int
,EventDate DateTime
,Equity Decimal (38,2)

)
--declare @MindateAdd date = ( select min(EventDate)  from [OPGC].[OpgcInvestmentCashFlow]   where InvestmentCashflowTypeId  = 1 and 
--  FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentId and Isdeleted=0  )

declare @Invesmentname nvarchar(250) = (select InvestmentName from [OPGC].[OpgcInvestment] where FundID = @FundId and InvestmentId =@InvestmentId and Isdeleted = 0)

declare  @TargetIRR1 decimal(38,2) = ( select 1 + (@TargetIRR/100))


declare @InvesmentIdBase as table ( Id int)

declare @ExitValueCheck  int 


declare @CalcExitDateValue decimal(38,2)

Declare @ResultExitValue decimal (38,2)


;with investmentBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdBase
select A.InvestmentId from investmentBaseInitial A
join investmentBaseExit B
on A.InvestmentId =B.InvestmentId

--------insert target investment id --------------------------
insert into @InvesmentIdBase
select @InvestmentId


declare @MindateAdd date = ( select min(EventDate)  from [OPGC].[OpgcInvestmentCashFlow]   where InvestmentCashflowTypeId  in ( 1,2,4,6) and 
  FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId in (select Id from @InvesmentIdBase)  and Isdeleted=0  )


--select * from @InvesmentIdBase

--Declare @MinDate table 
--( FundId int , 
--  ScenarioId int , 
--  InvestmentId int,
--  MinEvenDate date
--)

--;with mindate as
--(
--select FundId ,ScenarioId ,InvestmentId ,EventDate
--from [OPGC].[OpgcInvestmentCashFlow]
--where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentCashflowTypeId in (1,2,4,6) and InvestmentId in ( select Id from @InvesmentIdBase ) and Isdeleted = 0
--)

--insert into @MinDate
--select FundId ,ScenarioId ,InvestmentId ,Min(EventDate)
--from mindate
--group by FundId ,ScenarioId ,InvestmentId

Declare @EventCashFlow table
(
 Id Int Identity (1,1)
 ,FundId	   int
,ScenarioId	int
,InvestmentId	Int
,InvesmentName nvarchar(250)
,InvestmentCashflowTypeId int
,EventDate	Date
,Equity	Decimal (38,2)
,IsSelectedInvestment	bit
,MinDate	Date
)

insert into @EventCashFlow

select A.FundId , A.ScenarioId , A.InvestmentId, B.InvestmentName ,A.InvestmentCashflowTypeId
, A.EventDate ,
 case when A.InvestmentCashflowTypeId IN ( 1,2,4,6) then - A.Equity else A.Equity end as Equity ,
case when A.InvestmentId = @InvestmentId then 1 else 0 end as IsSelectedInvestment
--,C.MinEvenDate
,@MindateAdd as MinEvenDate
from [OPGC].[OpgcInvestmentCashFlow] A
join [OPGC].[OpgcInvestment] B
on A.FundId = B.FundID and A.InvestmentId = B.InvestmentId
--join @MinDate C
--on A.InvestmentId = C.InvestmentId
where A.FundId = @FundId and A.ScenarioId = @ScenarioId and A.InvestmentId in ( select Id from @InvesmentIdBase ) and A.Isdeleted = 0

insert into @EventCashFlow

select @FundId , @ScenarioId , @InvestmentId , @Invesmentname , 3 , @TargetDate , Null ,1, @MindateAdd as MinEvenDate

--select * from @EventCashFlow
----------------------------------inserting GIRR---------------------------------------------------------
insert into @cashflowdetails
(
 FundID 
,ScenarioId 
,InvestmentId 
, InvestmentCashFlowTypeId 
,EventDate 
,Equity 
)

select 
 FundId	   
,ScenarioId	
,InvestmentId	
,InvestmentCashflowTypeId 
,EventDate
,Equity
from @EventCashFlow where Equity is not null
----------------------------------------------------------------------------------------------------------------------------------
; with YearDiff as 
(
select 
 Id
 ,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
--, case when IsSelectedInvestment =0  then datediff(day,MinDate ,EventDate) / 365.2425 
--       else datediff(day,MinDate , @TargetDate)/ 365.2425 end  as  YearDiffernce 
,cast ( datediff(day,MinDate ,EventDate) / 365.2425 as decimal(18,2))  as YearDiffernce 
,   @TargetIRR1 as  TargetIRR 
--,cast (POWER(@TargetIRR,YearDiffernce) as float)
from @EventCashFlow
)
, DcValue as 
(
select 
 Id
 ,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
, YearDiffernce 
,  TargetIRR 
,cast (POWER(TargetIRR,YearDiffernce) as decimal(38,2)) as DcValue
from YearDiff
)

, calcExitvalue as
(
select 
  Id
,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,   YearDiffernce 
,    TargetIRR 
, DCvalue
,  case when Equity =0 then 0.00 else cast (Equity / DCValue  as decimal(38,2)) end as CalDCValue
--, case when InvestmentCashflowTypeId in (1,2,4,6) then SUM(Equity) else 0 end as SumofInvesment 
from DCValue)

--select * from calcExitvalue

, Cumulative as
(
select 
  Id
,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,   YearDiffernce 
,    TargetIRR 
, DCvalue
,  CalDCValue

,sum(CalDCValue) OVER (ORDER BY Id) as Cumulative
--, case when InvestmentCashflowTypeId in (1,2,4,6) then SUM(Equity) else 0 end as SumofInvesment 
from calcExitvalue 
)
--select * from Cumulative

, ResultExitValue as
(
select 
  Id
,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,   YearDiffernce 
,    TargetIRR 
, DCvalue
,  CalDCValue

, Cumulative
--, abs(Cumulative) * DCvalue as ResultExitValue
, (Cumulative*-1) * DCvalue as ResultExitValue
--, case when InvestmentCashflowTypeId in (1,2,4,6) then SUM(Equity) else 0 end as SumofInvesment 
from Cumulative  where Equity is NUll
)


--select * from ResultExitValue

-- Select @ResultExitValue = ( select ResultExitValue from ResultExitValue )

 Select @ResultExitValue = ( select case when ResultExitValue < 0 then 0.00 else ResultExitValue end as  ResultExitValue  from ResultExitValue )


-----------------------Girr---------------------------------------------------------------

insert into @cashflowdetails
(
 FundID 
,ScenarioId 
,InvestmentId 
, InvestmentCashFlowTypeId 
,EventDate 
,Equity 

)
select 
 @FundId	   
,@ScenarioId	
,@InvestmentId	
,3 
,@TargetDate
,@ResultExitValue


--select * from @cashflowdetails

DECLARE @SnapshotDate Datetime = GETDATE()  

DECLARE @resultcount INT
DECLARE @Test [OPGC].[GIRRTableTEST] -- [OPGC].[GIRRTable]

INSERT  @Test
SELECT  Equity , EventDate FROM @cashflowdetails

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @fundid ,@ScenarioId, 0, 
        case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 
		     Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
        @SnapshotDate  




 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;



SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @ScenarioId  and SnapshotDate = @SnapshotDate and InvestmentID =0)

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@ScenarioId, 0,0.0 AS GIRR, @SnapshotDate
END

DELETE FROM @Test

declare @TotalGIRR decimal(38,2) = ( select GIRR  FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate  )  --NULL
--select @TotalGIRR as TotalGirr
--select @TargetIRR


declare  @TotalGIRRNull decimal(38,2) = ( select Isnull( @TotalGIRR , 0.00) )


--select @TotalGIRRNull


if @TotalGIRRNull = 0.00
begin
insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
(  
FundId
,ScenarioId
,InvestmentId
,IRR
,ExitDate
,Exitvalue 
,CreatedBy
,CreatedOn
,CalcIRR
)

select     
 @FundId         
,@ScenarioId     
,@InvestmentId
,@TargetIRR
,@TargetDate   
,@ResultExitValue 
,@UserAlias  
,getdate()
,@TotalGIRRNull
end


declare @DiffernceIRR decimal(6,2) = (select @TargetIRR - @TotalGIRR)


if @DiffernceIRR between -0.75 and 0.75 
begin
insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
(  
FundId
,ScenarioId
,InvestmentId
,IRR
,ExitDate
,Exitvalue 
,CreatedBy
,CreatedOn
)

select     
 @FundId         
,@ScenarioId     
,@InvestmentId
,@TargetIRR
,@TargetDate   
,@ResultExitValue 
,@UserAlias  
,getdate()


end

else if @DiffernceIRR > 0.75

begin
--Create cte

DECLARE @cte AS table ([value] decimal (18,2), [Date] DATETIME, ID INT)

INSERT INTO @cte
select case when InvestmentCashflowTypeId in (1,2,4,6) then  - Equity  else Equity end as [value] , EventDate  as [Date]
       , case when InvestmentCashflowTypeId in (1,2,4,6) then 1 else 2 End as ID
from [OPGC].[OpgcInvestmentCashFlow]
      where FundId = @FundId and ScenarioId = @ScenarioId  and InvestmentId in ( select Id from @InvesmentIdBase )
       and Isdeleted = 0 

WHILE( @TotalGIRR + 0.50) <= @TargetIRR
BEGIN
--SET @ResultExitValue = @ResultExitValue * 1.025
SET @ResultExitValue = @ResultExitValue * 1.0035

--SET @ResultExitValue = dateadd(mm,1, @FinalExitDate)

DELETE FROM @Test

INSERT INTO @Test
SELECT [value], [Date] FROM @cte
UNION
SELECT @ResultExitValue, @TargetDate FROM @cte

SELECT @TotalGIRR = CAST(ROUND([OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) --AS GIRR, @SnapshotDate as SnapshotDate
--IF ABS(@target-@resulGirr) <= 0.75
IF ABS(@TargetIRR-@TotalGIRR) <= 0.75
BEGIN
INSERT INTO OPGC.TargetGIRRcalculation
SELECT  @ResultExitValue,@snapshotDate,@TotalGIRR,@TargetIRR,@TargetDate
END
END
DECLARE @searchvalue Decimal (18,2) = (SELECT MIN(ABS(CalulatedGIRR-TagetGIRR)) FROM OPGC.TargetGIRRcalculation WHERE Snapshotdate = @snapshotDate)
select @ResultExitValue = (SELECT top 1 Exitvalue FROM OPGC.TargetGIRRcalculation  WHERE Snapshotdate = @snapshotDate and ABS(CalulatedGIRR-TagetGIRR) = @searchvalue )


--------------Inserting Goal Seek table ----------------------------------------------------

insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
(  
FundId
,ScenarioId
,InvestmentId
,IRR
,ExitDate
,Exitvalue 
,CreatedBy
,CreatedOn
)
select     
 @FundId         
,@ScenarioId     
,@InvestmentId
,@TargetIRR
,@TargetDate  
,@ResultExitValue
,@UserAlias  
,getdate()
End

else if @DiffernceIRR >= -0.75
begin
--Create cte
DECLARE @cteLessThan AS table ([value] decimal (18,2), [Date] DATETIME, ID INT)
INSERT INTO @cteLessThan

select case when InvestmentCashflowTypeId in (1,2,4,6) then  - Equity  else Equity end as [value] , EventDate  as [Date]
       , case when InvestmentCashflowTypeId in (1,2,4,6) then 1 else 2 End as ID
from [OPGC].[OpgcInvestmentCashFlow]
 where FundId = @FundId and ScenarioId = @ScenarioId  and InvestmentId in ( select Id from @InvesmentIdBase )
       and Isdeleted = 0

WHILe( @TotalGIRR + 0.50) > @TargetIRR
BEGIN 

--SET @ResultExitValue = @ResultExitValue / 1.025
SET @ResultExitValue = @ResultExitValue / 1.0035

DELETE FROM @Test

INSERT INTO @Test
SELECT [value], [Date] FROM @cte
UNION
SELECT @ResultExitValue, @TargetDate FROM @cte

SELECT @TotalGIRR = CAST(ROUND([OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) --AS GIRR, @SnapshotDate as SnapshotDate
--IF ABS(@target-@resulGirr) <= 0.75
IF ABS(@TargetIRR-@TotalGIRR) <= 0.75
BEGIN
INSERT INTO OPGC.TargetGIRRcalculation
SELECT  @ResultExitValue,@snapshotDate,@TotalGIRR,@TargetIRR,@TargetDate
END
END

DECLARE @searchvalueLess Decimal (18,2) = (SELECT MIN(ABS(CalulatedGIRR-TagetGIRR)) FROM OPGC.TargetGIRRcalculation WHERE Snapshotdate = @snapshotDate)
select @ResultExitValue = (SELECT top 1 Exitvalue FROM OPGC.TargetGIRRcalculation  WHERE Snapshotdate = @snapshotDate and ABS(CalulatedGIRR-TagetGIRR) = @searchvalueLess )


--------------Inserting Goal Seek table ----------------------------------------------------

insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
(  
FundId
,ScenarioId
,InvestmentId
,IRR
,ExitDate
,Exitvalue 
,CreatedBy
,CreatedOn
)
select     
 @FundId         
,@ScenarioId     
,@InvestmentId
,@TargetIRR
,@TargetDate  
,@ResultExitValue
,@UserAlias  
,getdate()


End

set @GSInvestmentId = ( select top 1 GsInvestmentId from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentID order by 1 desc )

delete from OPGC.TargetGIRRcalculation  where Snapshotdate = @snapshotDate

delete  FROM OPGC.OPGCResultGIRR where Snapshotdate = @snapshotDate

END TRY  
BEGIN CATCH  
 DECLARE @ErrorNumber INT  
 DECLARE @Severity  INT  
 DECLARE @State   INT   
 DECLARE @Procedure  NVARCHAR(250)  
 DECLARE @LineNumber  INT  
 DECLARE @Message  NVARCHAR(MAX)  
 DECLARE @Originator NVARCHAR(250)   
 SELECT   
  @ErrorNumber = ERROR_NUMBER(),  
  @Severity = ERROR_SEVERITY(),  
  @State = ERROR_STATE(),   
  @Procedure = ERROR_PROCEDURE(),  
  @LineNumber = ERROR_LINE(),   
  @Message = ERROR_MESSAGE()     
 EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message,   
       'Database', null, null,null                
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END         
END CATCH
END
