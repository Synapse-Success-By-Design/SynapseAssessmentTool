SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcInvestment](
	[InvestmentId] [int] IDENTITY(1,1) NOT NULL,
	[InvestmentName] [nvarchar](250) NOT NULL,
	[Address] [nvarchar](500) NULL,
	[IndustryId] [int] NOT NULL,
	[CountryId] [int] NOT NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
	[ValidFrom] [datetime2](0) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](0) GENERATED ALWAYS AS ROW END NOT NULL,
	[Isdeleted] [bit] NULL,
	[FundID] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[InvestmentId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [OPGC].[MSSQL_TemporalHistoryFor_942626401] )
)

ALTER TABLE [OPGC].[OpgcInvestment] ADD  CONSTRAINT [df_OpgcInvestment_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
ALTER TABLE [OPGC].[OpgcInvestment] ADD  CONSTRAINT [DF_ValidFrom_Investment1]  DEFAULT (dateadd(second,(-1),sysutcdatetime())) FOR [ValidFrom]
ALTER TABLE [OPGC].[OpgcInvestment] ADD  CONSTRAINT [DF_ValidTo_Investment1]  DEFAULT ('9999.12.31 23:59:59.99') FOR [ValidTo]
ALTER TABLE [OPGC].[OpgcInvestment] ADD  DEFAULT ((0)) FOR [Isdeleted]
ALTER TABLE [OPGC].[OpgcInvestment]  WITH CHECK ADD FOREIGN KEY([FundID])
REFERENCES [OPGC].[OpgcFund] ([FundId])
ALTER TABLE [OPGC].[OpgcInvestment]  WITH CHECK ADD  CONSTRAINT [FK_Investment_CountryId] FOREIGN KEY([CountryId])
REFERENCES [OPGC].[OpgcCountry] ([CountryId])
ALTER TABLE [OPGC].[OpgcInvestment] CHECK CONSTRAINT [FK_Investment_CountryId]
ALTER TABLE [OPGC].[OpgcInvestment]  WITH CHECK ADD  CONSTRAINT [FK_Investment_IndustryId1] FOREIGN KEY([IndustryId])
REFERENCES [OPGC].[OpgcIndustry] ([IndustryId​])
ALTER TABLE [OPGC].[OpgcInvestment] CHECK CONSTRAINT [FK_Investment_IndustryId1]
