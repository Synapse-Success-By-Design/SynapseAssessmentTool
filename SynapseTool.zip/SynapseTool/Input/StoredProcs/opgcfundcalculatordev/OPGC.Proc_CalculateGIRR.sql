SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE Procedure [OPGC].[Proc_CalculateGIRR]-- 1,1,'2016-06-25 05:52:20.640'
(
 @fundid int
,@ScenarioId int
,@SnapshotDate Datetime
)
AS
BEGIN
--DECLARE @fundid int = 1
--DECLARE @ScenarioId int = 1
DECLARE @resultcount INT


DECLARE @ResultGIRR as table ( FundId Int,ScenarioId Int,InvestmentID INT, GIRR DECIMAL (20,9))
DECLARE @GIRR AS TABLE (ScenarioID INT, GIRR DECIMAL (29,9))

DECLARE @cashflowdetails as table (
 FundID INT
,ScenarioId INT
,InvestmentId INT
,InvestmentCashflowID INT
,Equity Decimal (29,9)
,EventDate DateTime)

INSERT INTO @cashflowdetails
--Values (@fundid,@ScenarioId,1,1, 5000, '2016-06-25 05:52:20.640')
--	  ,(@fundid,@ScenarioId,1,2, 2000, '2016-07-25 05:52:20.640')
--	  ,(@fundid,@ScenarioId,1,2, 8000, '2016-08-25 05:52:20.640')
--	  ,(@fundid,@ScenarioId,1,3, 35000,'2025-08-25 05:52:20.640')
--	  ,(@fundid,@ScenarioId,2,1, 8000, '2016-09-25 05:52:20.640')
--	  ,(@fundid,@ScenarioId,2,2, 5000, '2016-10-25 05:52:20.640')
--	  ,(@fundid,@ScenarioId,2,2, 7000, '2016-11-25 05:52:20.640')
--	  ,(@fundid,@ScenarioId,2,3, 45000,'2025-12-25 05:52:20.640')

SELECT FundId, ScenarioId, InvestmentId, InvestmentCashflowTypeId, Equity, EventDate
FROM OPGC.OpgcInvestmentCashFlow WHERE FundId = @fundid and ScenarioId = @ScenarioId and InvestmentCashflowTypeId in (1,2,3,4,5,6,7,8) AND Isdeleted = 0



DECLARE @validate as table (
 Id INT Identity (1,1)
,InvestmentId INT
)
INSERT INTO @validate (InvestmentId)
SELECT InvestmentId FROM @cashflowdetails GROUP BY InvestmentId

DECLARE @investmentID int
DECLARE @min int
DECLARE @max int

SET @min = (SELECT Min(ID) FROM @validate)
SET @max = (SELECT Max(ID) FROM @validate)
SET @investmentID = (Select InvestmentId FROM @validate Where Id = @min)

DECLARE @Test [OPGC].[GIRRTable]
WHILE @min <= @max
BEGIN 

INSERT  @Test
SELECT CASE When InvestmentCashflowID in (1,2,4,6) THEN -(Equity) ELSE Equity end, EventDate FROM @cashflowdetails
WHERE FundID = @fundid and ScenarioId = @ScenarioId and InvestmentId = @investmentID

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @fundid ,@ScenarioId, @investmentID, 
       -- Case When CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else isnull(CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT),0.00) End  AS GIRR,
		 cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
		 
		@SnapshotDate


 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;


SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @ScenarioId and InvestmentID = @investmentID and SnapshotDate = @SnapshotDate)

IF @resultcount = 0 
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@ScenarioId, @investmentID,0.00 AS GIRR, @SnapshotDate
END

DELETE FROM @Test
SET @min = @min + 1
SET @max = (SELECT Max(ID) FROM @validate)
SET @investmentID = (Select InvestmentId FROM @validate Where Id = @min)


END

--SELECT * FROM @ResultGIRR

END




