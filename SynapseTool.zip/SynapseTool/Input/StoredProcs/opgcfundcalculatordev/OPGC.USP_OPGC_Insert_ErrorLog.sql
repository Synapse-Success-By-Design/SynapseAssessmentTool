SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_OPGC_Insert_ErrorLog]

	@ErrorNumber int,
	@ErrorSeverity int,
	@ErrorState int,
	@ErrorProcedure nvarchar(250),
	@ErrorLineNo int,
	@ErrorDescription nvarchar(max),  
	@Originator nvarchar(50),
	@ControllerName nvarchar(250),
	@ActionName nvarchar(250)    ,
	@userdetailid int    
AS
BEGIN
 --======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    03/18/2021 
 --Description    :    
--=========================================================== 
 --History                  
 --Author         :         Date         Description 
 -- [WWMG].[USP_WWMG_Insert_ErrorLog]
--============================================================ 

/*************************************************************************
Purpose
      Insert_ErrorLog

Uses   
     [USP_WWMG_Insert_ErrorLog]                                    SP     

Populates
       [WWMG].[WwmgErrorLog]                                       Table
	   
**************************************************************************/
--INSERT INTO [dbo].[PVIProcessing]([LogTime], [ProcessName], [StepName], [MeasureName], [Measure])
--VALUES(getdate(), 'USP_MSEvents_Insert_ErrorLog', 'START Process', 'Start', 0 );

	INSERT INTO [OPGC].[ErrorLog] 
			(
				[ErrorDate],
				[ErrorNumber],
				[ErrorSeverity],
				[ErrorState],
				[ErrorProcedure],
				[ErrorLineNo],
				[ErrorDescription],
				[Originator],
				[ControllerName],
				[ActionName]   ,
				UserDetailId			
			) 
	VALUES 
			(
				GETDATE(), 
				@ErrorNumber ,
				@ErrorSeverity,
				@ErrorState ,
				@ErrorProcedure ,
				@ErrorLineNo ,
				@ErrorDescription ,
				@Originator ,
				@ControllerName,
				@ActionName ,
				@UserDetailId		
			)
--INSERT INTO [dbo].[PVIProcessing]([LogTime], [ProcessName], [StepName], [MeasureName], [Measure])
--VALUES(getdate(), 'USP_MSEvents_Insert_ErrorLog', 'START Process', 'Start', 0 );
END

