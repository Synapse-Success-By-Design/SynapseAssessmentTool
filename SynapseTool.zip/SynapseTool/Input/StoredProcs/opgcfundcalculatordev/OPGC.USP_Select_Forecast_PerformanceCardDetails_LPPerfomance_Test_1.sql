SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [OPGC].[USP_Select_Forecast_PerformanceCardDetails_LPPerfomance_Test_1] -- '',196,196,63
(
	  @userAlias NVARCHAR(50)	  
	 ,@baseLineScenarioId INT
	 ,@NonBaseLineScenarioId NVARCHAR(10)
	 ,@FundId INT
	
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Appointment Details

Uses   
      [USP_Select_Appointment_GetAppointmentDetails]	    SP

Populates
      [WWMG].[ConfirmedScheduleDetails]			Table
	  [WWMG].[LocationDetails]					Table
	  [WWMG].[UserFamilyDetails]				Table
	  [WWMG].[FamilyDetails_Relations]			Table
**************************************************************************/
BEGIN TRY

SET @NonBaseLineScenarioId = CASE WHEN @NonBaseLineScenarioId IS NULL OR @NonBaseLineScenarioId=0 THEN 0 ELSE @NonBaseLineScenarioId END


DECLARE @NetMOIC_Current DECIMAL(30,2)
DECLARE @NetMOIC_Selected DECIMAL(30,2)
DECLARE @NetIRR_Current DECIMAL(30,2)
DECLARE @NetIRR_selected DECIMAL(30,2)


----------------------------------------------------------MOIC OLd concept--------------------------------------------------------------------------------------------------------
--DECLARE @ExitValuationSelected DECIMAL(18,2) = (SELECT SUM (Equity) from [OPGC].[OpgcInvestmentCashFlow] A JOIN [OPGC].[OpgcScenario] B 
--										   ON A.ScenarioId=B.ScenarioId AND A.FundId=B.FundID WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId  AND
--										   A.InvestmentCashflowTypeId in (3,5,7) --AND B.IsBaseline=0 
--										   and A.Isdeleted=0)

--DECLARE @IntialandFollowupSelected DECIMAL(18,2) =(SELECT SUM (Equity) from [OPGC].[OpgcInvestmentCashFlow] A JOIN [OPGC].[OpgcScenario] B 
--										   ON A.ScenarioId=B.ScenarioId AND A.FundId=B.FundID WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId AND
--										   A.InvestmentCashflowTypeId IN (1,2,4,6) --AND B.IsBaseline=0 
--										   and A.Isdeleted=0)




--IF (ISNULL(@ExitValuationSelected,0) = 0 OR ISNULL(@IntialandFollowupSelected,0)=0) 
--begin

--set @GrossMOIC_Selected=0

--end

--ELSE 

--BEGIN

--set @GrossMOIC_Selected= (@ExitValuationSelected/@IntialandFollowupSelected) 

--END
-----------------------------------------------------------------------NewNet Moic and Net IRR Concept --------- 25-04-2022----------------------------------------------

------------------Current Scenario---------------------------------------------------


-----------------Scenario Level ------------------------------------------------------------------------------------------------------------------------------

declare @InvesmentIdBase as table ( Id int)



;with investmentBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @fundid and ScenarioId = @baseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and 
  FundId = @fundid and ScenarioId = @baseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdBase
select A.InvestmentId from investmentBaseInitial A
join investmentBaseExit B
on A.InvestmentId =B.InvestmentId


declare @CurrentCommittedCapital decimal(30,2) = (select CommittedCapital from   [OPGC].[OpgcScenario] where ScenarioId = @baseLineScenarioId and Isdeleted = 0 )
--select @CommittedCapital as CommittedCapital

declare @CurrentManagementFeePercent decimal(30,5) = (select (ManagementFeePercent/100) from   [OPGC].[OpgcScenario] where ScenarioId = @baseLineScenarioId and Isdeleted = 0 )
select @CurrentManagementFeePercent as ManagementFeePercent

declare @CurrentOtherPartnershipFeesByQuarter decimal(30,2) = (select OtherPartnershipFeesByQuarter from   [OPGC].[OpgcScenario] where ScenarioId = @baseLineScenarioId and Isdeleted = 0 )
select @CurrentOtherPartnershipFeesByQuarter as ManagementFeePercent

declare @CurrentOffsetByQuarter decimal(30,2) = (select OffsetsByQuarter from   [OPGC].[OpgcScenario] where ScenarioId = @baseLineScenarioId and Isdeleted = 0 )
select @CurrentOffsetByQuarter as ManagementFeePercent


declare @CurrentSumOfNegativeInvestment decimal(30,2) = ( select SUM(Equity) from   [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId and ScenarioId = @baseLineScenarioId and InvestmentId in ( select Id from @InvesmentIdBase) and InvestmentCashflowTypeId  in (1,2,4,6) and Isdeleted = 0 )
--select @SumOfNegativeInvestment as SumOfNegativeInvestment

declare @CurrentFundInceptionDate date  = (select FundInceptionDate from   [OPGC].[OpgcScenario] where ScenarioId = @baseLineScenarioId and Isdeleted = 0 )
--select @FundInceptionDate as FundInceptionDate

declare @CurrentManualStepdownDate date  = (select ManualStepdownDate from   [OPGC].[OpgcScenario] where ScenarioId = @baseLineScenarioId and Isdeleted = 0 )
--select @ManualStepdownDate as ManualStepdownDate

declare @CurrentCalculatedManualStepdownDate date  = (select DATEADD(yy,5,FundInceptionDate) from   [OPGC].[OpgcScenario] where ScenarioId = @baseLineScenarioId and Isdeleted = 0 )
--select @CalculatedManualStepdownDate as CalculatedManualStepdownDate

Declare @CurrentMaxDateInvest date = ( select max(Eventdate) from   [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId and InvestmentId in ( select Id from @InvesmentIdBase) and ScenarioId = @baseLineScenarioId and Isdeleted = 0 )

Declare @CurrentMaxDateFund date = ( select max(Eventdate) from   [OPGC].[OpgcFundCashFlow] where FundId =  @FundId and ScenarioId = @baseLineScenarioId and Isdeleted = 0 )

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


--------------InvesmentId------------------------------------------------------------------------------------------




--select * from @InvesmentcashFlow

declare @CurrentPhantomCalculation as table 
(  ID                          int     identity (1,1),
   FundId                      int,
   ScenarioId                  int,
   InvestmentId                 int,
   InvesmentCashFlowTypeId     int,
   CashFlowTypeId              int, 
   IsActual                    int,
   [Status]                      nvarchar(250),
   TypeId                      int,
   CashflowType                nvarchar(250),
   EventDate                   date ,
   --QuarterDate                 date , 
   InvesmentCashFlow           decimal(30,2),
   LimitedPartnerPercent       decimal(5,2),
   LPInvesmentContribution     decimal(30,2),
   LPCostContribution          decimal(30,2),
   GPPercent                  decimal(30,2),
   GPINvesmentContibution     decimal(30,2),
   GPCostContribution     decimal(30,2)
)

declare @cumaltiveNegative as table
(
RN int ,
 EventDate date ,
 InvesmentCashFlow decimal(30,2) ,
 PhantomQuarter decimal(30,2),
 CumaltivePhantom decimal(30,2)
 )

 declare @TemproaryCurrentPhantomCalculation as table 
(  ID                          int     identity (1,1),
   FundId                      int,
   ScenarioId                  int,
   TypeId                      int,
   CashflowType                nvarchar(250),
   EventDate                   date ,
   InvesmentCashFlow           decimal(30,2)
)

 declare @WhileTemproaryCurrentPhantomCalculation as table 
(  ID                          int     identity (1,1),
   FundId                      int,
   ScenarioId                  int,
   TypeId                      int,
   CashflowType                nvarchar(250),
   EventDate                   date ,
   InvesmentCashFlow           decimal(30,2)
)

declare @CurrentLPCostContribution as table 
(  
   FundId                      int,
   ScenarioId                  int,
   InvestmentId                 int,
   InvesmentCashFlowTypeId     int,
   CashFlowTypeId              int, 
   IsActual                    int,
   [Status]                      nvarchar(250),
   TypeId                      int,
   CashflowType                nvarchar(250),
   EventDate                   date ,
   InvesmentCashFlow           decimal(30,2),
   LimitedPartnerPercent       decimal(5,2),
   LPInvesmentContribution     decimal(30,2),
   LPCostContribution          decimal(30,2),
   GPPercent                  decimal(30,2),
   GPINvesmentContibution     decimal(30,2),
   GPCOstContribution         decimal(30,2)
)

declare @CurrentInvesmentcashFlow as table 
(  FundId                      int,
   ScenarioId                  int,
   InvestmentId                 int,
   InvesmentCashFlowTypeId     int,
   IntialEquity                decimal(30,2),
   IntialLPInvesmentContribution     decimal(30,2)
   )



Declare @CurrentLPInvestReturn as table
(
Id int identity(1,1),
InvesmentId int,
invesmentCashFlowTypeId int,
IsActual int,
EventDate date,
LPInvestContribution decimal(30,2),
InvestCashFlow decimal(30,2),
InitialLPInvest decimal(30,2)
)

Declare @CurrentFinalLPInvestReturn as table
(
Id int ,
InvesmentId int,
invesmentCashFlowTypeId int,
IsActual int,
EventDate date,
LPInvestContribution decimal(30,2),
InvestCashFlow decimal(30,2),
InitialLPInvest decimal(30,2),
--SumOfNegative decimal(30,2),
LPInvestmentReturn decimal(30,2)
)

declare @CurrentCumalativeLPCostReturn as table 
(  ID                             int identity(1,1),
   FundId                         int,
   ScenarioId                     int,
   InvestmentId                   int,
   InvesmentCashFlowTypeId        int,
   CashFlowTypeId                 int, 
   IsActual                       int,
   [Status]                       nvarchar(250),
   TypeId                         int,
   CashflowType                   nvarchar(250),
   EventDate                      date ,
   InvesmentCashFlow              decimal(30,2),
   LimitedPartnerPercent          decimal(5,2),
   LPInvesmentContribution        decimal(30,2),
   LPCostContribution             decimal(30,2),
   IntialEquity                   decimal(30,2),
   InitialLPInvesmentContribution  decimal(30,2),
   LPInvesmentReturn              decimal(30,2),
   RemainLPInvesmentReturnSteps   decimal(30,2),
   CumaltiveLPCostContibution          decimal(30,2),
   GPPercent                  decimal(30,2),
   GPINvesmentContibution     decimal(30,2),
   GPCOstContribution         decimal(30,2)
)

declare @CurrentLPCostReturn as table 
( 
   ID                             int ,
   FundId                         int,
   ScenarioId                     int,
   InvestmentId                   int,
   InvesmentCashFlowTypeId        int,
   CashFlowTypeId                 int, 
   IsActual                       int,
   [Status]                       nvarchar(250),
   TypeId                         int,
   CashflowType                   nvarchar(250),
   EventDate                      date ,
   InvesmentCashFlow              decimal(30,2),
   LimitedPartnerPercent          decimal(5,2),
   LPInvesmentContribution        decimal(30,2),
   LPCostContribution             decimal(30,2),
   LPInvesmentReturn              decimal(30,2),
   RemainLPInvesmentReturnSteps   decimal(30,2),
   LPCostReturn                   decimal(30,2),
   CumalativeLPCostContibution     decimal(30,2),
   RemainLPCostReturn             decimal(30,2),
   GPPercent                  decimal(30,2),
   GPINvesmentContibution     decimal(30,2),
   GPCOstContribution         decimal(30,2)
)

declare @CurrentFinalLPCostReturn as table 
( 
   ID                             int ,
   FundId                         int,
   ScenarioId                     int,
   InvestmentId                   int,
   InvesmentCashFlowTypeId        int,
   CashFlowTypeId                 int, 
   IsActual                       int,
   [Status]                       nvarchar(250),
   TypeId                         int,
   CashflowType                   nvarchar(250),
   EventDate                      date ,
   InvesmentCashFlow              decimal(30,2),
   LimitedPartnerPercent          decimal(5,2),
   LPInvesmentContribution        decimal(30,2),
   LPCostContribution             decimal(30,2),
   LPInvesmentReturn              decimal(30,2),
   RemainLPInvesmentReturnSteps   decimal(30,2),
   LPCostReturn                   decimal(30,2),
   CumalativeLPCostContibution     decimal(30,2),
   RemainLPCostReturn             decimal(30,2),
   CumaltiveNetLPContibution     decimal(30,2),
   GPPercent                     decimal(30,2),
   GPINvesmentContibution        decimal(30,2),
   GPCOstContribution             decimal(30,2),
   TotalGPContribution            decimal(30,2),
   TotalGPReturn                  decimal(30,2),  
   NetGPContribution			  decimal(30,2),
   CumaltiveNetGPContibution	  decimal(30,2),
   LPPreferredReturnThreshold    decimal(30,2),
   LPPreferrefReturn             decimal(30,2),
   RemainLPPreferrefReturn       decimal(30,2),
   GPPreferredReturnThreshold    decimal(30,2),
   GPPreferrefReturn             decimal(30,2),
   RemainGPPreferrefReturn       decimal(30,2),
   FinalLPReturn                decimal(30,2),
   FinalGPReturn                decimal(30,2),
   TotalLPContibution             decimal(30,2),
   TotalLPReturn                  decimal(30,2),
   NetLPContribution              decimal(30,2)
) 



--declare @CurrentTempGPCostContribution as table ( 
--Id int ,
--value decimal(30,2)
--)

--insert into @CurrentTempGPCostContribution values
--(6,-11),(7,-3),(8,11),(9,3),(10,-10),(11,-2)

--IF @CurrentMaxDateInvest > @CurrentMaxDateFund
--begin


---------insert into Invesment level to find  LP Invesment contribution ---------------------------------------------------------------------


insert into @CurrentPhantomCalculation 
( FundId , ScenarioId,InvestmentId   , InvesmentCashFlowTypeId,IsActual ,Status , EventDate  , InvesmentCashFlow , LimitedPartnerPercent,LPInvesmentContribution,GPPercent , GPINvesmentContibution  )

select FundId , ScenarioId ,InvestmentId    , InvestmentCashflowTypeId ,IsActual , case when IsActual = 1 Then 'Actual' else 'Hypothetical' end Status ,EventDate  ,
      case when InvestmentCashflowTypeId IN (1,2,4,6) then (-1 *Equity)
	       when InvestmentCashflowTypeId IN (3,5,7,8) then (Equity) end as Equity  ,
	  LimitedPartnerPercent,
      case when IsActual = 1 and InvestmentCashflowTypeId IN  (1,2,4,6)  
	            then cast ( -1 *( (Equity * LimitedPartnerPercent) / 100 )  as decimal(30,2)) 
           when IsActual = 1 and InvestmentCashflowTypeId IN (3,5,7,8)  
	            then cast ( (Equity * LimitedPartnerPercent) / 100  as decimal(30,2)) 
           when IsActual = 0 and InvestmentCashflowTypeId IN (1,2,4,6) 
		        then cast ( -1 * ( (Equity * LimitedPartnerPercent) / 100 )  as decimal(30,2))
       else 0.00 End LPInvesmentContribution ,
	   (100 - LimitedPartnerPercent ) as GPPercent ,
	   case when IsActual = 1 and InvestmentCashflowTypeId IN (1,2,4,6) 
	            then cast ( -1 *( (Equity * (100 - LimitedPartnerPercent )) / 100 )  as decimal(30,2)) 
           when IsActual = 1 and InvestmentCashflowTypeId IN (3,5,7,8)  
	            then cast ( (Equity * (100 - LimitedPartnerPercent )) / 100  as decimal(30,2)) 
           when IsActual = 0 and InvestmentCashflowTypeId IN (1,2,4,6) 
		        then cast ( -1 * ( (Equity * (100 - LimitedPartnerPercent )) / 100 )  as decimal(30,2))
       else 0.00 End GPInvesmentContribution 
from   [OPGC].[OpgcInvestmentCashFlow] 
where FundId =  @FundId and ScenarioId = @baseLineScenarioId and InvestmentId in ( select Id from @InvesmentIdBase) and InvestmentCashflowTypeId not in (100) and Isdeleted = 0
order by EventDate asc

--select * from @PhantomCalculation

---------To Insert ditinct Invesment id for initial CAsh flow -------------------------------------------------------------------------

insert into @CurrentInvesmentcashFlow 
select  FundId , ScenarioId ,InvestmentId    , InvesmentCashFlowTypeId , InvesmentCashFlow , LPInvesmentContribution
from   @CurrentPhantomCalculation 
where FundId =  @FundId and ScenarioId = @baseLineScenarioId and InvesmentCashFlowTypeId  in (1) 

--select * from @InvesmentcashFlow

-------------------To find LP cost contribution FUnd level ----------------------------------------------------------------------------------------------

insert into @CurrentPhantomCalculation ( FundId , ScenarioId   , CashFlowTypeId ,IsActual ,  Status, EventDate, LimitedPartnerPercent , LPCostContribution,GPCostContribution )

select FundId , ScenarioId  , FundCashflowTypeId, IsActual , case when IsActual = 1 Then 'Actual' else 'Hypothetical' end Status , EventDate ,LimitedPartnerPercent 
       , case when FundCashflowTypeId in (6,7) then -1 *( (ValueAmount * LimitedPartnerPercent) / 100 )  else ( (ValueAmount * LimitedPartnerPercent) / 100 ) end
	  , case when FundCashflowTypeId in (6,7) then -1 * ( (1-LimitedPartnerPercent/100) * ValueAmount )  
	         when FundCashflowTypeId in (8,9) then   ( (1-LimitedPartnerPercent/100) * ValueAmount ) 
			 else 0.00 end
	  -- ,ValueAmount
from  [OPGC].[OpgcFundCashFlow] 
where FundId =  @FundId and ScenarioId = @baseLineScenarioId  and Isdeleted = 0
order by EventDate asc

-----



;with cumaltiveNegative
as
(
select Row_number()over( order by EventDate) as RN, EventDate,InvesmentCashFlow ,
case when InvesmentCashFlowTypeId in (1,2,4,6) then InvesmentCashFlow else 0.00 end as PhantomQuarter
 from @CurrentPhantomCalculation

)

insert into @cumaltiveNegative
select * , Sum (PhantomQuarter) Over (Order By RN) as CumaltivePhantom from cumaltiveNegative
order by EventDate asc

select * from @cumaltiveNegative

declare @CurrentInitialCheckInvesmentCashflowTypeId int = ( select   count(1) from @CurrentPhantomCalculation where   InvesmentCashFlowTypeID in (3,5,7,8) )

if @CurrentInitialCheckInvesmentCashflowTypeId > 0
begin

;with CurrentLPInvestReturn
as
(
select   
 A.InvestmentId
,A.InvesmentCashFlowTypeId
,A.IsActual                                      
,A.EventDate                 
,A.LPInvesmentContribution
,case when A.InvesmentCashFlowTypeId IN (1,2,4,6) then 0.00
      when A.Isactual = 0 and A.InvesmentCashFlowTypeId IN (3,5,7,8) then A.InvesmentCashFlow
	  when A.Isactual = 1 and A.InvesmentCashFlowTypeId IN (3,5,7,8) then null end as InvesmentCashFlow
,B.IntialLPInvesmentContribution
 
from @CurrentPhantomCalculation A
left join @CurrentInvesmentcashFlow B
on A.FundId = B.FundId and A.ScenarioId = B.ScenarioId and A.InvestmentId = B.InvestmentId
where A.InvesmentCashFlowTypeId in (1,2,3,4,5,6,7,8)
)

insert into @CurrentLPInvestReturn ( 
InvesmentId                
,invesmentCashFlowTypeId    
,IsActual                   
,EventDate                  
,LPInvestContribution       
,InvestCashFlow             
,InitialLPInvest            
)

select   
 InvestmentId
,InvesmentCashFlowTypeId
,IsActual                                      
,EventDate                 
,LPInvesmentContribution
, abs(InvesmentCashFlow) as InvesmentCashFlow
,abs(IntialLPInvesmentContribution) as IntialLPInvesmentContribution
from CurrentLPInvestReturn 
--where InvesmentCashFlow is not null
order by InvestmentId ,EventDate asc


--select * from @CurrentLPInvestReturn




------------------------------

----------To Find First date for Phantom Calculation ---for positive cash flow inesment level and isactual is 0-------------------------------------------------

declare @CurrentInvesmnetInitialDate date = ( select DATEADD(q, DATEDIFF(q, 0, min(EventDate)), 0)  from  [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId 
                                              and ScenarioId = @baseLineScenarioId and InvestmentId in ( select Id from @InvesmentIdBase) and InvestmentCashflowTypeId = 1 and Isdeleted = 0)
--select @InvesmnetInitialDate as InvesmnetInitialDate

declare @CurrentInvesmentMaxDate date = ( select DATEADD(q, DATEDIFF(q, 0, Max(EventDate)), 0) from  [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId 
                                          and ScenarioId = @baseLineScenarioId and InvestmentId in ( select Id from @InvesmentIdBase) and Isdeleted =0 )
--select @InvesmentMaxDate as InvesmentMaxDate


declare @CurrentFundMaxDate date = ( select DATEADD(q, DATEDIFF(q, 0, Max(EventDate)), 0) from  [OPGC].[OpgcFundCashFlow] where FundId =  @FundId 
                                      and ScenarioId = @baseLineScenarioId  and Isdeleted =0  )
--select @FundMaxDate as FundMaxDate


---------To Find Date  for Phantom ---------------------------------------------------------

--If @CurrentFundMaxDate is not null
--begin 


--	;with CurrentManagmentFees as
--	(
--	   select   1 r,@CurrentFundMaxDate s , -3 as TypeId , 'Managment Fees' as CashflowType
--	   union all 
--	   select r+1, DATEADD(qq,1,s) ,-3 as TypeId , 'Managment Fees' as CashflowType  from CurrentManagmentFees where r<=datediff(qq,@CurrentFundMaxDate,@CurrentInvesmentMaxDate) 
--	)




--	insert into @CurrentPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
--	select @FundId , @baseLineScenarioId ,  
--	TypeId, CashflowType , s from CurrentManagmentFees 
--	where  r not in(1)
--	option (maxrecursion 1000)


---------------------------------------------------Other Partnership Expenses------------------------------------------------------------------

--	;with CurrentOtherPartnerShipExpenses as
--	(
--	   select   1 r,@CurrentFundMaxDate s , -2 as TypeId , 'Other PartnerShip Expenses' as CashflowType
--	   union all 
--	   select r+1, DATEADD(qq,1,s) , -2 as TypeId , 'Other PartnerShip Expenses' as CashflowType   from CurrentOtherPartnerShipExpenses where r<=datediff(qq,@CurrentFundMaxDate,@CurrentInvesmentMaxDate) 
--	)

--	insert into @CurrentPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
--	select  @FundId , @baseLineScenarioId ,  TypeId, CashflowType , s from CurrentOtherPartnerShipExpenses where  r not in(1)
--	option (maxrecursion 1000)

-----------------------------------------------------------OffsetByQuarter------------------------------------------------------------------------------


--	;with CurrentOffsetBYQuarter as
--	(
--	   select   1 r,@CurrentFundMaxDate s , -1 as TypeId , 'Offset By Quarter' as CashflowType
--	   union all 
--	   select r+1, DATEADD(qq,1,s) , -1 as TypeId , 'Offset By Quarter' as CashflowType   from CurrentOffsetBYQuarter where r<=datediff(qq,@CurrentFundMaxDate,@CurrentInvesmentMaxDate) 
--	)

--	insert into @CurrentPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
--	select  @FundId , @baseLineScenarioId ,  TypeId, CashflowType , s from CurrentOffsetBYQuarter where  r not in(1)
--	option (maxrecursion 1000)


--end
--else 
--begin



--	;with CurrentManagmentFees as
--	(
--	   select   1 r,@CurrentInvesmnetInitialDate s , -3 as TypeId , 'Managment Fees' as CashflowType
--	   union all 
--	   select r+1, DATEADD(qq,1,s) ,-3 as TypeId , 'Managment Fees' as CashflowType  from CurrentManagmentFees where r<=datediff(qq,@CurrentInvesmnetInitialDate,@CurrentInvesmentMaxDate) 
--	)

--	insert into @CurrentPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
--	select  @FundId , @baseLineScenarioId ,  TypeId, CashflowType , s from CurrentManagmentFees where  r not in(1)
--	option (maxrecursion 1000)


---------------------------------------------------Other Partnership Expenses------------------------------------------------------------------

--	;with CurrentOtherPartnerShipExpenses as
--	(
--	   select   1 r,@CurrentInvesmnetInitialDate s , -2 as TypeId , 'Other PartnerShip Expenses' as CashflowType
--	   union all 
--	   select r+1, DATEADD(qq,1,s) , -2 as TypeId , 'Other PartnerShip Expenses' as CashflowType   from CurrentOtherPartnerShipExpenses where r<=datediff(qq,@CurrentInvesmnetInitialDate,@CurrentInvesmentMaxDate) 
--	)

--	insert into @CurrentPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
--	select  @FundId , @baseLineScenarioId ,  TypeId, CashflowType , s from CurrentOtherPartnerShipExpenses where  r not in(1)
--	option (maxrecursion 1000)

-----------------------------------------------------------OffsetByQuarter------------------------------------------------------------------------------


--	;with CurrentOffsetBYQuarter as
--	(
--	   select   1 r,@CurrentInvesmnetInitialDate s , -1 as TypeId , 'Offset By Quarter' as CashflowType
--	   union all 
--	   select r+1, DATEADD(qq,1,s) , -1 as TypeId , 'Offset By Quarter' as CashflowType   from CurrentOffsetBYQuarter where r<=datediff(qq,@CurrentInvesmnetInitialDate,@CurrentInvesmentMaxDate) 
--	)

--	insert into @CurrentPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
--	select  @FundId , @baseLineScenarioId ,  TypeId, CashflowType , s from CurrentOffsetBYQuarter where  r not in(1)
--	option (maxrecursion 1000)


--end

----------------------------------Temproary--------------------------------

If @CurrentFundMaxDate is not null
begin 


	;with CurrentManagmentFees as
	(
	   select   1 r,@CurrentFundMaxDate s , -3 as TypeId , 'Managment Fees' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) ,-3 as TypeId , 'Managment Fees' as CashflowType  from CurrentManagmentFees where r<=datediff(qq,@CurrentFundMaxDate,@CurrentInvesmentMaxDate) 
	)




	insert into @TemproaryCurrentPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select @FundId , @baseLineScenarioId ,  
	TypeId, CashflowType , s from CurrentManagmentFees 
	where  r not in(1)
	option (maxrecursion 1000)
end
else 
begin



	;with CurrentManagmentFees as
	(
	   select   1 r,@CurrentInvesmnetInitialDate s , -3 as TypeId , 'Managment Fees' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) ,-3 as TypeId , 'Managment Fees' as CashflowType  from CurrentManagmentFees where r<=datediff(qq,@CurrentInvesmnetInitialDate,@CurrentInvesmentMaxDate) 
	)

	insert into @TemproaryCurrentPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @FundId , @baseLineScenarioId ,  TypeId, CashflowType , s from CurrentManagmentFees where  r not in(1)
	option (maxrecursion 1000)
end



--select * from @TemproaryCurrentPhantomCalculation

declare @PhantomMinId int  = (select Min(ID) from @TemproaryCurrentPhantomCalculation )
declare @PhantomMaxId int  = (select Max(ID) from @TemproaryCurrentPhantomCalculation )

while @PhantomMinId <= @PhantomMaxId
begin

set @PhantomMinId = @PhantomMinId
--select @PhantomMinId

declare @TemproaryCurrentEvendate  date  = ( select Eventdate from @TemproaryCurrentPhantomCalculation where ID =  @PhantomMinId )
--select @TemproaryCurrentEvendate
declare @TemproarySumofNegative int =   ( select Max(abs(CumaltivePhantom)) from @cumaltiveNegative where EventDate <=  @TemproaryCurrentEvendate  )
--set @TemproarySumofNegative = -1 * @TemproarySumofNegative
--select @TemproarySumofNegative 

insert into @WhileTemproaryCurrentPhantomCalculation ( FundId,ScenarioId,TypeId,CashflowType,Eventdate , InvesmentCashflow)

select FundId,ScenarioId,TypeId,CashflowType,Eventdate
, InvesmentCashflow = case when @CurrentManualStepdownDate IS null   and  EventDate < @CurrentCalculatedManualStepdownDate
                                then  cast ( ( (-1 * (@CurrentCommittedCapital * @CurrentManagementFeePercent)/4  ) - @CurrentOtherPartnershipFeesByQuarter + @CurrentOffsetByQuarter ) as decimal(30,2) )
							When @CurrentManualStepdownDate IS null and  EventDate >= @CurrentCalculatedManualStepdownDate
                                then cast ( ( (-1 *(@TemproarySumofNegative * @CurrentManagementFeePercent)/4  ) - @CurrentOtherPartnershipFeesByQuarter +  @CurrentOffsetByQuarter ) as decimal(30,2) )
							When @CurrentManualStepdownDate is not null  and  EventDate < @CurrentManualStepdownDate
                                then cast ( ( (-1 * (@CurrentCommittedCapital * @CurrentManagementFeePercent)/4  ) - @CurrentOtherPartnershipFeesByQuarter +  @CurrentOffsetByQuarter ) as decimal(30,2) )
							When @CurrentManualStepdownDate is not null  and  EventDate >= @CurrentManualStepdownDate
                                then  cast ( ( (-1 *(@TemproarySumofNegative * @CurrentManagementFeePercent)/4  ) - @CurrentOtherPartnershipFeesByQuarter +  @CurrentOffsetByQuarter ) as decimal(30,2) )
       --                     when TypeId = -2 then -1 * cast ( @CurrentOtherPartnershipFeesByQuarter as decimal(30,2))
							--when TypeId = -1 then cast ( @CurrentOffsetByQuarter as decimal(30,2))
                       Else  InvesmentCashflow  end
from @TemproaryCurrentPhantomCalculation
where ID = @PhantomMinId

set @PhantomMinId = @PhantomMinId + 1

end

select * from @WhileTemproaryCurrentPhantomCalculation

insert into @CurrentLPCostContribution

(
 FundId                      
 ,ScenarioId                                    
 ,TypeId                      
 ,CashflowType                
 ,EventDate                                            
 ,LPInvesmentContribution     
 ,LPCostContribution
 , GPINvesmentContibution 
 )

 select FundId,
        ScenarioId,
		TypeId,
		CashflowType,
		Eventdate,
		cast ( 0.00 as decimal(30,2)),
		InvesmentCashflow,
		cast ( 0.00 as decimal(30,2))
from @WhileTemproaryCurrentPhantomCalculation


--------------------------------

insert into @CurrentLPCostContribution
(
 FundId                      
 ,ScenarioId                  
 ,InvestmentId                
 ,InvesmentCashFlowTypeId     
 ,CashFlowTypeId              
 ,IsActual                    
 ,[Status]                    
 ,TypeId                      
 ,CashflowType                
 ,EventDate                                
 ,InvesmentCashFlow           
 ,LimitedPartnerPercent       
 ,LPInvesmentContribution     
 ,LPCostContribution
 ,GPPercent
 , GPINvesmentContibution 
 ,GPCOstContribution
 )


select 
 A.FundId                 
,A.ScenarioId   
,A.InvestmentId
,A.InvesmentCashFlowTypeId
,A.CashFlowTypeId 
,A.IsActual
,A.Status                 
,A.TypeId
,A.CashflowType           
,A.EventDate 
--,QuarterDate            
,A.InvesmentCashFlow      
,A.LimitedPartnerPercent  
,isnull (A.LPInvesmentContribution,0.00) as  LPInvesmentContribution
, LPCostContribution 
 ,A.GPPercent
 , A.GPINvesmentContibution 
 ,isnull(A.GPCostContribution,0.00)
from @CurrentPhantomCalculation A


--;with cumaltiveNegative
--as
--(
--select 
--case when InvesmentCashFlowTypeId in (1,2,4,6) then InvesmentCashFlow else 0.00 end as PhantomQuarter,
--* from @CurrentPhantomCalculation

--)

--select Sum (PhantomQuarter) Over (Order By EventDate) as CumaltivePhantom , InvesmentCashFlow , EventDate  from cumaltiveNegative
--order by EventDate asc

--;with cumaltiveNegative
--as
--(
--select Row_number()over( order by EventDate) as RN ,case when InvesmentCashFlowTypeId in (1,2,4,6) then InvesmentCashFlow else 0.00 end as PhantomQuarter , 
--* from @CurrentPhantomCalculation
----order by EventDate
--)

--select Sum (PhantomQuarter) Over (Order By RN) as CumaltivePhantom , * from cumaltiveNegative
--order by EventDate
----------------------To Find LP Cost Contribution-----for phantom data-------------------------------------------------------------------------------------------------------------------------------------------------------------------

--declare @PhantomMinId int  = (select Min(ID) from @CurrentPhantomCalculation )
--declare @PhantomMaxId int  = (select Min(ID) from @CurrentPhantomCalculation )

--while @PhantomMinId = @PhantomMaxId
--begin

--if 


--end




--insert into @CurrentLPCostContribution
--(
-- FundId                      
-- ,ScenarioId                  
-- ,InvestmentId                
-- ,InvesmentCashFlowTypeId     
-- ,CashFlowTypeId              
-- ,IsActual                    
-- ,[Status]                    
-- ,TypeId                      
-- ,CashflowType                
-- ,EventDate                                
-- ,InvesmentCashFlow           
-- ,LimitedPartnerPercent       
-- ,LPInvesmentContribution     
-- ,LPCostContribution
-- ,GPPercent
-- , GPINvesmentContibution 
-- ,GPCOstContribution
-- )


--select 
-- A.FundId                 
--,A.ScenarioId   
--,A.InvestmentId
--,A.InvesmentCashFlowTypeId
--,A.CashFlowTypeId 
--,A.IsActual
--,A.Status                 
--,case when A.TypeId is null and InvesmentCashFlowTypeId  = 1 then 1 
--      when A.TypeId is null and InvesmentCashFlowTypeId  = 2 then 2 
--	  when A.TypeId is null and InvesmentCashFlowTypeId  = 3 then 3
--	  when A.TypeId is null and InvesmentCashFlowTypeId  = 4 then 4
--	  when A.TypeId is null and InvesmentCashFlowTypeId  = 5 then 5
--	  when A.TypeId is null and InvesmentCashFlowTypeId  = 6 then 6
--	  when A.TypeId is null and InvesmentCashFlowTypeId  = 7 then 7
--	  when A.TypeId is null and InvesmentCashFlowTypeId  = 8 then 8
--	  when A.TypeId is null and CashFlowTypeId  = 6 then 9
--	  when A.TypeId is null and CashFlowTypeId  = 7 then 10
--	  when A.TypeId is null and CashFlowTypeId  = 8 then 11
--	  when A.TypeId is null and CashFlowTypeId  = 9 then 12
--	  when A.TypeId is not null  then A.TypeId end 
--,A.CashflowType           
--,A.EventDate 
----,QuarterDate            
--,A.InvesmentCashFlow      
--,A.LimitedPartnerPercent  
--,isnull (A.LPInvesmentContribution,0.00) as  LPInvesmentContribution
--, LPCostContribution = case when @CurrentManualStepdownDate IS null and TypeId = -3  and  A.EventDate < @CurrentCalculatedManualStepdownDate
--                                then  -1 * cast ( (@CurrentCommittedCapital * @CurrentManagementFeePercent)/4 as decimal(30,2) )
--							When @CurrentManualStepdownDate IS null and A.TypeId = -3 and  A.EventDate >= @CurrentCalculatedManualStepdownDate
--                                then -1 * cast ((@CurrentSumOfNegativeInvestment * @CurrentManagementFeePercent)/4 as decimal(30,2) )
--							When @CurrentManualStepdownDate is not null and A.TypeId = -3 and  A.EventDate < @CurrentManualStepdownDate
--                                then -1* cast ((@CurrentCommittedCapital * @CurrentManagementFeePercent)/4 as decimal(30,2))
--							When @CurrentManualStepdownDate is not null and A.TypeId = -3 and  A.EventDate >= @CurrentManualStepdownDate
--                                then  -1 * cast ((@CurrentSumOfNegativeInvestment * @CurrentManagementFeePercent)/4  as decimal(30,2))
--                            when A.TypeId = -2 then -1 * cast ( @CurrentOtherPartnershipFeesByQuarter as decimal(30,2))
--							when A.TypeId = -1 then cast ( @CurrentOffsetByQuarter as decimal(30,2))
--                       Else  LPCostContribution  end
-- ,A.GPPercent
-- , A.GPINvesmentContibution 
-- ,isnull(A.GPCostContribution,0.00)
--from @CurrentPhantomCalculation A
----left Join @CurrentTempGPCostContribution B
----On A.CashFlowTypeId = B.Id or A.TypeId = B.Id
--order by A.EventDate ,A.TypeId asc

select * from @CurrentLPCostContribution
order by EventDate  asc

-------------------------CHeck Invesment cashflow type id for postive cashflow ,is there present is actual status should be 0 then enter into waterfall calculation
---otherwise direct calculation in else block

declare @CurrentCheckInvesmentCashflowTypeId int = ( select   count(1) from @CurrentLPCostContribution where  IsActual = 0 and InvesmentCashFlowTypeID in (3,5,7,8) )

--select @CurrentCheckInvesmentCashflowTypeId as CurrentCheckInvesmentCashflowTypeId

If @CurrentCheckInvesmentCashflowTypeId > 0
begin

-------------------------Water Fall :-  Step 1 LP Invest Calculation--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


declare @CurrentInvestmentIdValidate as table 
(Id int identity(1,1) , 
InvesmentId int)

insert into @CurrentInvestmentIdValidate   (InvesmentId)
select
InvesmentId from @CurrentLPInvestReturn group by InvesmentId

--select * from @InvestmentIdValidate
declare  @CurrentMinInvesmentId int = (select Min(Id) from @CurrentInvestmentIdValidate)
declare  @CurrentMaxInvesmentId int = (select Max(Id) from @CurrentInvestmentIdValidate)
declare  @CurrentInvesmentId int = (select InvesmentId from @CurrentInvestmentIdValidate where Id = @CurrentMinInvesmentId )
--select @MaxInvesmentId


while @CurrentMinInvesmentId <= @CurrentMaxInvesmentId
begin


declare @CurrentMinInitail date = (select MIN(EventDate) from @CurrentLPInvestReturn where InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId = 1 )
--select @MinInitail as MinInitail

declare @CurrentMinPositiveDate date = (select MIN(EventDate) from @CurrentLPInvestReturn where   InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and IsActual =0 )
--select @MinPositiveDate as MinPositiveDate

	  declare @CurrentNegativeValue decimal(30,2)  = (select abs(sum(isnull(LPInvestContribution,0.00))) from @CurrentLPInvestReturn where InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId in (1,2,4,6) and EventDate between @CurrentMinInitail and @CurrentMinPositiveDate)
	 -- select @CurrentNegativeValue as NegativeValue
      
	  declare @CurrentPositiveValue decimal(30,2)  = (select abs(sum(isnull(LPInvestContribution,0.00))) from @CurrentLPInvestReturn where InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and EventDate between @CurrentMinInitail and @CurrentMinPositiveDate)
	  --select @CurrentPositiveValue as PositiveValue

	  declare @CurrentFinalValue decimal(30,2) = ( select abs(@CurrentNegativeValue - @CurrentPositiveValue) )
	--  select @CurrentFinalValue as CurrentFinalValue


declare @CurrentMinPositiveId int = ( select Min(ID) from @CurrentLPInvestReturn where InvesmentId = @CurrentInvesmentId and EventDate = @CurrentMinPositiveDate and IsActual =0 )
--select @MinPositiveID as MinPositiveID

declare @CurrentMaxId int = ( select max(ID) from @CurrentLPInvestReturn )
--select @MinPositiveID as MinPositiveID


declare @CurrentMinLP decimal(30,2) = (select min(LPInvestContribution) from @CurrentLPInvestReturn where InvesmentId = @CurrentInvesmentId and EventDate = @CurrentMinInitail) 
--select @MInLP as MInLP

--declare @CurrentsumofNegative decimal(30,2) = (select isnull(SUM(LPInvestContribution),0.00) from @CurrentLPInvestReturn  where InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId in (2,4,6)) 
----select @sumofNegative as sumofNegative

insert into @CurrentFinalLPInvestReturn

select *
, case when Id = @CurrentMinPositiveId and InvestCashFlow > @CurrentFinalValue Then  @CurrentFinalValue
       when Id = @CurrentMinPositiveId and InvestCashFlow < @CurrentFinalValue Then InvestCashFlow 
	   when Id = @CurrentMinPositiveId and InvestCashFlow = @CurrentFinalValue Then @CurrentFinalValue
	   else NULL end as LPCost
from @CurrentLPInvestReturn
where InvesmentId = @CurrentInvesmentId 

--select * from @CurrentFinalLPInvestReturn

declare @CurrentCheckLPCost decimal(30,2) = ( select abs(LPInvestmentReturn) from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId )
--select @CheckLPCost as CheckLPCost

--declare @CurrentRemainingLPInvest decimal(30,2) = ( select case when InvestCashFlow < InitialLPInvest then (InitialLPInvest - InvestCashFlow) else 0.00 end from @CurrentFinalLPInvestReturn 
--                                                    where Id = @CurrentMinPositiveId )

declare @CurrentRemainingLPInvest decimal(30,2) = ( select @CurrentFinalValue - @CurrentCheckLPCost )

--select @CurrentRemainingLPInvest


--select @RemainingLPInvest as RemainingLPInvest

--declare  @BalanceSumofNegative decimal(30,2) = (select @sumofNegative + @RemainingLPInvest)

--select @BalanceSumofNegative as BalnacesumofNegative

--declare @CurrentFinalSumofNegative decimal(30,2) = (select @CurrentsumofNegative )

	set @CurrentMinPositiveID = @CurrentMinPositiveID + 1

--------------------------------------------------------------------------------------------------


	--select Id from @FinalLPInvestReturn where Id >= @MinPositiveID and invesmentCashFlowTypeId in (2,4,6)

              while @CurrentMinPositiveID <= @CurrentMaxId
			
              begin
			  --select @MinPositiveID as MinPositiveID

		--	  declare @CheckNegativeId  int = ( select count(1) from @FinalLPInvestReturn where Id = @MinPositiveID and invesmentCashFlowTypeId in (2,4,6) )
		--select @CheckNegativeId
		--	   declare @CheckPositiveId  int = ( select count(1) from @FinalLPInvestReturn where Id = @MinPositiveID and invesmentCashFlowTypeId in (3,5,7,8) and IsActual = 1 )
		--	  select @CheckPositiveId



			  set @CurrentRemainingLPInvest = @CurrentRemainingLPInvest
			--  select @RemainingLPInvest as RemainingLPInvest

		--	  if @CheckNegativeId = 1 or @CheckPositiveId = 1
		--	  begin
		--	  	 set @NegativeValue   = (select abs(sum(isnull(LPInvestContribution,0.00))) from @LPInvestReturn where InvesmentId = @InvesmentId and invesmentCashFlowTypeId in (2,4,6) and EventDate = @MinPositiveDate)
	 --            Set @PositiveValue   = (select abs(sum(isnull(LPInvestContribution,0.00))) from @LPInvestReturn where InvesmentId = @InvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and EventDate = @MinPositiveDate and IsActual = 1)
	 --            set @RemainingLPInvest = @RemainingLPInvest + @NegativeValue - @PositiveValue
		--	  end

			  declare @CurrentPositiveIsactual int = ( select count(1) from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId  and invesmentCashFlowTypeId in (3,5,7,8) and IsActual = 0)

			--  select @PositiveIsactual as PositiveIsactual

----------------------------------------------------------------------------------------------------------------
             declare @CurrentCheckRemainingLPInvest decimal(30,2)
			 declare @CurrentInvestCashFlow decimal(30,2)
			          If @CurrentMinPositiveID = @CurrentMinPositiveID and @CurrentPositiveIsactual = 1			 
			          
					  begin
					      declare @CurrentCheckPreviousLPInvestReturn decimal(30,2) = ( select LPInvestmentReturn from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID-1 and InvesmentId = @CurrentInvesmentId )
						 -- select  @CheckPreviousLPInvestReturn as CheckPreviousLPInvestReturn

			              update @CurrentFinalLPInvestReturn
                                 set LPInvestmentReturn = case when  InvestCashFlow > @CurrentRemainingLPInvest and @CurrentCheckPreviousLPInvestReturn != isnull(@CurrentRemainingLPInvest,0.00) Then @CurrentRemainingLPInvest
								 							   when  InvestCashFlow < @CurrentRemainingLPInvest and @CurrentCheckPreviousLPInvestReturn != isnull(@CurrentRemainingLPInvest,0.00) Then InvestCashFlow  
															   when  InvestCashFlow = @CurrentRemainingLPInvest and @CurrentCheckPreviousLPInvestReturn != isnull(@CurrentRemainingLPInvest,0.00) then @CurrentRemainingLPInvest 
															   else 0.00 end
															 --  when  InvestCashFlow = @RemainingLPInvest and @CheckPreviousLPInvestReturn  = isnull(@RemainingLPInvest,0.00) then isnull(0.00,0.00) end
                                 where Id = @CurrentMinPositiveID 	and InvesmentId = @CurrentInvesmentId   

                            Set @CurrentCheckRemainingLPInvest = ( select LPInvestmentReturn from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId )
							--select @CurrentCheckRemainingLPInvest as CheckRemainingLPInvest
							Set @CurrentInvestCashFlow  = ( select InvestCashFlow from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId )
						--   select @CurrentInvestCashFlow as InvestCashFlow
						  -- Set @RemainingLPInvest = ( select LPInvestmentReturn from @FinalLPInvestReturn where Id = @MinPositiveID and InvesmentId = @InvesmentId )
							if @CurrentCheckRemainingLPInvest <= @CurrentInvestCashFlow --or @CheckPreviousLPInvestReturn = 
							    begin
							    set @CurrentRemainingLPInvest = ( @CurrentRemainingLPInvest - @CurrentCheckRemainingLPInvest )
							--	select @CurrentRemainingLPInvest
								--print 'If Block'
								end
							--else
							--	begin
							--	set @RemainingLPInvest = ( select @RemainingLPInvest - @InvestCashFlow )
							--	--update @FinalLPInvestReturn
       -- --                         set LPInvestmentReturn = case when  InvestCashFlow > @RemainingLPInvest Then @RemainingLPInvest
							--	-- 							   when  InvestCashFlow < @RemainingLPInvest Then InvestCashFlow  
							--	--							   when  InvestCashFlow = @RemainingLPInvest then @RemainingLPInvest end
       -- --                         where Id = @MinPositiveID 	and InvesmentId = @InvesmentId  
							--	 --print 'FinalElse Block'
							--	 set @RemainingLPInvest = @RemainingLPInvest
							--	-- select @RemainingLPInvest
								
							--	 end
			           --  select @MinPositiveID as MinPositiveID       
					--	 select * from @FinalLPInvestReturn		
					  end
					  else 
					      begin
						  --      select @MinPositiveID as MinPositiveID
			                   update @CurrentFinalLPInvestReturn
                                      set LPInvestmentReturn = 0.00                                                                			            
                                      where Id = @CurrentMinPositiveID 	and InvesmentId = @CurrentInvesmentId 		
							
							set @CurrentRemainingLPInvest = @CurrentRemainingLPInvest	  
								-- select @RemainingLPInvest as RemainingLPInvest
								-- print 'FinalElse Block'
								 -- select * from @FinalLPInvestReturn
					      end
			     --set @RemainingLPInvest = @RemainingLPInvest
				
				

			     --set @MinPositiveID = @MinPositiveID + 1

				-- select @CurrentMinPositiveID as MinPositiveID
			     declare @CurrentNegativeInvestCashFlow decimal(30,2)  = isnull(( select abs(isnull(LPInvestContribution,0.00) ) from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId in (2,4,6)  ),0.00)
			--	 select @CurrentNegativeInvestCashFlow as NegativeInvestCashFlow
			     declare @CurrentPositiveInvestCashFlow decimal(30,2)  = isnull(( select isnull(LPInvestContribution,0.00) from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and IsActual =1 ),0.00)
			--	 select @CurrentPositiveInvestCashFlow as PositiveInvestCashFlow
			    set @CurrentRemainingLPInvest = abs( isnull(@CurrentRemainingLPInvest,0.00) + @CurrentNegativeInvestCashFlow - @CurrentPositiveInvestCashFlow)
			--	select @CurrentRemainingLPInvest as RemainingLPInvest
			   --select @RemainingLPInvest
			   set @CurrentMinPositiveID = @CurrentMinPositiveID + 1
			  
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			  
			  
			  --set @CheckLPCost = @CheckLPCost







--			  declare @CheckLPCost1 decimal(30,2) = ( select LPInvestmentReturn from @FinalLPInvestReturn where Id = @MinPositiveID and InvesmentId = @InvesmentId )
--              select @CheckLPCost1 as CheckLPCost
--              --select @sumofNegative as InitialsumofNegative
              
--              If @MInLP = @CheckLPCost1
--              begin
--              print'IF'
--              set @FinalSumofNegative =  @FinalSumofNegative
              
--              end
--              else
--              begin
--              Print'Else'
--                   If @sumofNegative = 0
--                   begin
--                   set @FinalSumofNegative = @RemainingLPInvest
--                   end
--                   else
--                   begin
--                   set @FinalSumofNegative = (@FinalSumofNegative- @CheckLPCost1)
--                   end
--              end


--update @FinalLPInvestReturn
--set LPInvestmentReturn = case when  InvestCashFlow > @FinalSumofNegative Then @FinalSumofNegative
--                              when   InvestCashFlow < @FinalSumofNegative Then InvestCashFlow  
--			                  when InvestCashFlow = @FinalSumofNegative then @FinalSumofNegative end
--where Id = (@MinPositiveID + 1 )	and InvesmentId = @InvesmentId         

----select * from @FinalLPInvestReturn


--set @MinPositiveID = @MinPositiveID + 1

--set @FinalSumofNegative = @FinalSumofNegative
--select @sumofNegative as FinalSumOfNegative

end







----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--while @CurrentMinPositiveID <= @CurrentMaxId
--begin


-- set @CurrentRemainingLPInvest = @CurrentRemainingLPInvest

--declare @CurrentIsactual bit = ( select Isactual from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and IsActual = 0 )

--             declare @CurrentCheckRemainingLPInvest decimal(30,2)
--			 declare @CurrentInvestCashFlow decimal(30,2)

--			          If @CurrentMinPositiveID = @CurrentMinPositiveID and @CurrentIsactual = 1			 
--			          begin

--					  declare @CurrentCheckPreviousLPInvestReturn decimal(30,2) = ( select LPInvestmentReturn from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID-1 and InvesmentId = @CurrentInvesmentId )

--			              update @CurrentFinalLPInvestReturn
--                                 set LPInvestmentReturn = case when  InvestCashFlow > @CurrentRemainingLPInvest and @CurrentCheckPreviousLPInvestReturn != isnull(@CurrentRemainingLPInvest,0.00) Then @CurrentRemainingLPInvest
--								 							   when  InvestCashFlow < @CurrentRemainingLPInvest and @CurrentCheckPreviousLPInvestReturn != isnull(@CurrentRemainingLPInvest,0.00) Then InvestCashFlow  
--															   when  InvestCashFlow = @CurrentRemainingLPInvest and @CurrentCheckPreviousLPInvestReturn != isnull(@CurrentRemainingLPInvest,0.00) then @CurrentRemainingLPInvest 
--														  Else 0.00 end
--                                 where Id = @CurrentMinPositiveID 	and InvesmentId = @CurrentInvesmentId   

--                            Set @CurrentCheckRemainingLPInvest = ( select LPInvestmentReturn from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId )
--							select @CurrentCheckRemainingLPInvest as CurrentCheckRemainingLPInvest
--							Set @CurrentInvestCashFlow  = ( select InvestCashFlow from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId )
--							select @CurrentInvestCashFlow as CurrentInvestCashFlow

--							if @CurrentCheckRemainingLPInvest <= @CurrentInvestCashFlow
--							    begin
--							    set @CurrentRemainingLPInvest = isnull (  ( @CurrentRemainingLPInvest - @CurrentCheckRemainingLPInvest ) , 0.00)
--								select @CurrentRemainingLPInvest as CurrentRemainingLPInvest
--								end
--							--else
--							--	begin
--							--	set @CurrentRemainingLPInvest = ( select @CurrentRemainingLPInvest - @CurrentInvestCashFlow )
--							--	update @CurrentFinalLPInvestReturn
--       --                          set LPInvestmentReturn = case when  InvestCashFlow > @CurrentRemainingLPInvest Then @CurrentRemainingLPInvest
--							--	 							   when  InvestCashFlow < @CurrentRemainingLPInvest Then InvestCashFlow  
--							--								   when  InvestCashFlow = @CurrentRemainingLPInvest then @CurrentRemainingLPInvest end
--       --                          where Id = @CurrentMinPositiveID 	and InvesmentId = @CurrentInvesmentId  
								 
--							--	 set @CurrentRemainingLPInvest = @CurrentRemainingLPInvest
--							--	-- select @RemainingLPInvest
--							--	 end
			                    
								
--					  end
--					  else 
--					      begin
--			                   update @CurrentFinalLPInvestReturn
--                                      set LPInvestmentReturn = 0.00                                                                			            
--                                      where Id = @CurrentMinPositiveID 	and InvesmentId = @CurrentInvesmentId 		
--								set @CurrentRemainingLPInvest = @CurrentRemainingLPInvest	  
--					      end
--			     --set @RemainingLPInvest = @RemainingLPInvest
--				 --select @RemainingLPInvest as RemainingLPInvest
--			     --set @CurrentMinPositiveID = @CurrentMinPositiveID + 1

--				 select  @CurrentMinPositiveID as  CurrentMinPositiveID
--			     declare @CurrentNegativeInvestCashFlow decimal(30,2)  = isnull(( select abs(isnull(LPInvestContribution,0.00) ) from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId in (2,4,6) ),0.00)
--				 select @CurrentNegativeInvestCashFlow as NegativeInvestCashFlow
--			     declare @CurrentPositiveInvestCashFlow decimal(30,2)  = isnull(( select isnull(LPInvestContribution,0.00) from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and IsActual =1 ),0.00)
--				 select @CurrentPositiveInvestCashFlow as PositiveInvestCashFlow
--			    set @CurrentRemainingLPInvest = abs ( isnull(@CurrentRemainingLPInvest,0.00) + @CurrentNegativeInvestCashFlow - @CurrentPositiveInvestCashFlow )
--				select @CurrentRemainingLPInvest as RemainingLPInvest
--			   --select @RemainingLPInvest
--			   set @CurrentMinPositiveID = @CurrentMinPositiveID + 1



------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----declare @CheckLPCost1 decimal(30,2) = ( select LPInvestmentReturn from @CurrentFinalLPInvestReturn where Id = @CurrentMinPositiveID and InvesmentId = @CurrentInvesmentId )
------select @CheckLPCost1 as CheckLPCost
------select @sumofNegative as InitialsumofNegative

----If @CurrentMInLP = @CheckLPCost1
----begin
----print'IF'
----set @CurrentFinalSumofNegative =  @CurrentFinalSumofNegative

----end
----else
----begin
----Print'Else'
----     If @CurrentsumofNegative = 0
----     begin
----     set @CurrentFinalSumofNegative = @CurrentRemainingLPInvest
----     end
----     else
----     begin
----     set @CurrentFinalSumofNegative = (@CurrentFinalSumofNegative- @CheckLPCost1)
----     end
----end

------declare @


----update @CurrentFinalLPInvestReturn
----set LPInvestmentReturn = case when  InvestCashFlow > @CurrentFinalSumofNegative Then @CurrentFinalSumofNegative
----                             when  InvestCashFlow < @CurrentFinalSumofNegative Then InvestCashFlow  
----			                 when InvestCashFlow = @CurrentFinalSumofNegative then @CurrentFinalSumofNegative end
----where Id = (@CurrentMinPositiveID + 1 )	and InvesmentId = @CurrentInvesmentId         

----set @CurrentMinPositiveID = @CurrentMinPositiveID + 1

----set @CurrentFinalSumofNegative = @CurrentFinalSumofNegative
------select @sumofNegative as FinalSumOfNegative

--end


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




set @CurrentMinInvesmentId = @CurrentMinInvesmentId + 1
--select @MinInvesmentId
set @CurrentInvesmentId  = (select InvesmentId from @CurrentInvestmentIdValidate where Id = @CurrentMinInvesmentId )
--select @InvesmentId
End


--select 
--Id  ,
--InvesmentId,
--invesmentCashFlowTypeId ,
--IsActual ,
--EventDate ,
--LPInvestContribution ,
--InvestCashFlow ,
--InitialLPInvest ,
----SumOfNegative decimal(30,2),
--abs(LPInvestmentReturn) as LPInvestmentReturn
--from @CurrentFinalLPInvestReturn

---------------------------------xxxxxxxxxxxxxxxxxxx----------------Step1 LPInvestReturn Completed xxxxxxxxxxxxxxxxxxx-------------------------------------------------------------------------------------------------------

--------------Remain after Step1 -----------------------------------------------------
; with CurrentRemainLPInvestReturn
as
(
select 

  A.FundId                      
 ,A.ScenarioId                  
 ,A.InvestmentId                
 ,A.InvesmentCashFlowTypeId     
 ,A.CashFlowTypeId              
 ,A.IsActual                    
 ,A.[Status]                    
 ,A.TypeId                      
 ,A.CashflowType                
 ,A.EventDate                                
 ,A.InvesmentCashFlow  
 ,A.LimitedPartnerPercent       
 ,A.LPInvesmentContribution     
 ,A.LPCostContribution 
 ,Abs(B.LPInvestmentReturn) LPInvestmentReturn
 ,A.GPPercent
 ,A.GPINvesmentContibution 
 ,A.GPCOstContribution

from @CurrentLPCostContribution A
Left Join @CurrentFinalLPInvestReturn B
on A.InvestmentId = B.InvesmentId and A.InvesmentCashFlowTypeId = B.invesmentCashFlowTypeId and A.IsActual = B.IsActual
and A.EventDate = B.EventDate and A.InvesmentCashFlow =B.InvestCashFlow
--order by A.Eventdate ,A.TypeId
--offset 0 rows

)

Insert into @CurrentCumalativeLPCostReturn
(                     
FundId                        
,ScenarioId                    
,InvestmentId                  
,InvesmentCashFlowTypeId       
,CashFlowTypeId                
,IsActual                      
,[Status]                      
,TypeId                        
,CashflowType                  
,EventDate                     
,InvesmentCashFlow             
,LimitedPartnerPercent         
,LPInvesmentContribution       
,LPCostContribution            
,LPInvesmentReturn             
,RemainLPInvesmentReturnSteps
,GPPercent
, GPINvesmentContibution 
,GPCOstContribution
)

select 

  FundId                      
 ,ScenarioId                  
 ,InvestmentId                
 ,InvesmentCashFlowTypeId     
 ,CashFlowTypeId              
 ,IsActual                    
 ,[Status]                    
 ,TypeId                      
 ,CashflowType                
 ,EventDate                                
 ,InvesmentCashFlow  
 ,LimitedPartnerPercent       
 ,LPInvesmentContribution     
 ,LPCostContribution 
 ,LPInvestmentReturn
 ,case when LPInvestmentReturn is not null then ( InvesmentCashFlow - LPInvestmentReturn ) else null end as RemainLPInvesmentReturn
 ,GPPercent
 , GPINvesmentContibution 
 ,GPCOstContribution
from CurrentRemainLPInvestReturn
order by Eventdate ,TypeId

--select * from @CurrentCumalativeLPCostReturn
-- order by EventDate ,TypeId

---------------To Stop the Cumalative Value -------------------------------------------------------------------------------

declare @CurrentBeforeCumalativeDate date = ( Select MIN(EventDate)   from  [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId and ScenarioId = @baseLineScenarioId
                                              and IsActual = 0 and InvestmentCashflowTypeId in (3,5,7,8) and Isdeleted =0 )

--select @BeforeCumalativeDate BeforeCumalativeDate

-------------------------------------------------------------------------------------------------------------------------------------


;with CurrentCumalativeLPCostContibution
as
(
select 
ID
,FundId                        
,ScenarioId                    
,InvestmentId                  
,InvesmentCashFlowTypeId       
,CashFlowTypeId                
,IsActual                      
,[Status]                      
,TypeId                        
,CashflowType                  
,EventDate                                    
,InvesmentCashFlow             
,LimitedPartnerPercent         
,LPInvesmentContribution
,LPCostContribution
,LPInvesmentReturn             
,RemainLPInvesmentReturnSteps                                        
,Sum (LPCostContribution) Over (Order By ID ) as CumaltiveLPCostContibution 
,GPPercent
, GPINvesmentContibution
,GPCOstContribution
from @CurrentCumalativeLPCostReturn
)

--select * from CumalativeLPCostContibution
insert into @CurrentLPCostReturn
(
ID                          
,FundId                      
,ScenarioId                  
,InvestmentId                
,InvesmentCashFlowTypeId     
,CashFlowTypeId              
,IsActual                    
,[Status]                    
,TypeId                      
,CashflowType                
,EventDate                   
,InvesmentCashFlow           
,LimitedPartnerPercent       
,LPInvesmentContribution     
,LPCostContribution          
,LPInvesmentReturn           
,RemainLPInvesmentReturnSteps
,LPCostReturn                
,CumalativeLPCostContibution  
,RemainLPCostReturn
,GPPercent
, GPINvesmentContibution 
,GPCOstContribution
)
select 
ID
,FundId                        
,ScenarioId                    
,InvestmentId                  
,InvesmentCashFlowTypeId       
,CashFlowTypeId                
,IsActual                      
,[Status]                      
,TypeId                        
,CashflowType                  
,EventDate                                    
,InvesmentCashFlow             
,LimitedPartnerPercent         
,LPInvesmentContribution       
,LPCostContribution            
,LPInvesmentReturn           
,RemainLPInvesmentReturnSteps
,0.00 LPCostReturn   
,case when  @CurrentBeforeCumalativeDate > EventDate then isnull(CumaltiveLPCostContibution,0.00) else 0.00 End as CumalativeLPCostContibution
, 0.00 RemainLPCostReturn  
,GPPercent
, GPINvesmentContibution 
,GPCOstContribution
from CurrentCumalativeLPCostContibution
order by Eventdate ,TypeId

--select * from @CurrentLPCostReturn
--order by Eventdate ,TypeId


Declare @CurrentUpdateLPCostReturn as table
( Id                           int, 
LPCostContribution             decimal(30,2),
Step1LPInvestReturn            decimal(30,2),
Step2LPCostReturn              decimal(30,2),
CumalativeLPCostContribution   decimal(30,2)
)


insert into @CurrentUpdateLPCostReturn (
 Id                        
,LPCostContribution          
,Step1LPInvestReturn         
,Step2LPCostReturn           
,CumalativeLPCostContribution
)

select 
 Id                        
,LPCostContribution          
,RemainLPInvesmentReturnSteps         
,LPCostReturn           
,CumalativeLPCostContibution
from @CurrentLPCostReturn

--select 
--EventDate
--,TypeId
--, Id                        
--,LPCostContribution          
--,RemainLPInvesmentReturnSteps         
--,LPCostReturn           
--,CumalativeLPCostContibution

--from @CurrentLPCostReturn

--select * from @CurrentUpdateLPCostReturn

Declare @Currentmin int = (Select min(Id) from @CurrentUpdateLPCostReturn where Step1LPInvestReturn is not NULL)
 
--select @min

Declare @Currentmax int = (Select max(Id) from @CurrentUpdateLPCostReturn )
--select @max



--SELECT * from @UpdateLPCostReturn

while (@Currentmin <= @Currentmax)
begin

declare @CurrentStep1LPInvestReturn decimal(30,2) = ( select Step1LPInvestReturn from @CurrentUpdateLPCostReturn where Id = @Currentmin)
--select @Step1LPInvestReturn as Step1LPInvestReturn
If @CurrentStep1LPInvestReturn is not null
begin
Declare @CurrentTestLP as table (id int,  step1LPremain decimal(30,2), flag int, result int)
insert into @CurrentTestLP
SELECT Id,Step1LPInvestReturn, case when Step1LPInvestReturn > 0 then 1 else 0 end as flag, LAG(CumalativeLPCostContribution) over (order by id) as result 
from @CurrentUpdateLPCostReturn  where Id in (@Currentmin, @Currentmin-1)


--select * from  @CurrentTestLP

update L
SET Step2LPCostReturn = Case when T.flag = 0 then 0 else IIF(L.Step1LPInvestReturn > ABS(T.Result), ABS(T.Result), L.Step1LPInvestReturn) END
FROM @CurrentUpdateLPCostReturn L
inner join @CurrentTestLP T
ON T.id = L.Id
WHERE L.Id = @Currentmin

--SELECT * from @UpdateLPCostReturn

Update L
SET CumalativeLPCostContribution = L.Step2LPCostReturn + T.result
FROM @CurrentUpdateLPCostReturn L
inner join @CurrentTestLP T 
ON T.id = L.Id
WHERE L.Id = @Currentmin



DECLARE @CurrentCumalativeLPCostContribution DECIMAL(30,2) = ( select isnull(CumalativeLPCostContribution,0.00) from @CurrentUpdateLPCostReturn where Id = @Currentmin )
dECLARE @CurrentLPCostContributionUpdate DECIMAL(30,2) =  (select isnull(LPCostContribution,0.00) from @CurrentUpdateLPCostReturn where Id = @Currentmin+1)

UPDATE @CurrentUpdateLPCostReturn
SET CumalativeLPCostContribution = @CurrentCumalativeLPCostContribution + @CurrentLPCostContributionUpdate
WHERE Id  =  @Currentmin+1

end
else 
begin

DECLARE @CurrentCumalativeLPCostContributionElse DECIMAL(30,2) = ( select isnull(CumalativeLPCostContribution,0.00) from @CurrentUpdateLPCostReturn where Id = @Currentmin )
dECLARE @CurrentLPCostContributionElse DECIMAL(30,2) =  (select isnull(LPCostContribution,0.00) from @CurrentUpdateLPCostReturn where Id = @Currentmin+1)


UPDATE @CurrentUpdateLPCostReturn
SET CumalativeLPCostContribution = @CurrentCumalativeLPCostContributionElse + @CurrentLPCostContributionElse
WHERE Id  =  @Currentmin+1

end


SET @Currentmin = @Currentmin+1
END



-------------------------------------------To find Step 3  WaterfallCalculation --------------------------------------------------

declare @CurrentMinPositiveDateStep3 date = (select MIN(EventDate) from @CurrentLPCostReturn where    invesmentCashFlowTypeId in (3,5,7,8) and IsActual =0  )
--select @MinPositiveDateStep3 as MinPositiveDate

declare @CurrentMinPositiveIdStep3 int = ( select Min(ID) from @CurrentLPCostReturn where  EventDate = @CurrentMinPositiveDateStep3 and IsActual =0 )
--select @MinPositiveIdStep3 as MinPositiveID

declare @CurrentMaxPositiveIdStep3 int = ( select Max(ID) from @CurrentLPCostReturn     )

--declare @MinDate date = (select MIN(EventDate) from @LPCostReturn )
--select @MinPositiveDateStep3 as MinPositiveDate

Insert into @CurrentFinalLPCostReturn
( 
 ID                          
,FundId                      
,ScenarioId                  
,InvestmentId                
,InvesmentCashFlowTypeId     
,CashFlowTypeId              
,IsActual                    
,[Status]                    
,TypeId                      
,CashflowType                
,EventDate                   
,InvesmentCashFlow           
,LimitedPartnerPercent       
,LPInvesmentContribution     
,LPCostContribution          
,LPInvesmentReturn           
,RemainLPInvesmentReturnSteps
,LPCostReturn                
,CumalativeLPCostContibution 
,RemainLPCostReturn          
,TotalLPContibution          
,TotalLPReturn               
,NetLPContribution  
,CumaltiveNetLPContibution
,GPPercent
, GPINvesmentContibution 
,GPCOstContribution
 ,TotalGPContribution          
 ,TotalGPReturn                
 ,NetGPContribution			
 ,CumaltiveNetGPContibution	
)

select
 A.ID                               
,A.FundId                           
,A.ScenarioId                       
,A.InvestmentId                     
,A.InvesmentCashFlowTypeId          
,A.CashFlowTypeId                   
,A.IsActual                         
,A.[Status]                         
,A.TypeId                           
,A.CashflowType                     
,A.EventDate                                           
,A.InvesmentCashFlow                
,A.LimitedPartnerPercent            
,A.LPInvesmentContribution          
,A.LPCostContribution               
,A.LPInvesmentReturn           
,A.RemainLPInvesmentReturnSteps
,B.Step2LPCostReturn                
,B.CumalativeLPCostContribution     
--,A.RemainLPCostReturn  
,A.RemainLPInvesmentReturnSteps - B.Step2LPCostReturn  as RemainLPCostReturn
-- ,case when A.ID < @MinPositiveIdStep3 then (isnull(A.LPInvesmentContribution,0.00) +  isnull(A.LPCostContribution,0.00) ) else 0.00 end as TotalLPContribution
  ,case when A.InvesmentCashFlowTypeId  IN (3,5,7,8) and IsActual = 0 then  0.00 else (isnull(A.LPInvesmentContribution,0.00) +  isnull(A.LPCostContribution,0.00) ) end as TotalLPContribution
 ,case when A.ID < @CurrentMinPositiveIdStep3 then (isnull(A.LPInvesmentReturn,0.00) + isnull(B.Step2LPCostReturn,0.00)) else 0.00 end  as TotalLPReturn

 , ( case when A.InvesmentCashFlowTypeId  IN (3,5,7,8) and IsActual = 0 then  0.00 else (isnull(A.LPInvesmentContribution,0.00) +  isnull(A.LPCostContribution,0.00) ) end + 
   case when A.ID < @CurrentMinPositiveIdStep3 then (isnull(A.LPInvesmentReturn,0.00) + isnull(B.Step2LPCostReturn,0.00)) else 0.00 end ) as NetLPContribution

 ,case when A.ID < @CurrentMinPositiveIdStep3 then Sum ( (isnull(A.LPInvesmentContribution,0.00) +  isnull(A.LPCostContribution,0.00)) + (isnull(A.LPInvesmentReturn,0.00) + isnull(B.Step2LPCostReturn,0.00)) ) Over (Order By A.ID )
       else 0.00 end  as CumaltiveNetLPContibution 
 ,GPPercent
 , GPINvesmentContibution 
 ,GPCOstContribution
 ,case when A.InvesmentCashFlowTypeId  IN (3,5,7,8) and IsActual = 0 then  0.00 else (isnull(A.GPINvesmentContibution,0.00) +  isnull(A.GPCOstContribution,0.00) ) end as TotalGPContribution
 , 0 as TotalGPReturn
 , ( case when A.InvesmentCashFlowTypeId  IN (3,5,7,8) and IsActual = 0 then  0.00 else (isnull(A.GPINvesmentContibution,0.00) +  isnull(A.GPCOstContribution,0.00) ) end +
      0 ) as NetGPContribution 
 ,case when A.ID < @CurrentMinPositiveIdStep3 then Sum ( (isnull(A.GPINvesmentContibution,0.00) +  isnull(A.GPCOstContribution,0.00) ) + 0 ) Over (Order By A.ID )
       else 0.00 end  as CumaltiveNetGPContibution 
from @CurrentLPCostReturn A
inner join @CurrentUpdateLPCostReturn B
on A.ID = B.Id

--select * from @FinalLPCostReturn


declare @CurrentLPPreferedReturn decimal(30,5) = ( select LPPreferredReturnPercent from [OPGC].[OpgcScenario] where FundID = @FundId and ScenarioId = @baseLineScenarioId and Isdeleted = 0 )
set @CurrentLPPreferedReturn = ( 1 + (@CurrentLPPreferedReturn/100) )

declare @CurrentGPPreferedReturn decimal(30,5) = ( select GPPreferredReturnPercent from [OPGC].[OpgcScenario] where FundID = @FundId and ScenarioId = @baseLineScenarioId and Isdeleted = 0 )
set @CurrentGPPreferedReturn = ( 1 + (@CurrentGPPreferedReturn/100) )

declare @CurrentLPFinalShare decimal(30,2) = ( select LPFinalSharePercent from [OPGC].[OpgcScenario] where FundID = @FundId and ScenarioId = @baseLineScenarioId and Isdeleted = 0 )


--declare @TestStep3 as table
--( Id                          int ,
--InvesmentCashFlowTypeID       int,
--IsActual                      int,
--EventDate                     date,
--MinDate                       date,
--LPPreferedReturn            decimal(30,2),
--NetLPContribution             Decimal(30,2),
--CumalativeNetLPContribution  decimal(30,2),
--GPPreferedReturn            decimal(30,2),
--NetGPContribution            decimal (30,2),
--CumalativeNetGPContribution  decimal(30,2)

--)

declare @CurrentFinalTestStep3 as table
( 
Id                          int ,
InvesmentCashFlowTypeID       int,
IsActual                      int,
EventDate                     date,
MaxDate                      date,
[YearDiffernce/365]          decimal(30,12),
[1+LPPreferedReturn]        decimal(18,12),
LogLPPreferedReturn           Decimal(30,12),
NetLPContribution             Decimal(30,2),
PowerNetLP                   Decimal(30,2),
CumalativeNetLPContribution  decimal(30,2),
LPPreferredReturnThreshold    decimal(30,2),
[1+GPPreferedReturn]        decimal(18,12),
LogGPPreferedReturn           Decimal(30,12),
NetGPContribution             Decimal(30,2),
PowerNetGP                   Decimal(30,2),
CumalativeNetGPContribution  decimal(30,2),
GPPreferredReturnThreshold    decimal(30,2),
GPPreferredReturn            decimal(30,2),
RemainGPPreferredReturn      decimal(30,2)
)



while @CurrentMinPositiveIDStep3 <= @CurrentMaxPositiveIdStep3

begin

set @CurrentMinPositiveDateStep3  = (select MIN(EventDate) from @CurrentLPCostReturn where  Id = @CurrentMinPositiveIdStep3  )
--select  @MinPositiveIdStep3 as MinPositiveIdStep3

declare @CheckInvesmentCashFlowID int = ( select count(1) from @CurrentLPCostReturn where  Id = @CurrentMinPositiveIdStep3 and IsActual = 0 and InvesmentCashFlowTypeID in (3,5,7,8) )
--select @CheckInvesmentCashFlowID as CheckInvesmentCashFlowID

IF @CurrentMinPositiveIdStep3 = @CurrentMinPositiveIdStep3 and @CheckInvesmentCashFlowID >= 1
begin

delete from  @CurrentFinalTestStep3

Insert into @CurrentFinalTestStep3
(
Id                         
,InvesmentCashFlowTypeID    
,IsActual                   
,EventDate                  
,MaxDate                    
,[YearDiffernce/365]        
,[1+LPPreferedReturn]       
,LogLPPreferedReturn        
,NetLPContribution          
,PowerNetLP                 
,CumalativeNetLPContribution
,[1+GPPreferedReturn]       
,LogGPPreferedReturn        
,NetGPContribution          
,PowerNetGP                 
,CumalativeNetGPContribution
--,GPPreferredReturnThreshold 
)




select ID
,InvesmentCashFlowTypeId
,IsActual
,EventDate
--,MinDate
,@CurrentMinPositiveDateStep3 as MaxDate
--, cast ( datediff(day,EventDate ,@MinPositiveDate) as decimal(30,10))  as YearDiffernce 
, cast ( ( cast ( datediff(day,EventDate ,@CurrentMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12)) as [YearDiffernce/365] 
,@CurrentLPPreferedReturn as [1+LPPreferedReturn]
,cast (POWER(@CurrentLPPreferedReturn,cast ( ( cast ( datediff(day,EventDate ,@CurrentMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12))) as decimal(30,12)) as LogLPPreferedReturn
,NetLPContribution
,  cast ( ( NetLPContribution * cast (POWER(@CurrentLPPreferedReturn,cast ( ( cast ( datediff(day,EventDate ,@CurrentMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12))) as decimal(30,12)) ) as decimal(30,12)) as PowerNetLP
,CumaltiveNetLPContibution 

,@CurrentGPPreferedReturn as [1+GPPreferedReturn]
,cast (POWER(@CurrentGPPreferedReturn,cast ( ( cast ( datediff(day,EventDate ,@CurrentMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12))) as decimal(30,12)) as LogGPPreferedReturn
,NetGPContribution
,  cast ( ( NetGPContribution * cast (POWER(@CurrentGPPreferedReturn,cast ( ( cast ( datediff(day,EventDate ,@CurrentMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12))) as decimal(30,12)) ) as decimal(30,12)) as PowerNetGP
,CumaltiveNetGPContibution 

from @CurrentFinalLPCostReturn

--select * from @FinalTestStep3


declare @CurrentCumalativeNetLPContribution decimal(30,10) = (select CumalativeNetLPContribution from @CurrentFinalTestStep3 Where Id = (@CurrentMinPositiveIdStep3-1)  )
--select @CurrentCumalativeNetLPContribution as CumalativeNetLPContribution

declare @CurrentCumalativeNetGPContribution decimal(30,10) = (select CumalativeNetGPContribution from @CurrentFinalTestStep3 Where Id = (@CurrentMinPositiveIdStep3-1)  )
--select @CumalativeNetGPContribution as CumalativeNetGPContribution






declare @CurrentSumofPowerNetLP decimal(30,10) = (select SUM(PowerNetLP) from @CurrentFinalTestStep3 where Id < @CurrentMinPositiveIDStep3  )
declare @CurrentSumofPowerNetGP decimal(30,10) = (select SUM(PowerNetGP) from @CurrentFinalTestStep3 where Id < @CurrentMinPositiveIDStep3  )

--select @SumofPowerNetLP as SumofPowerNetLP
--select @SumofPowerNetGP as SumofPowerNetGP
--select @MinPositiveIdStep3 as MinPositiveIdStep3


if @CurrentCumalativeNetLPContribution < 0
begin

--declare @LPPreferredReturnThreshold decimal(30,2) = ( select isnull( (- @SumofPowerNetLP) - ( - @CumalativeNetLPContribution ), 0.00) )
--declare @PPreferredReturnThreshold decimal(30,2) = ( select 

update @CurrentFinalTestStep3
set LPPreferredReturnThreshold = case when isnull( (- @CurrentSumofPowerNetLP) - ( - @CurrentCumalativeNetLPContribution ), 0.00) < 0 then 0.00 else isnull( (- @CurrentSumofPowerNetLP) - ( - @CurrentCumalativeNetLPContribution ), 0.00) end   
   -- GPPreferredReturnThreshold = case when isnull( (- @CurrentSumofPowerNetGP) - ( - @CurrentCumalativeNetGPContribution ) , 0.00) < 0 then 0.00 else isnull( (- @CurrentSumofPowerNetGP) - ( - @CurrentCumalativeNetGPContribution ) , 0.00) end
from  @CurrentFinalTestStep3
where Id = @CurrentMinPositiveIdStep3

end

else
begin
update @CurrentFinalTestStep3
set LPPreferredReturnThreshold = 0.00
  --  GPPreferredReturnThreshold = case when isnull( (- @CurrentSumofPowerNetGP) - ( - @CurrentCumalativeNetGPContribution ) , 0.00) < 0 then 0.00 else isnull( (- @CurrentSumofPowerNetGP) - ( - @CurrentCumalativeNetGPContribution ) , 0.00) end
from  @CurrentFinalTestStep3
where Id = @CurrentMinPositiveIdStep3
end

if @CurrentCumalativeNetGPContribution < 0
begin

--declare @LPPreferredReturnThreshold decimal(30,2) = ( select isnull( (- @SumofPowerNetLP) - ( - @CumalativeNetLPContribution ), 0.00) )
--declare @PPreferredReturnThreshold decimal(30,2) = ( select 

update @CurrentFinalTestStep3
set   GPPreferredReturnThreshold = case when isnull( (- @CurrentSumofPowerNetGP) - ( - @CurrentCumalativeNetGPContribution ) , 0.00) < 0 then 0.00 else isnull( (- @CurrentSumofPowerNetGP) - ( - @CurrentCumalativeNetGPContribution ) , 0.00) end
from  @CurrentFinalTestStep3
where Id = @CurrentMinPositiveIdStep3

end

else
begin
update @CurrentFinalTestStep3
set GPPreferredReturnThreshold = 0.00
from  @CurrentFinalTestStep3
where Id = @CurrentMinPositiveIdStep3
end

--select * from @CurrentFinalTestStep3

Declare @CurrentLPPreferredReturnThreshold decimal(30,2) = ( select ISnull(LPPreferredReturnThreshold,0.00) from @CurrentFinalTestStep3 where Id = @CurrentMinPositiveIdStep3)
declare @CurrentRemianLPCostReturn decimal(30,2) = ( select Isnull(RemainLPCostReturn,0.00) from @CurrentFinalLPCostReturn where Id = @CurrentMinPositiveIdStep3)

Declare @CurrentGPPreferredReturnThreshold decimal(30,2) = ( select isnull(GPPreferredReturnThreshold,0.00) from @CurrentFinalTestStep3 where Id = @CurrentMinPositiveIdStep3)
--declare @RemianGPCostReturn decimal(30,2) = ( select RemainGPCostReturn from @FinalLPCostReturn where Id = @MinPositiveIdStep3)


Update A
set A.LPPreferredReturnThreshold = isnull(B.LPPreferredReturnThreshold,0.00) ,
A.LPPreferrefReturn = case when @CurrentRemianLPCostReturn > 0 and @CurrentRemianLPCostReturn >= B.LPPreferredReturnThreshold then Isnull(B.LPPreferredReturnThreshold,0.00)
                           when @CurrentRemianLPCostReturn > 0 and @CurrentRemianLPCostReturn < B.LPPreferredReturnThreshold then isnull(@CurrentRemianLPCostReturn,0.00)
						   when @CurrentRemianLPCostReturn <= 0   then 0.00 end ,
A.RemainLPPreferrefReturn =  ( @CurrentRemianLPCostReturn - case when @CurrentRemianLPCostReturn > 0 and @CurrentRemianLPCostReturn >= B.LPPreferredReturnThreshold then isnull(B.LPPreferredReturnThreshold,0.00)
                                                     when @CurrentRemianLPCostReturn > 0 and @CurrentRemianLPCostReturn < B.LPPreferredReturnThreshold then isnull(@CurrentRemianLPCostReturn,0.00)
						                             when @CurrentRemianLPCostReturn <= 0   then 0.00 end ) ,
 
 A.GPPreferredReturnThreshold = isnull(B.GPPreferredReturnThreshold ,0.00)

from @CurrentFinalLPCostReturn A
join @CurrentFinalTestStep3 B
on A.ID = B.Id
where A.ID = @CurrentMinPositiveIdStep3

declare @CurrentRemianLPPreferredReturn decimal(30,2) = ( select isnull(RemainLPPreferrefReturn,0.00) from @CurrentFinalLPCostReturn where Id = @CurrentMinPositiveIdStep3)


Update A
set A.GPPreferrefReturn = case when @CurrentRemianLPPreferredReturn > 0 and @CurrentRemianLPPreferredReturn >= B.GPPreferredReturnThreshold then isnull(B.GPPreferredReturnThreshold,0.00)
                           when @CurrentRemianLPPreferredReturn > 0 and @CurrentRemianLPPreferredReturn < B.GPPreferredReturnThreshold then isnull(@CurrentRemianLPPreferredReturn,0.00)
						   when @CurrentRemianLPPreferredReturn <= 0   then 0.00 end ,
A.RemainGPPreferrefReturn =  ( @CurrentRemianLPPreferredReturn - case when @CurrentRemianLPPreferredReturn > 0 and @CurrentRemianLPPreferredReturn >= B.GPPreferredReturnThreshold then isnull(B.GPPreferredReturnThreshold,0.00)
                                                          when @CurrentRemianLPPreferredReturn > 0 and @CurrentRemianLPPreferredReturn < B.GPPreferredReturnThreshold then isnull(@CurrentRemianLPPreferredReturn,0.00)
						                                  when @CurrentRemianLPPreferredReturn <= 0   then 0.00 end ) 

from @CurrentFinalLPCostReturn A
join @CurrentFinalTestStep3 B
on A.ID = B.Id
where A.ID = @CurrentMinPositiveIdStep3



Update @CurrentFinalLPCostReturn

set FinalLPReturn = isnull( RemainGPPreferrefReturn * (@CurrentLPFinalShare/100),0.00) ,
FinalGPReturn = isnull(RemainGPPreferrefReturn * ( 1 - (@CurrentLPFinalShare /100)),0.00)
where ID = @CurrentMinPositiveIdStep3

Update @CurrentFinalLPCostReturn

set TotalLPReturn = isnull( LPInvesmentReturn + LPCostReturn + LPPreferrefReturn + FinalLPReturn,0.00) ,
NetLPContribution = isnull( TotalLPContibution + ( LPInvesmentReturn + LPCostReturn + LPPreferrefReturn + FinalLPReturn),0.00),
CumaltiveNetLPContibution = isnull( @CurrentCumalativeNetLPContribution + (  TotalLPContibution + ( LPInvesmentReturn + LPCostReturn + LPPreferrefReturn + FinalLPReturn) ),0.00) ,
TotalGPReturn = isnull(GPPreferrefReturn + FinalGPReturn,0.00),
NetGPContribution = isnull(TotalGPContribution + ( GPPreferrefReturn + FinalGPReturn ) ,0.00),
CumaltiveNetGPContibution = isnull(@CurrentCumalativeNetGPContribution + (  TotalGPContribution + ( GPPreferrefReturn + FinalGPReturn ) ),0.00)
where ID = @CurrentMinPositiveIdStep3


Update B
Set B.CumalativeNetLPContribution = A.CumaltiveNetLPContibution,
B.CumalativeNetGPContribution = A.CumaltiveNetGPContibution

from @CurrentFinalLPCostReturn A
join @CurrentFinalTestStep3 B
on A.ID = B.Id
where A.ID = @CurrentMinPositiveIdStep3

end
else
begin

declare @CurrentElseCumalativeNetLPContribution decimal(30,10) = (select CumalativeNetLPContribution from @CurrentFinalTestStep3 Where Id = (@CurrentMinPositiveIdStep3-1)  )
--select @ElseCumalativeNetLPContribution as ElseCumalativeNetLPContribution

declare @CurrentElseCumalativeNetGPContribution decimal(30,10) = (select CumalativeNetGPContribution from @CurrentFinalTestStep3 Where Id = (@CurrentMinPositiveIdStep3-1)  )

Update @CurrentFinalLPCostReturn
set NetLPContribution = TotalLPContibution,
CumaltiveNetLPContibution = @CurrentElseCumalativeNetLPContribution + TotalLPContibution,
NetGPContribution = TotalGPContribution ,
CumaltiveNetGPContibution = @CurrentElseCumalativeNetGPContribution + TotalGPContribution
where ID = @CurrentMinPositiveIdStep3

Update B
Set B.CumalativeNetLPContribution = A.CumaltiveNetLPContibution,
B.CumalativeNetGPContribution = A.CumaltiveNetGPContibution

from @CurrentFinalLPCostReturn A
join @CurrentFinalTestStep3 B
on A.ID = B.Id
where A.ID = @CurrentMinPositiveIdStep3


end

--select * from @FinalTestStep3

set @CurrentMinPositiveIdStep3 = @CurrentMinPositiveIdStep3 + 1
--select @MinPositiveIdStep3 as MinPositiveIdStep3


--select  @MinPositiveIdStep3 as NextMinPositiveIdStep3
end


end
else

begin

insert into @CurrentFinalLPCostReturn
 
(                         
 FundId                      
,ScenarioId                  
,InvestmentId                
,InvesmentCashFlowTypeId     
,CashFlowTypeId              
,IsActual                    
,[Status]                    
,TypeId                      
,CashflowType                
,EventDate                   
,InvesmentCashFlow           
,LimitedPartnerPercent       
,LPInvesmentContribution     
,LPCostContribution                        
,TotalLPContibution          
,TotalLPReturn               
,NetLPContribution           
)

select 
 FundId                      
 ,ScenarioId                  
 ,InvestmentId                
 ,InvesmentCashFlowTypeId     
 ,CashFlowTypeId              
 ,IsActual                    
 ,[Status]                    
 ,TypeId                      
 ,CashflowType                
 ,EventDate                                
 ,InvesmentCashFlow           
 ,LimitedPartnerPercent       
 ,LPInvesmentContribution     
 ,LPCostContribution
 ,isnull(LPInvesmentContribution,0.00) + isnull(LPCostContribution,0.00) as TotalLPContribution
 , 0 as TotalLPReturn
 , ( ( isnull(LPInvesmentContribution,0.00) + isnull(LPCostContribution,0.00) ) + 0 ) as NetLPContribution


 from @CurrentLPCostContribution

 --------------------------------------------------------------------------------------------------------------------

-- insert into @CurrentFinalLPCostReturn
 
--(                         
-- FundId                      
--,ScenarioId                  
----,InvestmentId                
----,InvesmentCashFlowTypeId     
----,CashFlowTypeId              
----,IsActual                    
----,[Status]                    
----,TypeId                      
----,CashflowType                
----,EventDate                   
----,InvesmentCashFlow           
----,LimitedPartnerPercent       
----,LPInvesmentContribution     
----,LPCostContribution                        
--,TotalLPContibution          
--,TotalLPReturn               
--,NetLPContribution           
--)

--select 
-- @FundId                      
-- ,@baseLineScenarioId                               
-- ,0.00
-- ,0.00
-- ,0.00





 --select * from @CurrentFinalLPCostReturn
 --order by  EventDate , TypeId 


end


--SELECT * from @CurrentUpdateLPCostReturn

--end
--else
--begin

--insert into @CurrentFinalLPCostReturn
 
--(                         
-- FundId                      
--,ScenarioId                   
--,NetLPContribution           
--)

--select 
-- @FundId                      
-- ,@baseLineScenarioId                  
-- , 0 as NetLPContribution


--end

end
else
begin

 insert into @CurrentFinalLPCostReturn
 
(                         
 FundId                      
,ScenarioId                  
--,InvestmentId                
--,InvesmentCashFlowTypeId     
--,CashFlowTypeId              
--,IsActual                    
--,[Status]                    
--,TypeId                      
--,CashflowType                
--,EventDate                   
--,InvesmentCashFlow           
--,LimitedPartnerPercent       
--,LPInvesmentContribution     
--,LPCostContribution                        
,TotalLPContibution          
,TotalLPReturn               
,NetLPContribution           
)

select 
 @FundId                      
 ,@baseLineScenarioId                               
 ,0.00
 ,0.00
 ,0.00

end


--select * from @CurrentFinalLPCostReturn
-- order by  EventDate , TypeId 

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

------------------selected Scenario



-----------------Scenario Level ------------------------------------------------------------------------------------------------------------------------------


declare @InvesmentIdNonBase as table ( Id int)



;with investmentNonBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @fundid and ScenarioId = @NonBaseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentNonBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and 
  FundId = @fundid and ScenarioId = @NonBaseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdNonBase
select A.InvestmentId from investmentNonBaseInitial A
join investmentNonBaseExit B
on A.InvestmentId =B.InvestmentId




declare @SelectedCommittedCapital decimal(30,2) = (select CommittedCapital from   [OPGC].[OpgcScenario] where ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )
--select @CommittedCapital as CommittedCapital

declare @SelectedManagementFeePercent decimal(30,5) = (select (ManagementFeePercent/100) from   [OPGC].[OpgcScenario] where ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )
--select @ManagementFeePercent as ManagementFeePercent

declare @SelectedOtherPartnershipFeesByQuarter decimal(30,2) = (select OtherPartnershipFeesByQuarter from   [OPGC].[OpgcScenario] where ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )
--select @OtherPartnershipFeesByQuarter as ManagementFeePercent

declare @SelectOffsetByQuarter decimal(30,2) = (select OffsetsByQuarter from   [OPGC].[OpgcScenario] where ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )
--select @SelectOffsetByQuarter as ManagementFeePercent


declare @SelectedSumOfNegativeInvestment decimal(30,2) = ( select SUM(Equity) from   [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId and ScenarioId = @NonBaseLineScenarioId and InvestmentId in ( select Id from @InvesmentIdNonBase) and InvestmentCashflowTypeId  in (1,2,4,6) and Isdeleted = 0 )
--select @SumOfNegativeInvestment as SumOfNegativeInvestment



declare @SelectedFundInceptionDate date  = (select FundInceptionDate from   [OPGC].[OpgcScenario] where ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )
--select @FundInceptionDate as FundInceptionDate

declare @SelectedManualStepdownDate date  = (select ManualStepdownDate from   [OPGC].[OpgcScenario] where ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )
--select @ManualStepdownDate as ManualStepdownDate

declare @SelectedCalculatedManualStepdownDate date  = (select DATEADD(yy,5,FundInceptionDate) from   [OPGC].[OpgcScenario] where ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )
--select @CalculatedManualStepdownDate as CalculatedManualStepdownDate


Declare @SelectedMaxDateInvest date = ( select max(Eventdate) from   [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId and ScenarioId = @NonBaseLineScenarioId and InvestmentId in ( select Id from @InvesmentIdNonBase) and Isdeleted = 0 )

Declare @SelectedMaxDateFund date = ( select max(Eventdate) from   [OPGC].[OpgcFundCashFlow] where FundId =  @FundId and ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


--------------InvesmentId------------------------------------------------------------------------------------------




--select * from @InvesmentcashFlow

declare @SelectedPhantomCalculation as table 
(  
   FundId                      int,
   ScenarioId                  int,
   InvestmentId                 int,
   InvesmentCashFlowTypeId     int,
   CashFlowTypeId              int, 
   IsActual                    int,
   [Status]                      nvarchar(250),
   TypeId                      int,
   CashflowType                nvarchar(250),
   EventDate                   date ,
   --QuarterDate                 date , 
   InvesmentCashFlow           decimal(30,2),
   LimitedPartnerPercent       decimal(5,2),
   LPInvesmentContribution     decimal(30,2),
   LPCostContribution          decimal(30,2),
   GPPercent                  decimal(30,2),
   GPINvesmentContibution     decimal(30,2),
   GPCostContribution         decimal(30,2)
)


declare @SelectedLPCostContribution as table 
(  
   FundId                      int,
   ScenarioId                  int,
   InvestmentId                 int,
   InvesmentCashFlowTypeId     int,
   CashFlowTypeId              int, 
   IsActual                    int,
   [Status]                      nvarchar(250),
   TypeId                      int,
   CashflowType                nvarchar(250),
   EventDate                   date ,
   InvesmentCashFlow           decimal(30,2),
   LimitedPartnerPercent       decimal(5,2),
   LPInvesmentContribution     decimal(30,2),
   LPCostContribution          decimal(30,2),
   GPPercent                  decimal(30,2),
   GPINvesmentContibution     decimal(30,2),
   GPCOstContribution         decimal(30,2)
)

declare @SelectedInvesmentcashFlow as table 
(  FundId                      int,
   ScenarioId                  int,
   InvestmentId                 int,
   InvesmentCashFlowTypeId     int,
   IntialEquity                decimal(30,2),
   IntialLPInvesmentContribution     decimal(30,2)
   )



Declare @SelectedLPInvestReturn as table
(
Id int identity(1,1),
InvesmentId int,
invesmentCashFlowTypeId int,
IsActual int,
EventDate date,
LPInvestContribution decimal(30,2),
InvestCashFlow decimal(30,2),
InitialLPInvest decimal(30,2)
)

Declare @SelectedFinalLPInvestReturn as table
(
Id int ,
InvesmentId int,
invesmentCashFlowTypeId int,
IsActual int,
EventDate date,
LPInvestContribution decimal(30,2),
InvestCashFlow decimal(30,2),
InitialLPInvest decimal(30,2),
--SumOfNegative decimal(30,2),
LPInvestmentReturn decimal(30,2)
)

declare @SelectedCumalativeLPCostReturn as table 
(  ID                             int identity(1,1),
   FundId                         int,
   ScenarioId                     int,
   InvestmentId                   int,
   InvesmentCashFlowTypeId        int,
   CashFlowTypeId                 int, 
   IsActual                       int,
   [Status]                       nvarchar(250),
   TypeId                         int,
   CashflowType                   nvarchar(250),
   EventDate                      date ,
   InvesmentCashFlow              decimal(30,2),
   LimitedPartnerPercent          decimal(5,2),
   LPInvesmentContribution        decimal(30,2),
   LPCostContribution             decimal(30,2),
   IntialEquity                   decimal(30,2),
   InitialLPInvesmentContribution  decimal(30,2),
   LPInvesmentReturn              decimal(30,2),
   RemainLPInvesmentReturnSteps   decimal(30,2),
   CumaltiveLPCostContibution          decimal(30,2),
   GPPercent                  decimal(30,2),
   GPINvesmentContibution     decimal(30,2),
   GPCOstContribution         decimal(30,2)
)

declare @SelectedLPCostReturn as table 
( 
   ID                             int ,
   FundId                         int,
   ScenarioId                     int,
   InvestmentId                   int,
   InvesmentCashFlowTypeId        int,
   CashFlowTypeId                 int, 
   IsActual                       int,
   [Status]                       nvarchar(250),
   TypeId                         int,
   CashflowType                   nvarchar(250),
   EventDate                      date ,
   InvesmentCashFlow              decimal(30,2),
   LimitedPartnerPercent          decimal(5,2),
   LPInvesmentContribution        decimal(30,2),
   LPCostContribution             decimal(30,2),
   LPInvesmentReturn              decimal(30,2),
   RemainLPInvesmentReturnSteps   decimal(30,2),
   LPCostReturn                   decimal(30,2),
   CumalativeLPCostContibution     decimal(30,2),
   RemainLPCostReturn             decimal(30,2),
   GPPercent                  decimal(30,2),
   GPINvesmentContibution     decimal(30,2),
   GPCOstContribution         decimal(30,2)
)

declare @SelectedFinalLPCostReturn as table 
( 
   ID                             int ,
   FundId                         int,
   ScenarioId                     int,
   InvestmentId                   int,
   InvesmentCashFlowTypeId        int,
   CashFlowTypeId                 int, 
   IsActual                       int,
   [Status]                       nvarchar(250),
   TypeId                         int,
   CashflowType                   nvarchar(250),
   EventDate                      date ,
   InvesmentCashFlow              decimal(30,2),
   LimitedPartnerPercent          decimal(5,2),
   LPInvesmentContribution        decimal(30,2),
   LPCostContribution             decimal(30,2),
   LPInvesmentReturn              decimal(30,2),
   RemainLPInvesmentReturnSteps   decimal(30,2),
   LPCostReturn                   decimal(30,2),
   CumalativeLPCostContibution     decimal(30,2),
   RemainLPCostReturn             decimal(30,2),
   CumaltiveNetLPContibution     decimal(30,2),
   GPPercent                     decimal(30,2),
   GPINvesmentContibution        decimal(30,2),
   GPCOstContribution             decimal(30,2),
   TotalGPContribution            decimal(30,2),
   TotalGPReturn                  decimal(30,2),  
   NetGPContribution			  decimal(30,2),
   CumaltiveNetGPContibution	  decimal(30,2),
   LPPreferredReturnThreshold    decimal(30,2),
   LPPreferrefReturn             decimal(30,2),
   RemainLPPreferrefReturn       decimal(30,2),
   GPPreferredReturnThreshold    decimal(30,2),
   GPPreferrefReturn             decimal(30,2),
   RemainGPPreferrefReturn       decimal(30,2),
   FinalLPReturn                decimal(30,2),
   FinalGPReturn                decimal(30,2),
   TotalLPContibution             decimal(30,2),
   TotalLPReturn                  decimal(30,2),
   NetLPContribution              decimal(30,2)
) 



--declare @SelectedTempGPCostContribution as table ( 
--Id int ,
--value decimal(30,2)
--)

--insert into @SelectedTempGPCostContribution values
--(6,-11),(7,-3),(8,11),(9,3),(10,-10),(11,-2)


--IF @SelectedMaxDateInvest > @SelectedMaxDateFund
--begin



---------insert into Invesment level to find  LP Invesment contribution ---------------------------------------------------------------------


insert into @SelectedPhantomCalculation 
( FundId , ScenarioId,InvestmentId   , InvesmentCashFlowTypeId,IsActual ,Status , EventDate  , InvesmentCashFlow , LimitedPartnerPercent,LPInvesmentContribution,GPPercent , GPINvesmentContibution  )

select FundId , ScenarioId ,InvestmentId    , InvestmentCashflowTypeId ,IsActual , case when IsActual = 1 Then 'Actual' else 'Hypothetical' end Status ,EventDate  ,
      case when InvestmentCashflowTypeId IN (1,2,4,6) then (-1 *Equity)
	       when InvestmentCashflowTypeId IN (3,5,7,8) then (Equity) end as Equity  ,
	  LimitedPartnerPercent,
      case when IsActual = 1 and InvestmentCashflowTypeId IN  (1,2,4,6)  
	            then cast ( -1 *( (Equity * LimitedPartnerPercent) / 100 )  as decimal(30,2)) 
           when IsActual = 1 and InvestmentCashflowTypeId IN (3,5,7,8)  
	            then cast ( (Equity * LimitedPartnerPercent) / 100  as decimal(30,2)) 
           when IsActual = 0 and InvestmentCashflowTypeId IN (1,2,4,6) 
		        then cast ( -1 * ( (Equity * LimitedPartnerPercent) / 100 )  as decimal(30,2))
       else 0.00 End LPInvesmentContribution ,
	   (100 - LimitedPartnerPercent ) as GPPercent ,
	   case when IsActual = 1 and InvestmentCashflowTypeId IN (1,2,4,6) 
	            then cast ( -1 *( (Equity * (100 - LimitedPartnerPercent )) / 100 )  as decimal(30,2)) 
           when IsActual = 1 and InvestmentCashflowTypeId IN (3,5,7,8)  
	            then cast ( (Equity * (100 - LimitedPartnerPercent )) / 100  as decimal(30,2)) 
           when IsActual = 0 and InvestmentCashflowTypeId IN (1,2,4,6) 
		        then cast ( -1 * ( (Equity * (100 - LimitedPartnerPercent )) / 100 )  as decimal(30,2))
       else 0.00 End GPInvesmentContribution 
from   [OPGC].[OpgcInvestmentCashFlow] 
where FundId =  @FundId and ScenarioId = @NonBaseLineScenarioId and InvestmentId in ( select Id from @InvesmentIdNonBase) and InvestmentCashflowTypeId not in (100) and Isdeleted = 0
order by EventDate asc

--select * from @PhantomCalculation

---------To Insert ditinct Invesment id for initial CAsh flow -------------------------------------------------------------------------

insert into @SelectedInvesmentcashFlow 
select  FundId , ScenarioId ,InvestmentId    , InvesmentCashFlowTypeId , InvesmentCashFlow , LPInvesmentContribution
from   @SelectedPhantomCalculation 
where FundId =  @FundId and ScenarioId = @NonBaseLineScenarioId and InvesmentCashFlowTypeId  in (1) 

--select * from @InvesmentcashFlow

-------------------To find LP cost contribution FUnd level ----------------------------------------------------------------------------------------------

insert into @SelectedPhantomCalculation ( FundId , ScenarioId   , CashFlowTypeId ,IsActual ,  Status, EventDate, LimitedPartnerPercent , LPCostContribution,GPCostContribution )

select FundId , ScenarioId  , FundCashflowTypeId, IsActual , case when IsActual = 1 Then 'Actual' else 'Hypothetical' end Status , EventDate ,LimitedPartnerPercent 
       , case when FundCashflowTypeId in (6,7) then -1 * ( (ValueAmount * LimitedPartnerPercent) / 100 )  else ( (ValueAmount * LimitedPartnerPercent) / 100 ) end
	   	  , case when FundCashflowTypeId in (6,7) then -1 * ( (1-LimitedPartnerPercent/100) * ValueAmount )  
	         when FundCashflowTypeId in (8,9) then   ( (1-LimitedPartnerPercent/100) * ValueAmount ) 
			 else 0.00 end
	  -- ,ValueAmount
from  [OPGC].[OpgcFundCashFlow] 
where FundId =  @FundId and ScenarioId = @NonBaseLineScenarioId  and Isdeleted = 0
order by EventDate asc

declare @SelectedInitialCheckInvesmentCashflowTypeId int = ( select   count(1) from @SelectedPhantomCalculation where   InvesmentCashFlowTypeID in (3,5,7,8) )

if @SelectedInitialCheckInvesmentCashflowTypeId > 0
begin


;with SelectedLPInvestReturn
as
(
select   
 A.InvestmentId
,A.InvesmentCashFlowTypeId
,A.IsActual                                      
,A.EventDate                 
,A.LPInvesmentContribution
,case when A.InvesmentCashFlowTypeId IN (1,2,4,6) then 0.00
      when A.Isactual = 0 and A.InvesmentCashFlowTypeId IN (3,5,7,8) then A.InvesmentCashFlow
	  when A.Isactual = 1 and A.InvesmentCashFlowTypeId IN (3,5,7,8) then null end as InvesmentCashFlow
,B.IntialLPInvesmentContribution
 
from @SelectedPhantomCalculation A
left join @SelectedInvesmentcashFlow B
on A.FundId = B.FundId and A.ScenarioId = B.ScenarioId and A.InvestmentId = B.InvestmentId
where A.InvesmentCashFlowTypeId in (1,2,3,4,5,6,7,8)
)

insert into @SelectedLPInvestReturn ( 
InvesmentId                
,invesmentCashFlowTypeId    
,IsActual                   
,EventDate                  
,LPInvestContribution       
,InvestCashFlow             
,InitialLPInvest            
)

select   
 InvestmentId
,InvesmentCashFlowTypeId
,IsActual                                      
,EventDate                 
,LPInvesmentContribution
, abs(InvesmentCashFlow) as InvesmentCashFlow
,abs(IntialLPInvesmentContribution) as IntialLPInvesmentContribution
from SelectedLPInvestReturn 
--where InvesmentCashFlow is not null
order by InvestmentId ,EventDate asc


--select * from @LPInvestReturn




------------------------------

----------To Find First date for Phantom Calculation ---for positive cash flow inesment level and isactual is 0-------------------------------------------------

declare @SelectedInvesmnetInitialDate date = ( select DATEADD(q, DATEDIFF(q, 0, min(EventDate)), 0)  from  [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId 
                                              and ScenarioId = @NonBaseLineScenarioId and InvestmentId in ( select Id from @InvesmentIdNonBase) and InvestmentCashflowTypeId = 1 and Isdeleted = 0)
--select @InvesmnetInitialDate as InvesmnetInitialDate

declare @SelectedInvesmentMaxDate date = ( select DATEADD(q, DATEDIFF(q, 0, Max(EventDate)), 0) from  [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId 
                                          and ScenarioId = @NonBaseLineScenarioId  and InvestmentId in ( select Id from @InvesmentIdNonBase) and Isdeleted =0 )
--select @InvesmentMaxDate as InvesmentMaxDate


declare @SelectedFundMaxDate date = ( select DATEADD(q, DATEDIFF(q, 0, Max(EventDate)), 0) from  [OPGC].[OpgcFundCashFlow] where FundId =  @FundId 
                                      and ScenarioId = @NonBaseLineScenarioId and Isdeleted =0  )
--select @FundMaxDate as FundMaxDate


---------To Find Date  for Phantom ---------------------------------------------------------

If @SelectedFundMaxDate is not null
begin 


	;with SelectedManagmentFees as
	(
	   select   1 r,@SelectedFundMaxDate s , -3 as TypeId , 'Managment Fees Contribution' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) ,-3 as TypeId , 'Managment Fees Contribution' as CashflowType  from SelectedManagmentFees where r<=datediff(qq,@SelectedFundMaxDate,@SelectedInvesmentMaxDate) 
	)




	insert into @SelectedPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select @FundId , @NonBaseLineScenarioId ,  
	TypeId, CashflowType , s from SelectedManagmentFees 
	where  r not in(1)
	option (maxrecursion 1000)


-------------------------------------------------Other Partnership Expenses------------------------------------------------------------------

	;with SelectedOtherPartnerShipExpenses as
	(
	   select   1 r,@SelectedFundMaxDate s , -2 as TypeId , 'Other PartnerShip Expenses Contribution' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) , -2 as TypeId , 'Other PartnerShip Expenses Contribution' as CashflowType   from SelectedOtherPartnerShipExpenses where r<=datediff(qq,@SelectedFundMaxDate,@SelectedInvesmentMaxDate) 
	)

	insert into @SelectedPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @FundId , @NonBaseLineScenarioId ,  TypeId, CashflowType , s from SelectedOtherPartnerShipExpenses where  r not in(1)
	option (maxrecursion 1000)

---------------------------------------------------------OffsetByQuarter------------------------------------------------------------------------------


	;with SelectedOffsetBYQuarter as
	(
	   select   1 r,@SelectedFundMaxDate s , -1 as TypeId , 'Offset By Quarter' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) , -1 as TypeId , 'Offset By Quarter' as CashflowType   from SelectedOffsetBYQuarter where r<=datediff(qq,@SelectedFundMaxDate,@SelectedInvesmentMaxDate) 
	)

	insert into @SelectedPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @FundId , @NonBaseLineScenarioId ,  TypeId, CashflowType , s from SelectedOffsetBYQuarter where  r not in(1)
	option (maxrecursion 1000)


end
else 
begin



	;with SelectedManagmentFees as
	(
	   select   1 r,@SelectedInvesmnetInitialDate s , -3 as TypeId , 'Managment Fees Contribution' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) ,-3 as TypeId , 'Managment Fees Contribution' as CashflowType  from SelectedManagmentFees where r<=datediff(qq,@SelectedInvesmnetInitialDate,@SelectedInvesmentMaxDate) 
	)

	insert into @SelectedPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @FundId , @NonBaseLineScenarioId ,  TypeId, CashflowType , s from SelectedManagmentFees where  r not in(1)
	option (maxrecursion 1000)


-------------------------------------------------Other Partnership Expenses------------------------------------------------------------------

	;with SelectedOtherPartnerShipExpenses as
	(
	   select   1 r,@SelectedInvesmnetInitialDate s , -2 as TypeId , 'Other PartnerShip Expenses Contribution' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) , -2 as TypeId , 'Other PartnerShip Expenses Contribution' as CashflowType   from SelectedOtherPartnerShipExpenses where r<=datediff(qq,@SelectedInvesmnetInitialDate,@SelectedInvesmentMaxDate) 
	)

	insert into @SelectedPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @FundId , @NonBaseLineScenarioId ,  TypeId, CashflowType , s from SelectedOtherPartnerShipExpenses where  r not in(1)
	option (maxrecursion 1000)

---------------------------------------------------------OffsetByQuarter------------------------------------------------------------------------------


	;with SelectedOffsetBYQuarter as
	(
	   select   1 r,@SelectedInvesmnetInitialDate s , -1 as TypeId , 'Offset By Quarter' as CashflowType
	   union all 
	   select r+1, DATEADD(qq,1,s) , -1 as TypeId , 'Offset By Quarter' as CashflowType   from SelectedOffsetBYQuarter where r<=datediff(qq,@SelectedInvesmnetInitialDate,@SelectedInvesmentMaxDate) 
	)

	insert into @SelectedPhantomCalculation ( FundId , ScenarioId   , TypeId , CashflowType , EventDate)
	select  @FundId , @NonBaseLineScenarioId ,  TypeId, CashflowType , s from SelectedOffsetBYQuarter where  r not in(1)
	option (maxrecursion 1000)


end

----------------------To Find LP Cost Contribution-----for phantom data-------------------------------------------------------------------------------------------------------------------------------------------------------------------


insert into @SelectedLPCostContribution
(
 FundId                      
 ,ScenarioId                  
 ,InvestmentId                
 ,InvesmentCashFlowTypeId     
 ,CashFlowTypeId              
 ,IsActual                    
 ,[Status]                    
 ,TypeId                      
 ,CashflowType                
 ,EventDate                                
 ,InvesmentCashFlow           
 ,LimitedPartnerPercent       
 ,LPInvesmentContribution     
 ,LPCostContribution
 ,GPPercent
 , GPINvesmentContibution 
 ,GPCOstContribution
 )


select 
 A.FundId                 
,A.ScenarioId   
,A.InvestmentId
,A.InvesmentCashFlowTypeId
,A.CashFlowTypeId 
,A.IsActual
,A.Status                 
--,A.TypeId     
,case when A.TypeId is null and InvesmentCashFlowTypeId  = 1 then 1 
      when A.TypeId is null and InvesmentCashFlowTypeId  = 2 then 2 
	  when A.TypeId is null and InvesmentCashFlowTypeId  = 3 then 3
	  when A.TypeId is null and InvesmentCashFlowTypeId  = 4 then 4
	  when A.TypeId is null and InvesmentCashFlowTypeId  = 5 then 5
	  when A.TypeId is null and InvesmentCashFlowTypeId  = 6 then 6
	  when A.TypeId is null and InvesmentCashFlowTypeId  = 7 then 7
	  when A.TypeId is null and InvesmentCashFlowTypeId  = 8 then 8
	  when A.TypeId is null and CashFlowTypeId  = 6 then 9
	  when A.TypeId is null and CashFlowTypeId  = 7 then 10
	  when A.TypeId is null and CashFlowTypeId  = 8 then 11
	  when A.TypeId is null and CashFlowTypeId  = 9 then 12
	  when A.TypeId is not null  then A.TypeId end 
,A.CashflowType           
,A.EventDate 
--,QuarterDate            
,A.InvesmentCashFlow      
,A.LimitedPartnerPercent  
,isnull (A.LPInvesmentContribution,0.00) as  LPInvesmentContribution
, LPCostContribution = case when @SelectedManualStepdownDate IS null and TypeId = -3  and  A.EventDate < @SelectedCalculatedManualStepdownDate
                                then  -1 * cast ( (@SelectedCommittedCapital * @SelectedManagementFeePercent)/4 as decimal(30,2) )
							When @SelectedManualStepdownDate IS null and A.TypeId = -3 and  A.EventDate >= @SelectedCalculatedManualStepdownDate
                                then -1 * cast ((@SelectedSumOfNegativeInvestment * @SelectedManagementFeePercent)/4 as decimal(30,2) )
							When @SelectedManualStepdownDate is not null and A.TypeId = -3 and  A.EventDate < @SelectedManualStepdownDate
                                then -1* cast ((@SelectedCommittedCapital * @SelectedManagementFeePercent)/4 as decimal(30,2))
							When @SelectedManualStepdownDate is not null and A.TypeId = -3 and  A.EventDate >= @SelectedManualStepdownDate
                                then  -1 * cast ((@SelectedSumOfNegativeInvestment * @SelectedManagementFeePercent)/4  as decimal(30,2))
                            when A.TypeId = -2 then -1 * cast ( @SelectedOtherPartnershipFeesByQuarter as decimal(30,2))
							 when A.TypeId = -1 then cast ( @SelectOffsetByQuarter as decimal(30,2))
                       Else  LPCostContribution  end
 ,A.GPPercent
 , A.GPINvesmentContibution 
 ,isnull(A.GPCostContribution,0.00)
from @SelectedPhantomCalculation A
--left Join @SelectedTempGPCostContribution B
--On A.CashFlowTypeId = B.Id or A.TypeId = B.Id
order by A.EventDate ,A.TypeId asc

--select * from @SelectedLPCostContribution

-------------------------CHeck Invesment cashflow type id for postive cashflow ,is there present is actual status should be 0 then enter into waterfall calculation
---otherwise direct calculation in else block

declare @SelectedCheckInvesmentCashflowTypeId int = ( select   count(1) from @SelectedLPCostContribution where  IsActual = 0 and InvesmentCashFlowTypeID in (3,5,7,8) )

If @SelectedCheckInvesmentCashflowTypeId > 0
begin

-------------------------Water Fall :-  Step 1 LP Invest Calculation--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


declare @SelectedInvestmentIdValidate as table 
(Id int identity(1,1) , 
InvesmentId int)

insert into @SelectedInvestmentIdValidate   (InvesmentId)
select
InvesmentId from @SelectedLPInvestReturn group by InvesmentId

--select * from @InvestmentIdValidate
declare  @SelectedMinInvesmentId int = (select Min(Id) from @SelectedInvestmentIdValidate)
declare  @SelectedMaxInvesmentId int = (select Max(Id) from @SelectedInvestmentIdValidate)
declare  @SelectedInvesmentId int = (select InvesmentId from @SelectedInvestmentIdValidate where Id = @SelectedMinInvesmentId )
--select @MaxInvesmentId
while @SelectedMinInvesmentId <= @SelectedMaxInvesmentId
begin


declare @SelectedMinInitail date = (select MIN(EventDate) from @SelectedLPInvestReturn where InvesmentId = @SelectedInvesmentId and invesmentCashFlowTypeId = 1 )
--select @MinInitail as MinInitail

declare @SelectedMinPositiveDate date = (select MIN(EventDate) from @SelectedLPInvestReturn where   InvesmentId = @SelectedInvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and IsActual =0 )
--select @MinPositiveDate as MinPositiveDate

	  declare @SelectedNegativeValue decimal(30,2)  = (select abs(sum(isnull(LPInvestContribution,0.00))) from @SelectedLPInvestReturn where InvesmentId = @SelectedInvesmentId and invesmentCashFlowTypeId in (1,2,4,6) and EventDate between @SelectedMinInitail and @SelectedMinPositiveDate)
	  --select @NegativeValue as NegativeValue
      
	  declare @SelectedPositiveValue decimal(30,2)  = (select abs(sum(isnull(LPInvestContribution,0.00))) from @SelectedLPInvestReturn where InvesmentId = @SelectedInvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and EventDate between @SelectedMinInitail and @SelectedMinPositiveDate)
	--  select @PositiveValue as PositiveValue

	  declare @SelectedFinalValue decimal(30,2) = ( select abs(@SelectedNegativeValue - @SelectedPositiveValue) )


declare @SelectedMinPositiveId int = ( select Min(ID) from @SelectedLPInvestReturn where InvesmentId = @SelectedInvesmentId and EventDate = @SelectedMinPositiveDate and IsActual =0 )
--select @MinPositiveID as MinPositiveID

declare @SelectedMaxId int = ( select max(ID) from @SelectedLPInvestReturn )
--select @MinPositiveID as MinPositiveID


declare @SelectedMinLP decimal(30,2) = (select min(LPInvestContribution) from @SelectedLPInvestReturn where InvesmentId = @SelectedInvesmentId and EventDate = @SelectedMinInitail) 
--select @MInLP as MInLP

--declare @SelectedsumofNegative decimal(30,2) = (select isnull(SUM(LPInvestContribution),0.00) from @SelectedLPInvestReturn  where InvesmentId = @SelectedInvesmentId and invesmentCashFlowTypeId in (2,4,6)) 
----select @sumofNegative as sumofNegative

insert into @SelectedFinalLPInvestReturn

select *
, case when Id = @SelectedMinPositiveId and InvestCashFlow > @SelectedFinalValue Then @SelectedFinalValue
       when Id = @SelectedMinPositiveId and InvestCashFlow < @SelectedFinalValue Then InvestCashFlow 
	   when Id = @SelectedMinPositiveId and InvestCashFlow = @SelectedFinalValue Then @SelectedFinalValue
	   else NULL end as LPCost
from @SelectedLPInvestReturn
where InvesmentId = @SelectedInvesmentId 

--select * from @FinalLPcost

declare @SelectedCheckLPCost decimal(30,2) = ( select abs(LPInvestmentReturn) from @SelectedFinalLPInvestReturn where Id = @SelectedMinPositiveID and InvesmentId = @SelectedInvesmentId )
--select @CheckLPCost as CheckLPCost

--declare @SelectedRemainingLPInvest decimal(30,2) = ( select case when InvestCashFlow < InitialLPInvest then (InitialLPInvest - InvestCashFlow) else 0.00 end from @SelectedFinalLPInvestReturn 
--                                                    where Id = @SelectedMinPositiveId )

declare @SelectedRemainingLPInvest decimal(30,2) = ( select @SelectedFinalValue - @SelectedCheckLPCost )
--select @RemainingLPInvest as RemainingLPInvest

--declare  @BalanceSumofNegative decimal(30,2) = (select @sumofNegative + @RemainingLPInvest)

--select @BalanceSumofNegative as BalnacesumofNegative

--declare @SelectedFinalSumofNegative decimal(30,2) = (select @SelectedsumofNegative )

set @SelectedMinPositiveID = @SelectedMinPositiveID + 1

while @SelectedMinPositiveID <= @SelectedMaxId
begin

 set @SelectedRemainingLPInvest = @SelectedRemainingLPInvest

			  declare @SelectedIsactual Int = ( select count(1) from @SelectedFinalLPInvestReturn where Id = @SelectedMinPositiveID and InvesmentId = @SelectedInvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and IsActual = 0 )

			--  select @MinPositiveID as MinPositiveID

----------------------------------------------------------------------------------------------------------------
             declare @SelectedCheckRemainingLPInvest decimal(30,2)
			 declare @SelectedInvestCashFlow decimal(30,2)
			          If @SelectedMinPositiveID = @SelectedMinPositiveID and @SelectedIsactual = 1			 
			          begin

					   declare @SelectedCheckPreviousLPInvestReturn decimal(30,2) = ( select LPInvestmentReturn from @SelectedFinalLPInvestReturn where Id = @SelectedMinPositiveID-1 and InvesmentId = @SelectedInvesmentId )
			              update @SelectedFinalLPInvestReturn
                                 set LPInvestmentReturn = case when  InvestCashFlow > @SelectedRemainingLPInvest and @SelectedCheckPreviousLPInvestReturn != isnull(@SelectedRemainingLPInvest,0.00) Then @SelectedRemainingLPInvest
								 							   when  InvestCashFlow < @SelectedRemainingLPInvest and @SelectedCheckPreviousLPInvestReturn != isnull(@SelectedRemainingLPInvest,0.00) Then InvestCashFlow  
															   when  InvestCashFlow = @SelectedRemainingLPInvest and @SelectedCheckPreviousLPInvestReturn != isnull(@SelectedRemainingLPInvest,0.00) then @SelectedRemainingLPInvest 
														  Else 0.00 end
                                 where Id = @SelectedMinPositiveID 	and InvesmentId = @SelectedInvesmentId   

                            Set @SelectedCheckRemainingLPInvest = ( select LPInvestmentReturn from @SelectedFinalLPInvestReturn where Id = @SelectedMinPositiveID and InvesmentId = @SelectedInvesmentId )
							Set @SelectedInvestCashFlow  = ( select InvestCashFlow from @SelectedFinalLPInvestReturn where Id = @SelectedMinPositiveID and InvesmentId = @SelectedInvesmentId )

							if @SelectedCheckRemainingLPInvest <= @SelectedInvestCashFlow
							    begin
							    set @SelectedRemainingLPInvest = ( @SelectedRemainingLPInvest - @SelectedCheckRemainingLPInvest ) 
								--select @RemainingLPInvest
								end
							--else
							--	begin
							--	set @SelectedRemainingLPInvest = ( select @SelectedRemainingLPInvest - @SelectedInvestCashFlow )
							--	update @SelectedFinalLPInvestReturn
       --                          set LPInvestmentReturn = case when  InvestCashFlow > @SelectedRemainingLPInvest Then @SelectedRemainingLPInvest
							--	 							   when  InvestCashFlow < @SelectedRemainingLPInvest Then InvestCashFlow  
							--								   when  InvestCashFlow = @SelectedRemainingLPInvest then @SelectedRemainingLPInvest end
       --                          where Id = @SelectedMinPositiveID 	and InvesmentId = @SelectedInvesmentId  
								 
							--	 set @SelectedRemainingLPInvest = @SelectedRemainingLPInvest
							--	-- select @RemainingLPInvest
							--	 end
			                    
								
					  end
					  else 
					      begin
			                   update @SelectedFinalLPInvestReturn
                                      set LPInvestmentReturn = 0.00                                                                			            
                                      where Id = @SelectedMinPositiveID 	and InvesmentId = @SelectedInvesmentId 		
								set @SelectedRemainingLPInvest = @SelectedRemainingLPInvest	  
					      end
			     --set @RemainingLPInvest = @RemainingLPInvest
				 --select @RemainingLPInvest as RemainingLPInvest
			     
			     declare @SelectedNegativeInvestCashFlow decimal(30,2)  = isnull(( select abs(isnull(LPInvestContribution,0.00) ) from @SelectedFinalLPInvestReturn where Id = @SelectedMinPositiveID and InvesmentId = @SelectedInvesmentId and invesmentCashFlowTypeId in (2,4,6)  ),0.00)
				 --select @NegativeInvestCashFlow as NegativeInvestCashFlow
			     declare @SelectedPositiveInvestCashFlow decimal(30,2)  = isnull(( select isnull(LPInvestContribution,0.00) from @SelectedFinalLPInvestReturn where Id = @SelectedMinPositiveID and InvesmentId = @SelectedInvesmentId and invesmentCashFlowTypeId in (3,5,7,8) and IsActual =1 ),0.00)
				-- select @PositiveInvestCashFlow as PositiveInvestCashFlow
			    set @SelectedRemainingLPInvest = abs( isnull( @SelectedRemainingLPInvest + @SelectedNegativeInvestCashFlow - @SelectedPositiveInvestCashFlow  ,0.00))
				--select @RemainingLPInvest as RemainingLPInvest
			   --select @RemainingLPInvest
			   set @SelectedMinPositiveID = @SelectedMinPositiveID + 1
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			  








--declare @SelectedCheckLPCost1 decimal(30,2) = ( select LPInvestmentReturn from @SelectedFinalLPInvestReturn where Id = @SelectedMinPositiveID and InvesmentId = @SelectedInvesmentId )
----select @CheckLPCost1 as CheckLPCost
----select @sumofNegative as InitialsumofNegative

--If @SelectedMInLP = @SelectedCheckLPCost1
--begin
--print'IF'
--set @SelectedFinalSumofNegative =  @SelectedFinalSumofNegative

--end
--else
--begin
--Print'Else'
--     If @SelectedsumofNegative = 0
--     begin
--     set @SelectedFinalSumofNegative = @SelectedRemainingLPInvest
--     end
--     else
--     begin
--     set @SelectedFinalSumofNegative = (@SelectedFinalSumofNegative- @SelectedCheckLPCost1)
--     end
--end

----declare @


--update @SelectedFinalLPInvestReturn
--set LPInvestmentReturn = case when  InvestCashFlow > @SelectedFinalSumofNegative Then @SelectedFinalSumofNegative
--                             when  InvestCashFlow < @SelectedFinalSumofNegative Then InvestCashFlow  
--			                 when InvestCashFlow = @SelectedFinalSumofNegative then @SelectedFinalSumofNegative end
--where Id = (@SelectedMinPositiveID + 1 )	and InvesmentId = @SelectedInvesmentId         

--set @SelectedMinPositiveID = @SelectedMinPositiveID + 1

--set @SelectedFinalSumofNegative = @SelectedFinalSumofNegative
----select @sumofNegative as FinalSumOfNegative

end

set @SelectedMinInvesmentId = @SelectedMinInvesmentId + 1
--select @MinInvesmentId
set @SelectedInvesmentId  = (select InvesmentId from @SelectedInvestmentIdValidate where Id = @SelectedMinInvesmentId )
--select @InvesmentId
End


--select 
--Id  ,
--InvesmentId,
--invesmentCashFlowTypeId ,
--IsActual ,
--EventDate ,
--LPInvestContribution ,
--InvestCashFlow ,
--InitialLPInvest ,
----SumOfNegative decimal(30,2),
--abs(LPInvestmentReturn) as LPInvestmentReturn
--from @SelectedFinalLPInvestReturn

---------------------------------xxxxxxxxxxxxxxxxxxx----------------Step1 LPInvestReturn Completed xxxxxxxxxxxxxxxxxxx-------------------------------------------------------------------------------------------------------

--------------Remain after Step1 -----------------------------------------------------
; with SelectedRemainLPInvestReturn
as
(
select 

  A.FundId                      
 ,A.ScenarioId                  
 ,A.InvestmentId                
 ,A.InvesmentCashFlowTypeId     
 ,A.CashFlowTypeId              
 ,A.IsActual                    
 ,A.[Status]                    
 ,A.TypeId                      
 ,A.CashflowType                
 ,A.EventDate                                
 ,A.InvesmentCashFlow  
 ,A.LimitedPartnerPercent       
 ,A.LPInvesmentContribution     
 ,A.LPCostContribution 
 ,Abs(B.LPInvestmentReturn) LPInvestmentReturn
 ,A.GPPercent
 ,A.GPINvesmentContibution 
 ,A.GPCOstContribution

from @SelectedLPCostContribution A
Left Join @SelectedFinalLPInvestReturn B
on A.InvestmentId = B.InvesmentId and A.InvesmentCashFlowTypeId = B.invesmentCashFlowTypeId and A.IsActual = B.IsActual
and A.EventDate = B.EventDate and A.InvesmentCashFlow =B.InvestCashFlow
order by A.Eventdate ,A.TypeId
offset 0 rows

)

Insert into @SelectedCumalativeLPCostReturn
(                     
FundId                        
,ScenarioId                    
,InvestmentId                  
,InvesmentCashFlowTypeId       
,CashFlowTypeId                
,IsActual                      
,[Status]                      
,TypeId                        
,CashflowType                  
,EventDate                     
,InvesmentCashFlow             
,LimitedPartnerPercent         
,LPInvesmentContribution       
,LPCostContribution            
,LPInvesmentReturn             
,RemainLPInvesmentReturnSteps
,GPPercent
, GPINvesmentContibution 
,GPCOstContribution
)

select 

  FundId                      
 ,ScenarioId                  
 ,InvestmentId                
 ,InvesmentCashFlowTypeId     
 ,CashFlowTypeId              
 ,IsActual                    
 ,[Status]                    
 ,TypeId                      
 ,CashflowType                
 ,EventDate                                
 ,InvesmentCashFlow  
 ,LimitedPartnerPercent       
 ,LPInvesmentContribution     
 ,LPCostContribution 
 ,LPInvestmentReturn
 ,case when LPInvestmentReturn is not null then ( InvesmentCashFlow - LPInvestmentReturn ) else null end as RemainLPInvesmentReturn
 ,GPPercent
 , GPINvesmentContibution 
 ,GPCOstContribution
from SelectedRemainLPInvestReturn
order by Eventdate ,TypeId

---------------To Stop the Cumalative Value -------------------------------------------------------------------------------

declare @SelectedBeforeCumalativeDate date = ( Select MIN(EventDate)   from  [OPGC].[OpgcInvestmentCashFlow] where FundId =  @FundId and ScenarioId = @NonBaseLineScenarioId 
                                              and IsActual = 0 and InvestmentCashflowTypeId in (3,5,7,8) and Isdeleted =0 )

--select @BeforeCumalativeDate BeforeCumalativeDate

-------------------------------------------------------------------------------------------------------------------------------------


;with SelectedCumalativeLPCostContibution
as
(
select 
ID
,FundId                        
,ScenarioId                    
,InvestmentId                  
,InvesmentCashFlowTypeId       
,CashFlowTypeId                
,IsActual                      
,[Status]                      
,TypeId                        
,CashflowType                  
,EventDate                                    
,InvesmentCashFlow             
,LimitedPartnerPercent         
,LPInvesmentContribution
,LPCostContribution
,LPInvesmentReturn             
,RemainLPInvesmentReturnSteps                                        
,Sum (LPCostContribution) Over (Order By ID ) as CumaltiveLPCostContibution 
,GPPercent
, GPINvesmentContibution
,GPCOstContribution
from @SelectedCumalativeLPCostReturn
)

--select * from CumalativeLPCostContibution
insert into @SelectedLPCostReturn
(
ID                          
,FundId                      
,ScenarioId                  
,InvestmentId                
,InvesmentCashFlowTypeId     
,CashFlowTypeId              
,IsActual                    
,[Status]                    
,TypeId                      
,CashflowType                
,EventDate                   
,InvesmentCashFlow           
,LimitedPartnerPercent       
,LPInvesmentContribution     
,LPCostContribution          
,LPInvesmentReturn           
,RemainLPInvesmentReturnSteps
,LPCostReturn                
,CumalativeLPCostContibution  
,RemainLPCostReturn
,GPPercent
, GPINvesmentContibution 
,GPCOstContribution
)
select 
ID
,FundId                        
,ScenarioId                    
,InvestmentId                  
,InvesmentCashFlowTypeId       
,CashFlowTypeId                
,IsActual                      
,[Status]                      
,TypeId                        
,CashflowType                  
,EventDate                                    
,InvesmentCashFlow             
,LimitedPartnerPercent         
,LPInvesmentContribution       
,LPCostContribution            
,LPInvesmentReturn           
,RemainLPInvesmentReturnSteps
,0.00 LPCostReturn   
,case when  @SelectedBeforeCumalativeDate > EventDate then isnull(CumaltiveLPCostContibution,0.00) else 0.00 End as CumalativeLPCostContibution
, 0.00 RemainLPCostReturn  
,GPPercent
, GPINvesmentContibution 
,GPCOstContribution
from SelectedCumalativeLPCostContibution
order by Eventdate ,TypeId

--select * from @LPCostReturn


Declare @SelectedUpdateLPCostReturn as table
( Id                           int, 
LPCostContribution             decimal(30,2),
Step1LPInvestReturn            decimal(30,2),
Step2LPCostReturn              decimal(30,2),
CumalativeLPCostContribution   decimal(30,2)
)


insert into @SelectedUpdateLPCostReturn (
 Id                        
,LPCostContribution          
,Step1LPInvestReturn         
,Step2LPCostReturn           
,CumalativeLPCostContribution
)

select 
 Id                        
,LPCostContribution          
,RemainLPInvesmentReturnSteps         
,LPCostReturn           
,CumalativeLPCostContibution
from @SelectedLPCostReturn

--select * from @UpdateLPCostReturn

Declare @Selectedmin int = (Select min(Id) from @SelectedUpdateLPCostReturn where Step1LPInvestReturn is not NULL)
 
--select @min

Declare @Selectedmax int = (Select max(Id) from @SelectedUpdateLPCostReturn )
--select @max



--SELECT * from @UpdateLPCostReturn

while (@Selectedmin <= @Selectedmax)
begin

declare @SelectedStep1LPInvestReturn decimal(30,2) = ( select Step1LPInvestReturn from @SelectedUpdateLPCostReturn where Id = @Selectedmin)
--select @Step1LPInvestReturn as Step1LPInvestReturn
If @SelectedStep1LPInvestReturn is not null
begin
Declare @SelectedTestLP as table (id int,  step1LPremain decimal(30,2), flag int, result int)
insert into @SelectedTestLP
SELECT Id,Step1LPInvestReturn, case when Step1LPInvestReturn > 0 then 1 else 0 end as flag, LAG(CumalativeLPCostContribution) over (order by id) as result 
from @SelectedUpdateLPCostReturn  where Id in (@Selectedmin, @Selectedmin-1)


--select * from  @TestLP

update L
SET Step2LPCostReturn = Case when T.flag = 0 then 0 else IIF(L.Step1LPInvestReturn > ABS(T.Result), ABS(T.Result), L.Step1LPInvestReturn) END
FROM @SelectedUpdateLPCostReturn L
inner join @SelectedTestLP T
ON T.id = L.Id
WHERE L.Id = @Selectedmin

--SELECT * from @UpdateLPCostReturn

Update L
SET CumalativeLPCostContribution = L.Step2LPCostReturn + T.result
FROM @SelectedUpdateLPCostReturn L
inner join @SelectedTestLP T 
ON T.id = L.Id
WHERE L.Id = @Selectedmin



DECLARE @SelectedCumalativeLPCostContribution DECIMAL(30,2) = ( select ISNULL(CumalativeLPCostContribution,0.00) from @SelectedUpdateLPCostReturn where Id = @Selectedmin )
dECLARE @SelectedLPCostContributionUpdate DECIMAL(30,2) =  (select     ISNULL(LPCostContribution,0.00) from @SelectedUpdateLPCostReturn where Id = @Selectedmin+1)

UPDATE @SelectedUpdateLPCostReturn
SET CumalativeLPCostContribution = @SelectedCumalativeLPCostContribution + @SelectedLPCostContributionUpdate
WHERE Id  =  @Selectedmin+1

end
else 
begin

DECLARE @SelectedCumalativeLPCostContributionElse DECIMAL(30,2) = ( select ISNULL(CumalativeLPCostContribution,0.00) from @SelectedUpdateLPCostReturn where Id = @Selectedmin )
dECLARE @SelectedLPCostContributionElse DECIMAL(30,2) =  (select ISNULL(LPCostContribution,0.00) from @SelectedUpdateLPCostReturn where Id = @Selectedmin+1)


UPDATE @SelectedUpdateLPCostReturn
SET CumalativeLPCostContribution = @SelectedCumalativeLPCostContributionElse + @SelectedLPCostContributionElse
WHERE Id  =  @Selectedmin+1

end


SET @Selectedmin = @Selectedmin+1
END

--SELECT * from @UpdateLPCostReturn

-------------------------------------------To find Step 3  WaterfallCalculation --------------------------------------------------

declare @SelectedMinPositiveDateStep3 date = (select MIN(EventDate) from @SelectedLPCostReturn where    invesmentCashFlowTypeId in (3,5,7,8) and IsActual =0  )
--select @MinPositiveDateStep3 as MinPositiveDate

declare @SelectedMinPositiveIdStep3 int = ( select Min(ID) from @SelectedLPCostReturn where  EventDate = @SelectedMinPositiveDateStep3 and IsActual =0 )
--select @MinPositiveIdStep3 as MinPositiveID

declare @SelectedMaxPositiveIdStep3 int = ( select Max(ID) from @SelectedLPCostReturn     )

--declare @MinDate date = (select MIN(EventDate) from @LPCostReturn )
--select @MinPositiveDateStep3 as MinPositiveDate

Insert into @SelectedFinalLPCostReturn
( 
 ID                          
,FundId                      
,ScenarioId                  
,InvestmentId                
,InvesmentCashFlowTypeId     
,CashFlowTypeId              
,IsActual                    
,[Status]                    
,TypeId                      
,CashflowType                
,EventDate                   
,InvesmentCashFlow           
,LimitedPartnerPercent       
,LPInvesmentContribution     
,LPCostContribution          
,LPInvesmentReturn           
,RemainLPInvesmentReturnSteps
,LPCostReturn                
,CumalativeLPCostContibution 
,RemainLPCostReturn          
,TotalLPContibution          
,TotalLPReturn               
,NetLPContribution  
,CumaltiveNetLPContibution
,GPPercent
, GPINvesmentContibution 
,GPCOstContribution
 ,TotalGPContribution          
 ,TotalGPReturn                
 ,NetGPContribution			
 ,CumaltiveNetGPContibution	
)

select
 A.ID                               
,A.FundId                           
,A.ScenarioId                       
,A.InvestmentId                     
,A.InvesmentCashFlowTypeId          
,A.CashFlowTypeId                   
,A.IsActual                         
,A.[Status]                         
,A.TypeId                           
,A.CashflowType                     
,A.EventDate                                           
,A.InvesmentCashFlow                
,A.LimitedPartnerPercent            
,A.LPInvesmentContribution          
,A.LPCostContribution               
,A.LPInvesmentReturn           
,A.RemainLPInvesmentReturnSteps
,B.Step2LPCostReturn                
,B.CumalativeLPCostContribution     
--,A.RemainLPCostReturn  
,A.RemainLPInvesmentReturnSteps - B.Step2LPCostReturn  as RemainLPCostReturn
-- ,case when A.ID < @MinPositiveIdStep3 then (isnull(A.LPInvesmentContribution,0.00) +  isnull(A.LPCostContribution,0.00) ) else 0.00 end as TotalLPContribution
  ,case when A.InvesmentCashFlowTypeId  IN (3,5,7,8) and IsActual = 0 then  0.00 else (isnull(A.LPInvesmentContribution,0.00) +  isnull(A.LPCostContribution,0.00) ) end as TotalLPContribution
 ,case when A.ID < @SelectedMinPositiveIdStep3 then (isnull(A.LPInvesmentReturn,0.00) + isnull(B.Step2LPCostReturn,0.00)) else 0.00 end  as TotalLPReturn

 , ( case when A.InvesmentCashFlowTypeId  IN (3,5,7,8) and IsActual = 0 then  0.00 else (isnull(A.LPInvesmentContribution,0.00) +  isnull(A.LPCostContribution,0.00) ) end + 
   case when A.ID < @SelectedMinPositiveIdStep3 then (isnull(A.LPInvesmentReturn,0.00) + isnull(B.Step2LPCostReturn,0.00)) else 0.00 end ) as NetLPContribution

 ,case when A.ID < @SelectedMinPositiveIdStep3 then Sum ( (isnull(A.LPInvesmentContribution,0.00) +  isnull(A.LPCostContribution,0.00)) + (isnull(A.LPInvesmentReturn,0.00) + isnull(B.Step2LPCostReturn,0.00)) ) Over (Order By A.ID )
       else 0.00 end  as CumaltiveNetLPContibution 
 ,GPPercent
 , GPINvesmentContibution 
 ,GPCOstContribution
 ,case when A.InvesmentCashFlowTypeId  IN (3,5,7,8) and IsActual = 0 then  0.00 else (isnull(A.GPINvesmentContibution,0.00) +  isnull(A.GPCOstContribution,0.00) ) end as TotalGPContribution
 , 0 as TotalGPReturn
 , ( case when A.InvesmentCashFlowTypeId  IN (3,5,7,8) and IsActual = 0 then  0.00 else (isnull(A.GPINvesmentContibution,0.00) +  isnull(A.GPCOstContribution,0.00) ) end +
      0 ) as NetGPContribution 
 ,case when A.ID < @SelectedMinPositiveIdStep3 then Sum ( (isnull(A.GPINvesmentContibution,0.00) +  isnull(A.GPCOstContribution,0.00) ) + 0 ) Over (Order By A.ID )
       else 0.00 end  as CumaltiveNetGPContibution 
from @SelectedLPCostReturn A
inner join @SelectedUpdateLPCostReturn B
on A.ID = B.Id

--select * from @FinalLPCostReturn


declare @SelectedLPPreferedReturn decimal(30,5) = ( select LPPreferredReturnPercent from [OPGC].[OpgcScenario] where FundID = @FundId and ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )
set @SelectedLPPreferedReturn = ( 1 + (@SelectedLPPreferedReturn/100) )

declare @SelectedGPPreferedReturn decimal(30,5) = ( select GPPreferredReturnPercent from [OPGC].[OpgcScenario] where FundID = @FundId and ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )
set @SelectedGPPreferedReturn = ( 1 + (@SelectedGPPreferedReturn/100) )

declare @SelectedLPFinalShare decimal(30,2) = ( select LPFinalSharePercent from [OPGC].[OpgcScenario] where FundID = @FundId and ScenarioId = @NonBaseLineScenarioId and Isdeleted = 0 )


--declare @TestStep3 as table
--( Id                          int ,
--InvesmentCashFlowTypeID       int,
--IsActual                      int,
--EventDate                     date,
--MinDate                       date,
--LPPreferedReturn            decimal(30,2),
--NetLPContribution             Decimal(30,2),
--CumalativeNetLPContribution  decimal(30,2),
--GPPreferedReturn            decimal(30,2),
--NetGPContribution            decimal (30,2),
--CumalativeNetGPContribution  decimal(30,2)

--)

declare @SelectedFinalTestStep3 as table
( 
Id                          int ,
InvesmentCashFlowTypeID       int,
IsActual                      int,
EventDate                     date,
MaxDate                      date,
[YearDiffernce/365]          decimal(30,12),
[1+LPPreferedReturn]        decimal(18,12),
LogLPPreferedReturn           Decimal(30,12),
NetLPContribution             Decimal(30,2),
PowerNetLP                   Decimal(30,2),
CumalativeNetLPContribution  decimal(30,2),
LPPreferredReturnThreshold    decimal(30,2),
[1+GPPreferedReturn]        decimal(18,12),
LogGPPreferedReturn           Decimal(30,12),
NetGPContribution             Decimal(30,2),
PowerNetGP                   Decimal(30,2),
CumalativeNetGPContribution  decimal(30,2),
GPPreferredReturnThreshold    decimal(30,2),
GPPreferredReturn            decimal(30,2),
RemainGPPreferredReturn      decimal(30,2)
)



while @SelectedMinPositiveIDStep3 <= @SelectedMaxPositiveIdStep3

begin

set @SelectedMinPositiveDateStep3  = (select MIN(EventDate) from @SelectedLPCostReturn where  Id = @SelectedMinPositiveIdStep3  )
--select  @MinPositiveIdStep3 as MinPositiveIdStep3

declare @SelectedCheckInvesmentCashFlowID int = ( select count(1) from @SelectedLPCostReturn where  Id = @SelectedMinPositiveIdStep3 and IsActual = 0 and InvesmentCashFlowTypeID in (3,5,7,8) )
--select @CheckInvesmentCashFlowID as CheckInvesmentCashFlowID

IF @SelectedMinPositiveIdStep3 = @SelectedMinPositiveIdStep3 and @SelectedCheckInvesmentCashFlowID >= 1
begin

delete from  @SelectedFinalTestStep3

Insert into @SelectedFinalTestStep3
(
Id                         
,InvesmentCashFlowTypeID    
,IsActual                   
,EventDate                  
,MaxDate                    
,[YearDiffernce/365]        
,[1+LPPreferedReturn]       
,LogLPPreferedReturn        
,NetLPContribution          
,PowerNetLP                 
,CumalativeNetLPContribution
,[1+GPPreferedReturn]       
,LogGPPreferedReturn        
,NetGPContribution          
,PowerNetGP                 
,CumalativeNetGPContribution
--,GPPreferredReturnThreshold 
)




select ID
,InvesmentCashFlowTypeId
,IsActual
,EventDate
--,MinDate
,@SelectedMinPositiveDateStep3 as MaxDate
--, cast ( datediff(day,EventDate ,@MinPositiveDate) as decimal(30,10))  as YearDiffernce 
, cast ( ( cast ( datediff(day,EventDate ,@SelectedMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12)) as [YearDiffernce/365] 
,@SelectedLPPreferedReturn as [1+LPPreferedReturn]
,cast (POWER(@SelectedLPPreferedReturn,cast ( ( cast ( datediff(day,EventDate ,@SelectedMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12))) as decimal(30,12)) as LogLPPreferedReturn
,NetLPContribution
,  cast ( ( NetLPContribution * cast (POWER(@SelectedLPPreferedReturn,cast ( ( cast ( datediff(day,EventDate ,@SelectedMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12))) as decimal(30,12)) ) as decimal(30,12)) as PowerNetLP
,CumaltiveNetLPContibution 

,@SelectedGPPreferedReturn as [1+GPPreferedReturn]
,cast (POWER(@SelectedGPPreferedReturn,cast ( ( cast ( datediff(day,EventDate ,@SelectedMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12))) as decimal(30,12)) as LogGPPreferedReturn
,NetGPContribution
,  cast ( ( NetGPContribution * cast (POWER(@SelectedGPPreferedReturn,cast ( ( cast ( datediff(day,EventDate ,@SelectedMinPositiveDateStep3) as decimal(30,12)) / 365 ) as decimal(30,12))) as decimal(30,12)) ) as decimal(30,12)) as PowerNetGP
,CumaltiveNetGPContibution 

from @SelectedFinalLPCostReturn

--select * from @FinalTestStep3


declare @SelectedCumalativeNetLPContribution decimal(30,10) = (select CumalativeNetLPContribution from @SelectedFinalTestStep3 Where Id = (@SelectedMinPositiveIdStep3-1)  )
--select @CumalativeNetLPContribution as CumalativeNetLPContribution

declare @SelectedCumalativeNetGPContribution decimal(30,10) = (select CumalativeNetGPContribution from @SelectedFinalTestStep3 Where Id = (@SelectedMinPositiveIdStep3-1)  )
--select @CumalativeNetGPContribution as CumalativeNetGPContribution






declare @SelectedSumofPowerNetLP decimal(30,10) = (select SUM(PowerNetLP) from @SelectedFinalTestStep3 where Id < @SelectedMinPositiveIDStep3  )
declare @SelectedSumofPowerNetGP decimal(30,10) = (select SUM(PowerNetGP) from @SelectedFinalTestStep3 where Id < @SelectedMinPositiveIDStep3  )

--select @SumofPowerNetLP as SumofPowerNetLP
--select @SumofPowerNetGP as SumofPowerNetGP
--select @MinPositiveIdStep3 as MinPositiveIdStep3



--declare @LPPreferredReturnThreshold decimal(30,2) = ( select isnull( (- @SumofPowerNetLP) - ( - @CumalativeNetLPContribution ), 0.00) )
--declare @PPreferredReturnThreshold decimal(30,2) = ( select 

IF @SelectedCumalativeNetLPContribution < 0
BEGIN

update @SelectedFinalTestStep3
set LPPreferredReturnThreshold = case when isnull( (- @SelectedSumofPowerNetLP) - ( - @SelectedCumalativeNetLPContribution ), 0.00) < 0 then 0.00 else isnull( (- @SelectedSumofPowerNetLP) - ( - @SelectedCumalativeNetLPContribution ), 0.00) end   
    --GPPreferredReturnThreshold =  case when isnull( (- @SelectedSumofPowerNetGP) - ( - @SelectedCumalativeNetGPContribution ) , 0.00) < 0 then 0.00 else isnull( (- @SelectedSumofPowerNetGP) - ( - @SelectedCumalativeNetGPContribution ) , 0.00) end
from  @SelectedFinalTestStep3
where Id = @SelectedMinPositiveIdStep3
END
ELSE
BEGIN
update @SelectedFinalTestStep3
set LPPreferredReturnThreshold =  0.00

from  @SelectedFinalTestStep3
where Id = @SelectedMinPositiveIdStep3
END

IF @SelectedCumalativeNetGPContribution < 0
BEGIN

update @SelectedFinalTestStep3
set  GPPreferredReturnThreshold =  case when isnull( (- @SelectedSumofPowerNetGP) - ( - @SelectedCumalativeNetGPContribution ) , 0.00) < 0 then 0.00 else isnull( (- @SelectedSumofPowerNetGP) - ( - @SelectedCumalativeNetGPContribution ) , 0.00) end
from  @SelectedFinalTestStep3
where Id = @SelectedMinPositiveIdStep3
END
ELSE
BEGIN
update @SelectedFinalTestStep3
set GPPreferredReturnThreshold =  0.00

from  @SelectedFinalTestStep3
where Id = @SelectedMinPositiveIdStep3
END

--select * from @FinalTestStep3

Declare @SelectedLPPreferredReturnThreshold decimal(30,2) = ( select ISnull(LPPreferredReturnThreshold,0.00) from @SelectedFinalTestStep3 where Id = @SelectedMinPositiveIdStep3)
declare @SelectedRemianLPCostReturn decimal(30,2) = ( select Isnull(RemainLPCostReturn,0.00) from @SelectedFinalLPCostReturn where Id = @SelectedMinPositiveIdStep3)

Declare @SelectedGPPreferredReturnThreshold decimal(30,2) = ( select isnull(GPPreferredReturnThreshold,0.00) from @SelectedFinalTestStep3 where Id = @SelectedMinPositiveIdStep3)
--declare @RemianGPCostReturn decimal(30,2) = ( select RemainGPCostReturn from @FinalLPCostReturn where Id = @MinPositiveIdStep3)


Update A
set A.LPPreferredReturnThreshold = isnull(B.LPPreferredReturnThreshold,0.00) ,
A.LPPreferrefReturn = case when @SelectedRemianLPCostReturn > 0 and @SelectedRemianLPCostReturn >= B.LPPreferredReturnThreshold then Isnull(B.LPPreferredReturnThreshold,0.00)
                           when @SelectedRemianLPCostReturn > 0 and @SelectedRemianLPCostReturn < B.LPPreferredReturnThreshold then isnull(@SelectedRemianLPCostReturn,0.00)
						   when @SelectedRemianLPCostReturn <= 0   then 0.00 end ,
A.RemainLPPreferrefReturn =  ( @SelectedRemianLPCostReturn - case when @SelectedRemianLPCostReturn > 0 and @SelectedRemianLPCostReturn >= B.LPPreferredReturnThreshold then isnull(B.LPPreferredReturnThreshold,0.00)
                                                     when @SelectedRemianLPCostReturn > 0 and @SelectedRemianLPCostReturn < B.LPPreferredReturnThreshold then isnull(@SelectedRemianLPCostReturn,0.00)
						                             when @SelectedRemianLPCostReturn <= 0   then 0.00 end ) ,
 
 A.GPPreferredReturnThreshold = isnull(B.GPPreferredReturnThreshold ,0.00)

from @SelectedFinalLPCostReturn A
join @SelectedFinalTestStep3 B
on A.ID = B.Id
where A.ID = @SelectedMinPositiveIdStep3

declare @SelectedRemianLPPreferredReturn decimal(30,2) = ( select isnull(RemainLPPreferrefReturn,0.00) from @SelectedFinalLPCostReturn where Id = @SelectedMinPositiveIdStep3)


Update A
set A.GPPreferrefReturn = case when @SelectedRemianLPPreferredReturn > 0 and @SelectedRemianLPPreferredReturn >= B.GPPreferredReturnThreshold then isnull(B.GPPreferredReturnThreshold,0.00)
                               when @SelectedRemianLPPreferredReturn > 0 and @SelectedRemianLPPreferredReturn < B.GPPreferredReturnThreshold then isnull(@SelectedRemianLPPreferredReturn,0.00)
						       when @SelectedRemianLPPreferredReturn <= 0   then 0.00 end ,
A.RemainGPPreferrefReturn =  ( @SelectedRemianLPPreferredReturn - case when @SelectedRemianLPPreferredReturn > 0 and @SelectedRemianLPPreferredReturn >= B.GPPreferredReturnThreshold then isnull(B.GPPreferredReturnThreshold,0.00)
                                                                        when @SelectedRemianLPPreferredReturn > 0 and @SelectedRemianLPPreferredReturn < B.GPPreferredReturnThreshold then isnull(@SelectedRemianLPPreferredReturn,0.00)
						                                                when @SelectedRemianLPPreferredReturn <= 0   then 0.00 end ) 

from @SelectedFinalLPCostReturn A
join @SelectedFinalTestStep3 B
on A.ID = B.Id
where A.ID = @SelectedMinPositiveIdStep3



Update @SelectedFinalLPCostReturn

set FinalLPReturn = isnull( RemainGPPreferrefReturn * (@SelectedLPFinalShare/100),0.00) ,
FinalGPReturn = isnull(RemainGPPreferrefReturn * ( 1 - (@SelectedLPFinalShare /100)),0.00)
where ID = @SelectedMinPositiveIdStep3

Update @SelectedFinalLPCostReturn

set TotalLPReturn = isnull( LPInvesmentReturn + LPCostReturn + LPPreferrefReturn + FinalLPReturn,0.00) ,
NetLPContribution = isnull( TotalLPContibution + ( LPInvesmentReturn + LPCostReturn + LPPreferrefReturn + FinalLPReturn),0.00),
CumaltiveNetLPContibution = isnull( @SelectedCumalativeNetLPContribution + (  TotalLPContibution + ( LPInvesmentReturn + LPCostReturn + LPPreferrefReturn + FinalLPReturn) ),0.00) ,
TotalGPReturn = isnull(GPPreferrefReturn + FinalGPReturn,0.00),
NetGPContribution = isnull(TotalGPContribution + ( GPPreferrefReturn + FinalGPReturn ) ,0.00),
CumaltiveNetGPContibution = isnull(@SelectedCumalativeNetGPContribution + (  TotalGPContribution + ( GPPreferrefReturn + FinalGPReturn ) ),0.00)
where ID = @SelectedMinPositiveIdStep3


Update B
Set B.CumalativeNetLPContribution = A.CumaltiveNetLPContibution,
B.CumalativeNetGPContribution = A.CumaltiveNetGPContibution

from @SelectedFinalLPCostReturn A
join @SelectedFinalTestStep3 B
on A.ID = B.Id
where A.ID = @SelectedMinPositiveIdStep3

end
else
begin

declare @SelectedElseCumalativeNetLPContribution decimal(30,10) = (select CumalativeNetLPContribution from @SelectedFinalTestStep3 Where Id = (@SelectedMinPositiveIdStep3-1)  )
--select @ElseCumalativeNetLPContribution as ElseCumalativeNetLPContribution

declare @SelectedElseCumalativeNetGPContribution decimal(30,10) = (select CumalativeNetGPContribution from @SelectedFinalTestStep3 Where Id = (@SelectedMinPositiveIdStep3-1)  )

Update @SelectedFinalLPCostReturn
set NetLPContribution = TotalLPContibution,
CumaltiveNetLPContibution = @SelectedElseCumalativeNetLPContribution + TotalLPContibution,
NetGPContribution = TotalGPContribution ,
CumaltiveNetGPContibution = @SelectedElseCumalativeNetGPContribution + TotalGPContribution
where ID = @SelectedMinPositiveIdStep3

Update B
Set B.CumalativeNetLPContribution = A.CumaltiveNetLPContibution,
B.CumalativeNetGPContribution = A.CumaltiveNetGPContibution

from @SelectedFinalLPCostReturn A
join @SelectedFinalTestStep3 B
on A.ID = B.Id
where A.ID = @SelectedMinPositiveIdStep3


end

--select * from @FinalTestStep3

set @SelectedMinPositiveIdStep3 = @SelectedMinPositiveIdStep3 + 1
--select @MinPositiveIdStep3 as MinPositiveIdStep3


--select  @MinPositiveIdStep3 as NextMinPositiveIdStep3
end


end
else

begin

insert into @SelectedFinalLPCostReturn
 
(                         
 FundId                      
,ScenarioId                  
,InvestmentId                
,InvesmentCashFlowTypeId     
,CashFlowTypeId              
,IsActual                    
,[Status]                    
,TypeId                      
,CashflowType                
,EventDate                   
,InvesmentCashFlow           
,LimitedPartnerPercent       
,LPInvesmentContribution     
,LPCostContribution                        
,TotalLPContibution          
,TotalLPReturn               
,NetLPContribution           
)

select 
 FundId                      
 ,ScenarioId                  
 ,InvestmentId                
 ,InvesmentCashFlowTypeId     
 ,CashFlowTypeId              
 ,IsActual                    
 ,[Status]                    
 ,TypeId                      
 ,CashflowType                
 ,EventDate                                
 ,InvesmentCashFlow           
 ,LimitedPartnerPercent       
 ,LPInvesmentContribution     
 ,LPCostContribution
 ,isnull(LPInvesmentContribution,0.00) + isnull(LPCostContribution,0.00) as TotalLPContribution
 , 0 as TotalLPReturn
 , ( ( isnull(LPInvesmentContribution,0.00) + isnull(LPCostContribution,0.00) ) + 0 ) as NetLPContribution
 from @SelectedLPCostContribution

----------------------------------------------------------------------------------------------------------------------------------


-- insert into @SelectedFinalLPCostReturn
 
--(                         
-- FundId                      
--,ScenarioId                  
----,InvestmentId                
----,InvesmentCashFlowTypeId     
----,CashFlowTypeId              
----,IsActual                    
----,[Status]                    
----,TypeId                      
----,CashflowType                
----,EventDate                   
----,InvesmentCashFlow           
----,LimitedPartnerPercent       
----,LPInvesmentContribution     
----,LPCostContribution                        
--,TotalLPContibution          
--,TotalLPReturn               
--,NetLPContribution           
--)

--select 
-- @FundId                      
-- ,@NonBaseLineScenarioId                               
-- ,0.00
-- ,0.00
-- ,0.00

end


--end
--else
--begin

--insert into @SelectedFinalLPCostReturn
 
--(                         
-- FundId                      
--,ScenarioId                   
--,NetLPContribution           
--)

--select 
-- @FundId                      
-- ,@NonBaselineScenarioId                  
-- , 0 as NetLPContribution


--end

end
else
begin

 insert into @SelectedFinalLPCostReturn
 
(                         
 FundId                      
,ScenarioId                  
--,InvestmentId                
--,InvesmentCashFlowTypeId     
--,CashFlowTypeId              
--,IsActual                    
--,[Status]                    
--,TypeId                      
--,CashflowType                
--,EventDate                   
--,InvesmentCashFlow           
--,LimitedPartnerPercent       
--,LPInvesmentContribution     
--,LPCostContribution                        
,TotalLPContibution          
,TotalLPReturn               
,NetLPContribution           
)

select 
 @FundId                      
 ,@NonBaseLineScenarioId                               
 ,0.00
 ,0.00
 ,0.00

end

--select * from @SelectedFinalLPCostReturn
-- order by EventDate ,TypeId





-------------------------------------------NET OLD MOIC concet---------------25-04-22----------------------------------

--NET MOIC Current

--DECLARE @NetMOICCurrentContribution DECIMAL(30,2) = (SELECT SUM (ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
--										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
--										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
--										WHERE A.FundId=@FundId AND A.ScenarioId=@baseLineScenarioId --AND C.IsBaseline=1
--										AND B.FundCashFlowTypeId=1 and A.Isdeleted=0)


--DECLARE @NetMOICCurrentDistrubution DECIMAL(30,2) = (SELECT SUM(ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
--										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
--										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
--										WHERE A.FundId=@FundId AND A.ScenarioId=@baseLineScenarioId -- AND C.IsBaseline=1
--										and B.FundCashFlowTypeId=2 and A.Isdeleted=0)

--IF (ISNULL(@NetMOICCurrentContribution,0) = 0 OR ISNULL(@NetMOICCurrentDistrubution,0)=0) 
--begin

--set @NetMOIC_Current=0

--end

--ELSE 

--BEGIN

--set @NetMOIC_Current= (@NetMOICCurrentDistrubution/@NetMOICCurrentContribution) 

--END

--------------Net Moic current -------------------------

DECLARE @NetMOICCurrentContribution DECIMAL(30,2) = (SELECT abs (SUM (NetLPContribution)) FROM @CurrentFinalLPCostReturn  
										              WHERE InvesmentCashFlowTypeId in (1,2,4,6) or CashFlowTypeId in (6,7) or TypeId in (-3,-2, -1)  )

DECLARE @NetMOICCurrentDistrubution DECIMAL(30,2) = (SELECT abs (SUM (NetLPContribution)) FROM @CurrentFinalLPCostReturn  
										              WHERE InvesmentCashFlowTypeId in (3,5,7,8) or CashFlowTypeId in (8,9)   )


IF (ISNULL(@NetMOICCurrentContribution,0) = 0 OR ISNULL(@NetMOICCurrentDistrubution,0)=0) 
begin

set @NetMOIC_Current=0

end

ELSE 

BEGIN

set @NetMOIC_Current= (@NetMOICCurrentDistrubution/@NetMOICCurrentContribution) 

END


-------------------------------------------------------------------------------------------------------------------------------------

--NET MOIC Selected
--DECLARE @NetMOICSelectedContribution DECIMAL(30,2) = (SELECT SUM (ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
--										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
--										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
--										WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId --AND C.IsBaseline=0 
--										AND B.FundCashFlowTypeId=1 and A.Isdeleted=0)


--DECLARE @NetMOICSelectedDistrubution DECIMAL(30,2) = (SELECT SUM(ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
--										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
--										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
--										WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId  --AND C.IsBaseline=0 
--										and B.FundCashFlowTypeId=2 and A.Isdeleted=0)

--IF (ISNULL(@NetMOICSelectedContribution,0) = 0 OR ISNULL(@NetMOICSelectedDistrubution,0)=0) 
--begin

--set @NetMOIC_Selected=0

--end

--ELSE 

--BEGIN

--set @NetMOIC_Selected= (@NetMOICSelectedDistrubution/@NetMOICSelectedContribution) 

--END

-------------NET MOIC Selected

DECLARE @NetMOICSelectedContribution DECIMAL(30,2) = (SELECT abs (SUM (NetLPContribution)) FROM @SelectedFinalLPCostReturn  
										              WHERE InvesmentCashFlowTypeId in (1,2,4,6) or CashFlowTypeId in (6,7) or TypeId in (-3,-2,-1)  )

DECLARE @NetMOICSelectedDistrubution DECIMAL(30,2) = (SELECT abs(SUM (NetLPContribution)) FROM @SelectedFinalLPCostReturn  
										              WHERE InvesmentCashFlowTypeId in (3,5,7,8) or CashFlowTypeId in (8,9)    )


IF (ISNULL(@NetMOICSelectedContribution,0) = 0 OR ISNULL(@NetMOICSelectedDistrubution,0)=0) 
begin

set @NetMOIC_Selected=0

end

ELSE 

BEGIN

set @NetMOIC_Selected= (@NetMOICSelectedDistrubution/@NetMOICSelectedContribution) 

END







------------------------------------------------------------------------------------------------



----------------------------------GIRR---------------------------------


declare @CurrentDateCheck date = (select max(EventDate) from @CurrentFinalLPCostReturn  )
declare @SelectedDateCheck date = (select max(EventDate) from @SelectedFinalLPCostReturn  )

DECLARE @investmentCashflow as table (
 FundID int
,ScenarioID Int
,InvestmentCashFlowtypeID int
,InvestmentID INT
,Equity Decimal (30,2)
,Eventdate DateTime
,IsBaseline Int
,Isinvestment int
)


DECLARE @resultcount INT

INSERT INTO @investmentCashflow
--Values (@FundID,@baseLineScenarioId,1,1,10000,'2018-12-01 07:10:20.833',1),
--	   (@FundID,@baseLineScenarioId,1,2,6000,'2019-12-01 07:10:20.833',1),
--	   (@FundID,@baseLineScenarioId,1,3,25000,'2023-12-01 07:10:20.833',1),
--	   (@FundID,@NonBaseLineScenarioId,2,1,10000,'2018-10-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,2,2,5000,'2019-10-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,2,3,27000,'2023-10-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,3,1,8000,'2018-11-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,3,2,4000,'2019-11-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,3,3,22000,'2023-11-01 07:10:20.833',0)


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--UNION ALL
--SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 2 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
--		,Max(CAST(isbaseline AS INT)) isbaseline, 0 as IsInvestment
--FROM [OPGC].[OpgcFundCashFlow] o
--INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1 
--WHERE O.FundCashflowTypeId in (1) and o.ScenarioId = @baseLineScenarioId and o.Isdeleted=0
--GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)
--UNION ALL
--SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 2 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
--		,Max(CAST(isbaseline AS INT)) isbaseline, 0 as IsInvestment
--FROM [OPGC].[OpgcFundCashFlow] o
--INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1
--WHERE O.FundCashflowTypeId in (2) and o.ScenarioId = @baseLineScenarioId and o.Isdeleted=0
--GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--UNION ALL
--SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 3 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
--		,Max(CAST(isbaseline AS INT)) isbaseline, 0 as IsInvestment
--FROM [OPGC].[OpgcFundCashFlow] o
--INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 0
--WHERE O.FundCashflowTypeId in (1) and o.ScenarioId = @NonBaseLineScenarioId and o.Isdeleted=0
--GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)
--UNION ALL
--SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 3 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
--		,Max(CAST(isbaseline AS INT)) isbaseline, 0 as IsInvestment
--FROM [OPGC].[OpgcFundCashFlow] o
--INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 0
--WHERE O.FundCashflowTypeId in (2) and o.ScenarioId = @NonBaseLineScenarioId and o.Isdeleted=0
--GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)
------------------------------------------------------------------------------------------------------------------------------------------------------------------

SELECT FundId,ScenarioId,CashflowTypeId as InvestmentCashflowTypeId, 2 as investmentID , NetLPContribution as  Equity, EventDate
		,0 isbaseline, 0 as IsInvestment
FROM @CurrentFinalLPCostReturn

UNION ALL
SELECT FundId,ScenarioId,CashflowTypeId as InvestmentCashflowTypeId, 3 as investmentID , NetLPContribution as  Equity, EventDate
		,0 isbaseline, 0 as IsInvestment
FROM @SelectedFinalLPCostReturn


--SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate,  Equity FROM @investmentCashflow
--WHERE InvestmentID = 2 and Isinvestment = 0

DECLARE @Test [OPGC].[GIRRTable] -- [OPGC].[GIRRTableTEST]
DECLARE @snapshotdatecurrentGIRR Datetime = GEtdate ();

-----------------------------------------------------------------------------------------------------------------------------------------------------------------

If @CurrentDateCheck is not null

begin

;with CurrentscenariodataNet as (
--SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate,  Equity FROM @investmentCashflow
--WHERE InvestmentCashFlowtypeID in (1) and Isinvestment = 0
--GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
--UNION ALL
--SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @investmentCashflow
--WHERE  InvestmentCashFlowtypeID in (2) and Isinvestment = 0
--GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )

SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate,  Equity FROM @investmentCashflow
WHERE InvestmentID = 2 and Isinvestment = 0

--GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
)



INSERT  @Test
SELECT  Equity , EventDate FROM CurrentscenariodataNet
WHERE FundID = @fundid and ScenarioId = @baseLineScenarioId

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @fundid ,@baseLineScenarioId, 2, 
        -- case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
         cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
		 @snapshotdatecurrentGIRR  


 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;

SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @baseLineScenarioId  and SnapshotDate = @snapshotdatecurrentGIRR and InvestmentID = 2)

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@baseLineScenarioId, 2,0.0 AS GIRR, @snapshotdatecurrentGIRR
END

DELETE FROM @Test

end
else
begin

INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@baseLineScenarioId, 2,0.0 AS GIRR, @snapshotdatecurrentGIRR

end
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

If @SelectedDateCheck is not null
begin

;with SelectedscenariodataNet as (
--SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, -SUM(Equity) Equity FROM @investmentCashflow
--WHERE  InvestmentCashFlowtypeID in (1) and Isinvestment = 0
--GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
--UNION ALL
--SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @investmentCashflow
--WHERE  InvestmentCashFlowtypeID in (2) and Isinvestment = 0
--GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )

SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate,  Equity FROM @investmentCashflow
WHERE InvestmentID = 3 and Isinvestment = 0
--GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
)
INSERT  @Test
SELECT  Equity , EventDate FROM SelectedscenariodataNet
WHERE FundID = @fundid and ScenarioId = @NonBaseLineScenarioId

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @fundid ,@NonBaseLineScenarioId, 3, 
       -- case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
        cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
		@snapshotdatecurrentGIRR  


 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;

SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @NonBaseLineScenarioId  and SnapshotDate = @snapshotdatecurrentGIRR and InvestmentID = 3)

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@NonBaseLineScenarioId, 3,0.0 AS GIRR, @snapshotdatecurrentGIRR
END

end
else
begin

INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@baseLineScenarioId, 3,0.0 AS GIRR, @snapshotdatecurrentGIRR

end


SELECT 
@NetIRR_Current = (SELECT GIRR FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR AND InvestmentID = 2),
@NetIRR_selected = (SELECT GIRR FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR AND InvestmentID = 3)
-------------------------------------------------------------------------



SELECT 
 ISNULL(@NetMOIC_Current,0) AS  NetMOIC_Current
,ISNULL(@NetMOIC_Selected,0) AS NetMOIC_Selected
,ISNULL(@NetIRR_Current,0) AS   NetIRR_Current
,ISNULL(@NetIRR_selected,0) AS  NetIRR_Selected

--; with CurrentFinal as
--(

--select A.FundId
--      ,A.ScenarioId as CurrentScenarioId
--	  ,A.EventDate as CurrentEventDate
--	  , case when A.TypeId = -3 then 'Managment Fees Contribution'
--	         when A.TypeId = -2 then 'Other PartnerShip Expenses Contribution'
--			 when A.TypeId = -1 then 'Offset By Quarter'
--			 when A.CashFlowTypeId = 6 then 'Management Fees Contribution'
--			 when A.CashFlowTypeId = 7 then 'Other Partnership Expenses Contribution'
--			 when A.CashFlowTypeId = 8 then 'Management Fees Distribution'
--			 when A.CashFlowTypeId = 9 then  'Other Partnership Expenses Distribution' end as CurrentCashFlowType
--     ,A.LPCostContribution as CurrentValueAmount
--	 , Case when A.TypeId in (-3,-2,-1) then 'Forecast' else A.Status end as CurrentStatus
--	 , A.LimitedPartnerPercent as CurrentLimitedPartnerPercent
--	 , ISNULL(@NetMOIC_Current,0) AS  NetMOIC_Current
--	 ,ISNULL(@NetIRR_Current,0) AS   NetIRR_Current
--	 -- ,B.ScenarioId as CurrentScenarioId
--	 -- ,B.EventDate as CurrentEventDate
--	 -- , case when B.TypeId = -3 then 'Managment Fees Contribution'
--	 --        when B.TypeId = -2 then 'Other PartnerShip Expenses Contribution'
--		--	 when B.TypeId = -1 then 'Offset By Quarter'
--		--	 when B.CashFlowTypeId = 6 then 'Management Fees Contribution'
--		--	 when B.CashFlowTypeId = 7 then 'Other Partnership Expenses Contribution'
--		--	 when B.CashFlowTypeId = 8 then 'Management Fees Distribution'
--		--	 when B.CashFlowTypeId = 9 then  'Other Partnership Expenses Distribution' end as SelectCashFlowType
--  --   ,A.LPCostContribution as CurrentValueAmount
--	 --, Case when A.TypeId in (-3,-2,-1) then 'Forecast' else A.Status end as SelectStatus
--	 --, A.LimitedPartnerPercent as CurrentLimitedPartnerPercent

--     ,ISNULL(@NetMOIC_Selected,0) AS NetMOIC_Selected

--     ,ISNULL(@NetIRR_selected,0) AS  NetIRR_Selected

--from @CurrentFinalLPCostReturn A
--order by A.EventDate ,A.TypeId asc
--offset 0 rows

--)

----union all
--, SelectedFinal as
--(
--select FundId
--      ,ScenarioId as CurrentScenarioId
--	  ,EventDate as CurrentEventDate
--	  , case when TypeId = -3 then 'Managment Fees Contribution'
--	         when TypeId = -2 then 'Other PartnerShip Expenses Contribution'
--			 when TypeId = -1 then 'Offset By Quarter'
--			 when CashFlowTypeId = 6 then 'Management Fees Contribution'
--			 when CashFlowTypeId = 7 then 'Other Partnership Expenses Contribution'
--			 when CashFlowTypeId = 8 then 'Management Fees Distribution'
--			 when CashFlowTypeId = 9 then  'Other Partnership Expenses Distribution' end as CurrentCashFlowType
--     ,LPCostContribution as CurrentValueAmount
--	 , Case when TypeId in (-3,-2,-1) then 'Forecast' else Status end as CurrentStatus
--	 , LimitedPartnerPercent as CurrentLimitedPartnerPercent
--	 , ISNULL(@NetMOIC_Current,0) AS  NetMOIC_Current
--	 ,ISNULL(@NetIRR_Current,0) AS   NetIRR_Current
--	 -- ,B.ScenarioId as CurrentScenarioId
--	 -- ,B.EventDate as CurrentEventDate
--	 -- , case when B.TypeId = -3 then 'Managment Fees Contribution'
--	 --        when B.TypeId = -2 then 'Other PartnerShip Expenses Contribution'
--		--	 when B.TypeId = -1 then 'Offset By Quarter'
--		--	 when B.CashFlowTypeId = 6 then 'Management Fees Contribution'
--		--	 when B.CashFlowTypeId = 7 then 'Other Partnership Expenses Contribution'
--		--	 when B.CashFlowTypeId = 8 then 'Management Fees Distribution'
--		--	 when B.CashFlowTypeId = 9 then  'Other Partnership Expenses Distribution' end as SelectCashFlowType
--  --   ,A.LPCostContribution as CurrentValueAmount
--	 --, Case when A.TypeId in (-3,-2,-1) then 'Forecast' else A.Status end as SelectStatus
--	 --, A.LimitedPartnerPercent as CurrentLimitedPartnerPercent

--     ,ISNULL(@NetMOIC_Selected,0) AS NetMOIC_Selected

--     ,ISNULL(@NetIRR_selected,0) AS  NetIRR_Selected
--from @SelectedCumalativeLPCostReturn 
--order by EventDate ,TypeId asc
--offset 0 rows

--)

--select * from CurrentFinal
--union all
--select * from SelectedFinal


--select * from @CurrentFinalLPCostReturn

DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR






END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


