CREATE TYPE [dbo].[NameStyle] FROM [bit] NOT NULL
