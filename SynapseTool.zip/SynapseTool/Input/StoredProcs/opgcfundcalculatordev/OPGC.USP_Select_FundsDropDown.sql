SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_FundsDropDown] --''
(
	@userAlias NVARCHAR(250)

)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 




SELECT 
      [FundId]​    FundId            
     ,[FundName​]    FundName​     
	-- , CreatedOn
from [OPGC].[OpgcFund]	 
order by 1 desc

END


