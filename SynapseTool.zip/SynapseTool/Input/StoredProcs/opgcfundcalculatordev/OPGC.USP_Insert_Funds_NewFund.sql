SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [OPGC].[USP_Insert_Funds_NewFund] -- 'Fund TestSriram','100','100.1','100.23',Null,'5','2021-1-30','3.2','56',' '
(
    @FundName​                       NVARCHAR(100),
    @CommittedCapital               DECIMAL(30,2),
    @OffsetsByQuarter               DECIMAL(30,2),
    @OtherPartnershipFeesByQuarter  DECIMAL(30,2),
    @Description​                    NVARCHAR(500),
    @FundInceptionDate              DATETIME,
    @ManualStepdownDate​             DATETIME,
	@LPPreferredReturnPercent       DECIMAL(5,2),
	@LPFinalSharePercent            DECIMAL(5,2),
	@GPPreferredReturnPercent       DECIMAL(5,2),
    @ManagementFeePercent​           DECIMAL(30,2),
    @UserAlias				        NVARCHAR(250)

    -- @TotalInvestment​       DECIMAL(30,2)  ,
    --@TotalRealized​          DECIMAL(30,2),    
    --@TotalUnrealized​        DECIMAL(30,2),
	-- @ExpenseCap​             DECIMAL(30,2),
	--@LimitedPartnerPercent​  DECIMAL(30,2),
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Fund Details

Uses   
      [OPGC].[USP_Select_Funds_GetFundsListing]	    SP

Populates
      [OPGC].[Fund]			Table

**************************************************************************/


BEGIN TRY


Declare @FundNameCount int = (select count (1) from [OPGC].[OpgcFund] where  [FundName​] = @Fundname )
Declare @ErrorText Nvarchar(MAx) =''



If @FundNameCount > 0 
Begin

SET @ErrorText = 'Fund Name Already Exists'
RAISERROR (@ErrorText, 16, 1)

End

Else

Begin


INSERT INTO [OPGC].[OpgcFund] 
    (            
       [FundName​] 
	  ,[CommittedCapital]
      ,[OffsetsByQuarter]
      ,[OtherPartnershipFeesByQuarter]
      --,[TotalInvestment​]       
      --,[TotalRealized​]          
      --,[TotalUnrealized​]       
      ,[Description​]           
      --,[ExpenseCap​]
	  ,[FundInceptionDate]
      ,[ManualStepdownDate​]    
      --,[LimitedPartnerPercent​]
	  ,[LPPreferredReturnPercent]
      ,[LPFinalSharePercent]
	  ,[GPPreferredReturnPercent]
      ,[ManagementFeePercent​]  
      ,[CreatedBy​]             
      ,[CreatedOn​]             
	 )

SELECT                
        @FundName​  
	   ,@CommittedCapital             
	   ,@OffsetsByQuarter             
	   ,@OtherPartnershipFeesByQuarter
       --,@TotalInvestment​       
       --,@TotalRealized​          
       --,@TotalUnrealized​       
       ,@Description​           
       --,@ExpenseCap​
	   ,@FundInceptionDate
       ,@ManualStepdownDate​
       --,@LimitedPartnerPercent​
	   ,@LPPreferredReturnPercent
	   ,@LPFinalSharePercent     
	   ,@GPPreferredReturnPercent
       ,@ManagementFeePercent​
	   ,@UserAlias
	   ,getdate()

End


END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
    IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END 
END CATCH
END


