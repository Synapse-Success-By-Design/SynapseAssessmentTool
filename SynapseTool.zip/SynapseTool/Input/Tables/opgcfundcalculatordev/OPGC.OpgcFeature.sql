SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcFeature](
	[OpgcFeatureId] [int] IDENTITY(1,1) NOT NULL,
	[OpgcFeatureName] [nvarchar](50) NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[OpgcFeatureId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcFeature] ADD  CONSTRAINT [df_OpgcFeature_IsDeleted]  DEFAULT ((0)) FOR [IsDeleted]
ALTER TABLE [OPGC].[OpgcFeature] ADD  CONSTRAINT [df_OpgcFeature_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
