CREATE TYPE [OPGC].[IRRTable] AS TABLE(
	[Value] [decimal](19, 9) NOT NULL,
	[Date] [datetime] NOT NULL
)
