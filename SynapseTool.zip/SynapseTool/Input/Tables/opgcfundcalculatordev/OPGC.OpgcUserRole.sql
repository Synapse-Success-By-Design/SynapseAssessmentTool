SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcUserRole](
	[OpgcUserRoleId] [int] IDENTITY(1,1) NOT NULL,
	[OpgcUserRoleName] [nvarchar](250) NOT NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[OpgcUserRoleId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcUserRole] ADD  CONSTRAINT [df_OpgcUserRole_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
