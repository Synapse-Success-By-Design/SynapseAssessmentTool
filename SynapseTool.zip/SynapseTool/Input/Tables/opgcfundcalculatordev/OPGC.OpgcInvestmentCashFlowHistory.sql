SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcInvestmentCashFlowHistory](
	[InvestmenCashflowId] [int] NOT NULL,
	[FundId] [int] NOT NULL,
	[ScenarioId] [int] NOT NULL,
	[InvestmentCashflowTypeId] [int] NOT NULL,
	[InvestmentId] [int] NOT NULL,
	[Equity] [decimal](30, 2) NULL,
	[EventDate] [date] NOT NULL,
	[IsActual] [bit] NULL,
	[IsHypothetical] [bit] NULL,
	[RecallableUntil] [datetime] NULL,
	[Tag] [nvarchar](250) NULL,
	[Isdeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
	[ValidFrom] [datetime2](0) NOT NULL,
	[ValidTo] [datetime2](0) NOT NULL,
	[IsRecallable] [bit] NULL,
	[LimitedPartnerPercent] [decimal](5, 2) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)

