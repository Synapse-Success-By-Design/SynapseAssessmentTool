SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OPGCResultGIRR_History](
	[GIRRHistoryId] [int] IDENTITY(1,1) NOT NULL,
	[FundId] [int] NULL,
	[ScenarioId] [int] NULL,
	[InvestmentID] [int] NULL,
	[GIRR] [decimal](18, 2) NULL,
	[SnapshotDate] [datetime] NULL,
	[Modifiedon] [datetime] NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[InvestmentName] [nvarchar](500) NULL,
PRIMARY KEY CLUSTERED 
(
	[GIRRHistoryId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

