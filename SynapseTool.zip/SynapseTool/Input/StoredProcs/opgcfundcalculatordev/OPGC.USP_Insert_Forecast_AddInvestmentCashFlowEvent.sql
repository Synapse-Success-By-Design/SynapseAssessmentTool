SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
  
CREATE PROCEDURE [OPGC].[USP_Insert_Forecast_AddInvestmentCashFlowEvent] --'',1,1,1,1,'2021-07-19','100','Actual',0,NULL,'Testing in DB'  
(  
   @userAlias NVARCHAR(50),  
   @FundId INT,  
   @ScenarioId INT,  
   @InvestmentId INT,  
   @InvestmentCashFlowTypeId INT,  
   @EventDate DATETIME,  
   @ValueAmount DECIMAL(30,2),  
   @Status NVARCHAR(10),  
   @RecallBool BIT,  
   @RecallableUntil DATETIME,  
   @Tag NVARCHAR(250) ,
   @LimitedPartnerPercent decimal(5,2)
)  
  
As  
BEGIN  
--=======================================================   
 --Author         :    <AEGIS Team>      
 --Create Date    :    18/03/2021   
 --Description    :   Select the Get Appointment Details  
--===========================================================   
 --History                    
 --Author         :         Date         Description   
  
--============================================================   
  
/*************************************************************************  
Purpose  
      Display the Appointment Details  
  
Uses     
      [USP_Select_Appointment_GetAppointmentDetails]     SP  
  
Populates  
   [WWMG].[ConfirmedScheduleDetails]   Table  
   [WWMG].[LocationDetails]     Table  
   [WWMG].[UserFamilyDetails]    Table  
   [WWMG].[FamilyDetails_Relations]   Table  
**************************************************************************/  

BEGIN TRY 


declare @ErrorText nvarchar(max)  
declare @CheckInvestmentCashflowTypeId  int = (select count(1) from [OPGC].[opgcInvestmentCashFlow] where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentCashflowTypeId =1 and InvestmentId = @InvestmentId and Isdeleted=0)  

declare @CheckInvestmentCashflowTypeId100 int = ( select  count(1) from [OPGC].[opgcInvestmentCashFlow] where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentCashflowTypeId =100 and InvestmentId = @InvestmentId and Isdeleted=0 )
 declare @FundMindate date = ( select FundInceptionDate from [OPGC].[OpgcScenario]  where FundId =@fundId and ScenarioId = @scenarioId )
--select @FundMindate as FundMindate
declare @Mindate date = (select min(Eventdate) from [OPGC].[OpgcInvestmentCashFlow] where FundId =@fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID and InvestmentCashFlowTypeId in ( 1))
--select @Mindate as InvestMindate
declare @ExitCheck int = (select COUNT(1) from [OPGC].[OpgcInvestmentCashFlow] where FundId =@fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID and InvestmentCashflowTypeId = 3 and Isdeleted = 0)
declare @Exitdate date = (select Max(Eventdate) from [OPGC].[OpgcInvestmentCashFlow] where FundId =@fundId and ScenarioId = @scenarioId and InvestmentId = @investmentID and InvestmentCashFlowTypeId in ( 3) and Isdeleted = 0)


if @CheckInvestmentCashflowTypeId > 0 and @InvestmentCashFlowTypeId = 1   
BEGIN  
SET @ErrorText = 'Initial Investment Already Exists'  
RAISERROR (@ErrorText, 16, 1)  
END  
  
  
if @CheckInvestmentCashflowTypeId = 0 and @InvestmentCashFlowTypeId in (2,3,4,5,6,7,8)  
BEGIN  
SET @ErrorText = 'Please Add Intital Invesment'  
RAISERROR (@ErrorText, 16, 1)  
END  
  

  if @FundMindate > @EventDate
begin
SET @ErrorText = 'Date is less than Fund Inception Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)
end 

 if @Mindate >= @EventDate and @investmentCashFlowTypeId in (2,3,4,5,6,7,8)
begin
SET @ErrorText = 'Date is less than Initial Invesment Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)
end 


 if @ExitCheck = 1 and @investmentCashFlowTypeId = 3
begin
SET @ErrorText = 'Exit Invesment already exist'
RAISERROR (@ErrorText, 16, 1)
end 


 if @Exitdate < @EventDate and @investmentCashFlowTypeId in (1)
begin
SET @ErrorText = 'Date is greater than Exit Invesment Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)
end 
  
--if @CheckInvestmentCashflowTypeId = 0 and @InvestmentCashFlowTypeId = 3  
--BEGIN  
--SET @ErrorText = 'Please Add Intital Invesment'  
--RAISERROR (@ErrorText, 16, 1)  
--END  
    
  
--if @IntitalInvestmentDate = @EventDate and @InvestmentCashFlowTypeId = 3  
--BEGIN  
--SET @ErrorText = 'Intial Investment date and exit date cannot be same'  
--RAISERROR (@ErrorText, 16, 1)  
--END  
  
if @CheckInvestmentCashflowTypeId100 >= 1 and @InvestmentCashFlowTypeId = 1
begin

update [OPGC].[opgcInvestmentCashFlow]
set InvestmentCashflowTypeId  = @InvestmentCashFlowTypeId
   ,Equity  				  = @ValueAmount
   ,EventDate  				  = @EventDate
   ,IsActual  				  = CASE WHEN @Status ='Actual' THEN 1 ELSE 0 END
   ,IsHypothetical  		  = CASE WHEN @Status ='Hypothetical' THEN 1 ELSE 0 END 
   ,LimitedPartnerPercent     = @LimitedPartnerPercent
   ,IsRecallable  			  = @RecallBool
   ,RecallableUntil  		  = @RecallableUntil
   ,Tag  					  = @Tag
   ,Isdeleted  				  = 0 
   ,CreatedBy  				  = @userAlias
   --,CreatedOn 				  = GETDATE()   
where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentId   and Isdeleted = 0 and InvestmentCashflowTypeId = 100

end

  
Else  
Begin  
  
INSERT INTO [OPGC].[opgcInvestmentCashFlow]  
(  
 FundId  
,ScenarioId  
,InvestmentCashflowTypeId  
,InvestmentId  
,Equity  
,EventDate  
,IsActual  
,IsHypothetical  
,LimitedPartnerPercent     
,IsRecallable  
,RecallableUntil  
,Tag  
,Isdeleted  
,CreatedBy  
,CreatedOn  
)  
  
select   
 @FundId  
,@ScenarioId  
,@InvestmentCashFlowTypeId  
,@InvestmentId  
,@ValueAmount  
,@EventDate  
,CASE WHEN @Status ='Actual' THEN 1 ELSE 0 END  
,CASE WHEN @Status ='Hypothetical' THEN 1 ELSE 0 END 
,@LimitedPartnerPercent
,@RecallBool  
,@RecallableUntil  
,@Tag  
,0  
,@userAlias  
,GETDATE()  
  
   
End  

-------------------------------------------------------------update fot OPGC.OPGCFund Table with Baselinescenario investmnents------------------------------------------------------------
--DECLARE @BaselineScenarioid INT 
--SET @BaselineScenarioid = (SELECT ScenarioId from OPGC.OpgcScenario WHERE FundID = @fundid AND IsBaseline = 1 and Isdeleted = 0)
--DECLARE @Investment Decimal (30,2) = (SELECT SUM(Equity) FROM OPGC.OpgcInvestmentCashFlow WHERE Fundid = @fundid and ScenarioId = @BaselineScenarioid and InvestmentCashflowTypeId in (1,2) and Isdeleted = 0)
--DECLARE @totalInvestment Decimal (30,2), @realizedinvestment Decimal (30,2), @Unrealizedinvestment Decimal (30,2)
--;with Investment as  
--(  
--select FundId , ScenarioId , InvestmentId  , sum(Equity) as InitialInvestment , 0 as ExitValue   
--  from [OPGC].[OpgcInvestmentCashFlow]   
--  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
--  group by FundId , ScenarioId , InvestmentId   
--  union all   
--  select FundId , ScenarioId , InvestmentId  , 0 as IntialInvestment , sum(Equity) as ExitValue     
--  from [OPGC].[OpgcInvestmentCashFlow]   
--  where InvestmentCashflowTypeId in (3,5,7) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
--  group by FundId , ScenarioId , InvestmentId   
--  )  
--, TotalIvestment as  
--(  
--  select FundId , ScenarioId , InvestmentId  , sum( InitialInvestment) as Investment , sum (ExitValue)  as ExitVAlue   
--  from Investment A  
--   group by FundId , ScenarioId , InvestmentId   
--),
--Realizedvalidation as(
--SELECT FundId , ScenarioId , InvestmentId  ,  Investment ,  ExitVAlue ,
--CASE WHEN ExitVAlue > Investment THEN 1 ELSE 0 END AS IsRealized
--FROM TotalIvestment
--),
--------------------Investmet by Eventdate-----------------------------
--Investmentbyeventdate AS (
--select FundId , ScenarioId , InvestmentId  , CAST(EventDate AS DATE) EventDate,sum(Equity) as InitialInvestment , 0 as ExitValue   
--  from [OPGC].[OpgcInvestmentCashFlow]   
--  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
--  group by FundId , ScenarioId , InvestmentId ,CAST(EventDate AS DATE)  
--  union all   
--  select FundId , ScenarioId , InvestmentId  , CAST(EventDate AS DATE) EventDate,0 as IntialInvestment , sum(Equity) as ExitValue     
--  from [OPGC].[OpgcInvestmentCashFlow]   
--  where InvestmentCashflowTypeId in (3,5,7) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
--  group by FundId , ScenarioId , InvestmentId,CAST(EventDate AS DATE)
--  ),
--  TotalInvestmentbyeventdate AS (
--  select FundId , ScenarioId , InvestmentId  ,  EventDate,sum(InitialInvestment) as Investment ,  SUM(ExitValue) ExitValue
--  FROM Investmentbyeventdate
--  GROUP BY FundId , ScenarioId , InvestmentId  ,  EventDate
--  ),
--  Categorization as (
--  SELECT T.FundId , T.ScenarioId , T.InvestmentId  ,  T.EventDate,
--  CASE WHEN R.IsRealized = 1 THEN T.Investment *-1 ELSE 0 End AS Realizedinvestment,
--  CASE WHEN R.IsRealized = 0 THEN T.Investment *-1 ELSE 0 End AS UnRealizedinvestment,
--  CASE WHEN R.IsRealized = 1 THEN T.ExitValue  ELSE 0 End AS RealizedExitValue,
--  CASE WHEN R.IsRealized = 0 THEN T.ExitValue  ELSE 0 End AS UnRealizedExitValue
--  FROM TotalInvestmentbyeventdate T
--  INNER JOIN Realizedvalidation R On T.FundId = R.FundId and  T.ScenarioId  = R.ScenarioId and  T.InvestmentId =  R.InvestmentId
--  ),FinalResul As(
--  SELECT FundId,SUM(Realizedinvestment)*-1 Realizedinvestment, SUM(UnRealizedinvestment)*-1 UnRealizedinvestment , Sum(Realizedinvestment+UnRealizedinvestment)*-1 as TotalInvestment
--		FROM Categorization
--		GROUP BY FundId
--		)
--		SELECT @totalInvestment = TotalInvestment,
--			   @realizedinvestment = Realizedinvestment,
--			   @Unrealizedinvestment = UnRealizedinvestment
--			   FROM FinalResul

--If (Select count(InvestmentCashflowTypeId) FROM OPGC.OpgcInvestmentCashFlow WHERE fundId = @fundid and ScenarioId = @BaselineScenarioid and InvestmentCashflowTypeId = 3 AND Isdeleted = 0) >=1
--BEGIN

--UPDATE OPGC.OpgcFund
--SET [TotalInvestment​] = IIF(COALESCE([TotalInvestment​],0.00) = 0.00,@totalInvestment,[TotalInvestment​]),
--	[TotalRealized​] = IIF(COALESCE([TotalRealized​],0.00) = 0.00,@realizedinvestment,[TotalRealized​]),
--	[TotalUnrealized​] = IIF(COALESCE([TotalUnrealized​],0.00) = 0.00,@Unrealizedinvestment,[TotalUnrealized​])
--	WHERE Fundid = @fundid


--END 


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  

END TRY  
BEGIN CATCH  
 DECLARE @ErrorNumber INT  
 DECLARE @Severity  INT  
 DECLARE @State   INT   
 DECLARE @Procedure  NVARCHAR(250)  
 DECLARE @LineNumber  INT  
 DECLARE @Message  NVARCHAR(MAX)  
 DECLARE @Originator NVARCHAR(250)   
 SELECT   
  @ErrorNumber = ERROR_NUMBER(),  
  @Severity = ERROR_SEVERITY(),  
  @State = ERROR_STATE(),   
  @Procedure = ERROR_PROCEDURE(),  
  @LineNumber = ERROR_LINE(),   
  @Message = ERROR_MESSAGE()     
 EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message,   
       'Database', null, null,null   IF @ErrorText <> ''  
BEGIN  
RAISERROR (@ErrorText, 16, 1)  
END  
ELSE  
BEGIN  
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages  
END 
END CATCH  
END  
  
