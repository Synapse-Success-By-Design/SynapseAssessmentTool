SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Insert_Forecast_AddScenario]-- '',1,'My Scenario123 ','test sriram',1
(
	  @userAlias NVARCHAR(50)
	 ,@Fundid INT
	 ,@ScenarioName NVARCHAR(20)
	 ,@ScenarioDescription NVARCHAR(500)
	 ,@BaseLineStatus BIT
	 ,@CommittedCapital               DECIMAL(30,2)
	 ,@OffsetsByQuarter               DECIMAL(30,2)
	 ,@OtherPartnershipFeesByQuarter  DECIMAL(30,2)
	 ,@FundInceptionDate              DATETIME
	 ,@ManualStepdownDate​             DATETIME
	 ,@LPPreferredReturnPercent       DECIMAL(5,2)
	 ,@LPFinalSharePercent            DECIMAL(5,2)
	 ,@GPPreferredReturnPercent       DECIMAL(5,2)
	 ,@ManagementFeePercent​           DECIMAL(30,2)
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 


BEGIN TRY


Declare @ErrorText Nvarchar(MAX) =''
DECLARE @IfScenarioExist INT = (Select count(ScenarioId)from [OPGC].[OpgcScenario] where FundID=@Fundid  and Isdeleted=0)


--DECLARE @IfScenarioNameExist INT = (Select count(ScenarioId)from [OPGC].[OpgcScenario] where FundID=@Fundid  and ScenarioName =@ScenarioName )--Isdeleted=0)

--If @IfScenarioNameExist > 0
--Begin

--SET @ErrorText = 'Scenario Name Already Exists'
--RAISERROR (@ErrorText, 16, 1)

--END




DECLARE @ScenarioNameCount INT = (select count(*) from [OPGC].[OpgcScenario] where ScenarioName =@ScenarioName and Isdeleted=0 )

declare @GlobalFundMindate date = ( select FundInceptionDate from [OPGC].[OpgcFund]  where FundId =@FundId  )


IF(@ScenarioNameCount >0)
BEGIN

SET @ErrorText = 'Scenario Name Already Exists'
RAISERROR (@ErrorText, 16, 1)
END

ELSE
BEGIN

if @GlobalFundMindate > @FundInceptionDate
begin

SET @ErrorText = 'Date is less than Global Fund Inception Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)

end
else

begin
if (@IfScenarioExist = 0)
BEGIN

SET @BaseLineStatus = 1

END

insert into [OPGC].[OpgcScenario]
(
 FundID
,ScenarioName
,ScenarioDescription
,[IsBaseline]
,CommittedCapital
,OffsetsByQuarter
,OtherPartnershipFeesByQuarter
,FundInceptionDate
,ManualStepdownDate
,LPPreferredReturnPercent
,LPFinalSharePercent
,GPPreferredReturnPercent
,ManagementFeePercent
,CreatedBy
,CreatedOn
,ModifiedBy
,ModifiedOn)

select 
 @Fundid
,@ScenarioName
,@ScenarioDescription
,@BaseLineStatus
,@CommittedCapital             
,@OffsetsByQuarter             
,@OtherPartnershipFeesByQuarter
,@FundInceptionDate            
,@ManualStepdownDate​           
,@LPPreferredReturnPercent     
,@LPFinalSharePercent          
,@GPPreferredReturnPercent     
,@ManagementFeePercent​         
,@userAlias
,getdate()
,NULL
,NULL

IF @BaseLineStatus = 1
BEGIN

UPDATE [OPGC].[OpgcScenario]
SET [IsBaseline]= 0 
where scenarioname != @ScenarioName AND FundId = @Fundid and Isdeleted = 0

END

END

end


END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
    IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END  --Error Handling Messages 
END CATCH
END


