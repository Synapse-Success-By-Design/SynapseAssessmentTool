CREATE TYPE [dbo].[UDTOPGCSecurityGroup] AS TABLE(
	[Alias] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UserStatus] [bit] NULL,
	[UserGroup] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
