SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE  FUNCTION [OPGC].[CalcGIRR_Goalseek]
(
    @Sample GIRRTable READONLY
   -- @Rate DECIMAL(19, 9) = 0.1
)
RETURNS DECIMAL(38, 9)
AS
BEGIN

declare @Temp as table (Id int identity(1,1), Equity decimal(21,2) , Equitydate date)
declare @CalcExitValue decimal(30,2)

declare @CalcIRR decimal(30,10) = 1

declare @FinalTemp as table
(Id int , Equity decimal(21,2) , Equitydate date , Mindate date , [YearDiffernce/365] decimal(30,10) )

insert into @Temp 
select * from  @Sample
declare @Mindate date = ( select min(Equitydate) as MinDAte from @Temp)
;with mindate as
(
select Id , Equity , Equitydate , @Mindate as Mindate
from @Temp
group by Id , Equity , Equitydate 
order by Equitydate asc
offset 0 rows
)

,YearDiffernce as
(
select Id , Equity , Equitydate ,  Mindate
,cast ( datediff(day,MinDate ,Equitydate) as decimal(30,10))  as YearDiffernce 
from mindate
)
, [YearDiffernce/365] as 
(
select Id , Equity , Equitydate ,  Mindate, YearDiffernce 
, cast ( YearDiffernce / 365  as decimal(30,10) ) as [YearDiffernce/365] 
from YearDiffernce
)

insert into @FinalTemp ( Id  , Equity  , Equitydate  , Mindate , [YearDiffernce/365]  )
select 
Id , Equity , Equitydate ,  Mindate , [YearDiffernce/365] 
from [YearDiffernce/365]

;with DcValue as 
(
select Id , Equity , Equitydate ,  Mindate,  [YearDiffernce/365] 
,  @CalcIRR as CalcIRR
,cast (POWER(@CalcIRR,[YearDiffernce/365]) as decimal(30,10)) as DcValue
from @FinalTemp
)

, calcExitvalue as
(
select Id , Equity , Equitydate ,  Mindate, [YearDiffernce/365] , CalcIRR, DcValue
,  case when Equity =0 then 0.00 else cast (Equity / DCValue  as decimal(30,10)) end as CalDCValue
from DcValue
)

, Cumulative as
(
select Id , Equity , Equitydate ,  Mindate , [YearDiffernce/365] , CalcIRR, DcValue , CalDCValue
,sum(CalDCValue) OVER (ORDER BY Id) as Cumulative
from calcExitvalue
)



select @CalcExitValue = ( select top 1 Cumulative from Cumulative order by Id desc ) 


Declare @CalcExitValueNew decimal(30,10)

Declare @CalcIrr1 decimal(30,10)

while @CalcExitValue >= 0 
begin

set @CalcIRR1 = @CalcIRR + 0.0005

if @CalcIRR = 50
begin
break
end
                     
;with DcValue as 
(
select Id , Equity , Equitydate ,  Mindate ---, YearDiffernce 
, [YearDiffernce/365] 
,  @CalcIRR1 as CalcIRR
,cast (POWER(@CalcIRR1,[YearDiffernce/365]) as decimal(30,10)) as DcValue
from @FinalTemp
)

--select * from DcValue

, calcExitvalue as
(
select Id , Equity , Equitydate ,  Mindate--, YearDiffernce 
, [YearDiffernce/365] , CalcIRR, DcValue
,  case when Equity =0 then 0.00 else cast (Equity / DCValue  as decimal(30,10)) end as CalDCValue
from DcValue
)

, Cumulative as
(
select  Id , Equity , Equitydate ,  Mindate , [YearDiffernce/365] , CalcIRR, DcValue , CalDCValue
,sum(CalDCValue) OVER (ORDER BY Id) as Cumulative
from calcExitvalue

)

--select * from calcExitvalue

select @CalcExitValueNew  = ( select top 1 Cumulative from Cumulative   order by Id desc  ) 

--if @CalcExitValueNew > @CalcExitValue
--begin
--break
--end

select @CalcIRR = @CalcIRR1 

--select @CalcIRR1 as FinallIrr
--select @CalcExitValueNew AS EXitvalue


set @CalcExitValue = @CalcExitValueNew

end

--select @CalcIRR1  = ( (@CalcIRR1-1) * 100)
--select @CalcIRR1 as FinalIrr
--select @CalcExitValueNew AS EXitvalue


if @CalcIRR >= 50
begin
set  @CalcIRR = null
end

else
begin
Set  @CalcIRR = @CalcIRR
end

--if cast(@CalcExitValueNew as decimal(30,2)) = cast(@CalcExitValue as decimal(13,2))
--begin
--set  @CalcIRR = null
--end

--else
--begin
--Set  @CalcIRR = @CalcIRR
--end


RETURN  @CalcIRR




--RETURN NULL
END

