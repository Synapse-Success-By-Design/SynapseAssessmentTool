SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_GetLoginAccess] --'Jeyamurugansf'
(
	@OpgcUserEmail NVARCHAR(500)
)

As
BEGIN

--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    05/05/2021 
 --Description    :    Select the Login Feature Access Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Login Feature Details

Uses   
      [USP_Select_Login_GetFeatureAccess]		SP     

Populates
      [WWMG].[Opsuser] 							Table
	  [WWMG].[UserRolePermissionRights]			Table
	  [WWMG].[UserRolePermission]				Table
**************************************************************************/
BEGIN TRY	
declare @result nvarchar(50)
if exists(SELECT OpgcUserId FROM [OPGC].[OpgcUser] WHERE EmailId=@OpgcUserEmail)
begin
set @result='Valid';
end
else
begin
set @result='InValid';
end

SELECT @result AS Result

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		   
		BEGIN
				RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
		END      
END CATCH
END

