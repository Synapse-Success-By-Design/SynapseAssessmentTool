SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[Testtable](
	[Eventdate] [date] NOT NULL,
	[IsInvestment] [int] NOT NULL,
	[2] [decimal](38, 2) NULL,
	[6] [decimal](38, 2) NULL
) ON [PRIMARY]

