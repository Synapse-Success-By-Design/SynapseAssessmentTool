SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [OPGC].[USP_Select_Forecast_InvestmentDetails] --'',4,248
(
	 @userAlias NVARCHAR(250)
	,@fundId INT
	,@scenarioId INT
	
)
--1900-01-01;2032-10-27;2024-03-26;1900-01-01; ; 
As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 



DECLARE @SnapshotDate Datetime = GETDATE()

declare @CheckInvestmentCashflowTypeId100 int = ( select COUNT(1) from [OPGC].[OpgcInvestmentCashFlow] where FundId = @fundId and ScenarioId = @scenarioId and InvestmentCashflowTypeId = 100 and Isdeleted = 0 )

--declare @AquistionDate = select MIN(EventDate) from [OPGC].[OpgcInvestmentCashFlow] where FundId = @fundId and ScenarioId = @scenarioId and InvestmentCashflowTypeId = 100 and Isdeleted = 0

EXEC OPGC.Proc_CalculateGIRR @fundId,@scenarioId,@SnapshotDate

if @CheckInvestmentCashflowTypeId100 = 0

Begin

  ;with CalcInvesmentcashFlowTypeId as (
   select FundId , ScenarioId , InvestmentId  , case when InvestmentCashflowTypeId in (1,2,4,6) then sum(Equity) else 0 End as TotalInvestment , 
          case when InvestmentCashflowTypeId in (3,5,7) then sum(Equity) else 0 End as RealizedProceeds, 
          case when InvestmentCashflowTypeId = 1 then  MIN(EventDate)  End as AquistionDate , InvestmentCashflowTypeId,
          sum(Equity) as Equity,
          case when InvestmentCashflowTypeId in (3,5,7,8) then sum(Equity) else 0 End as ExitValue , case when InvestmentCashflowTypeId = 3 then  Max(EventDate)  End as ExitDate , min(CreatedOn) as CreatedOn
		 
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId not in (100) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0
  group by FundId , ScenarioId , InvestmentId ,InvestmentCashflowTypeId

  
  )
  ,fundcalculatorInvestment as( 
     select FundId , ScenarioId , InvestmentId  , sum(Equity) as TotalInvestment , 0 as RealizedProceeds, 
            MIN(AquistionDate)  as AquistionDate ,
            sum(Equity) as Equity,
            sum(ExitValue) as ExitValue ,  Max(ExitDate)   as ExitDate  ,  min(CreatedOn) as CreatedOn
  from CalcInvesmentcashFlowTypeId 
  where InvestmentCashflowTypeId  in (1,2,4,6) and FundId = @fundId and ScenarioId = @scenarioId 
  group by FundId , ScenarioId , InvestmentId 
  union all
      select FundId , ScenarioId , InvestmentId  , 0 as TotalInvestment , sum(Equity) as RealizedProceeds, 
            MIN(AquistionDate)  as AquistionDate ,
            0 as Equity,
            sum(ExitValue) as ExitValue ,  Max(ExitDate)   as ExitDate   ,min(CreatedOn) as CreatedOn
  from CalcInvesmentcashFlowTypeId 
  where InvestmentCashflowTypeId  in (3,5,7,8) and FundId = @fundId and ScenarioId = @scenarioId 
  group by FundId , ScenarioId , InvestmentId 
  )
 , ResultInsvesment as ( 
 select FundId , ScenarioId , InvestmentId , sum(TotalInvestment) as TotalInvestment , sum(RealizedProceeds) as RealizedProceeds , 
        Min(AquistionDate) as AquistionDate , sum(Equity) as Equity , sum(ExitValue) as ExitValue , max(ExitDate) as ExitDate , min(CreatedOn) as CreatedOn
 from fundcalculatorInvestment
 group by FundId , ScenarioId , InvestmentId 
 )

, FinalResult as ( select FundId , ScenarioId , InvestmentId , TotalInvestment , RealizedProceeds , AquistionDate ,Equity , ExitValue , 
 ExitDate  AS ExitDate , 
  case when Equity > ExitValue Then  ExitVAlue  - Equity    Else 0 End as UnRealizedValue , 

   case when Equity = 0 Then 0 
        when ExitValue = 0 Then 0 else CAST (( ExitVAlue / Equity) AS decimal (20,5)) End  as UnderWritingMultiple ,
   --'23' as GrossIRR,
  case when Equity < ExitValue Then ExitVAlue - Equity
		WHEN  ExitValue =0 THEN 0 
		WHEN ExitValue < Equity THEN -(Equity - ExitValue) Else 0 End as TotalGain ,
  case when Equity = 0 Then 0 
       when ExitVAlue = 0 Then 0 else  CAST(( ExitVAlue / Equity) AS decimal (20,5)) End as  MOIC
  --( ExitVAlue / Equity)  as  MOIC
  ,case when Equity > ExitValue Then (ExitVAlue - Equity) + (RealizedProceeds) Else RealizedProceeds End as TotalValue 
  ,min(CreatedOn) as CreatedOn
 from ResultInsvesment
 Group By  FundId , ScenarioId , InvestmentId , TotalInvestment , RealizedProceeds , AquistionDate ,Equity , ExitValue , ExitDate 
 )
 , FinalResult1 as (
 select A.FundId , A.ScenarioId , A.InvestmentId , B.InvestmentName ,  - (A.TotalInvestment) as TotalInvestment , A.RealizedProceeds ,A.AquistionDate 
 --, A.Equity 
 , cast ( cast ( round (A.Equity ,0) as decimal(30,0)) as nvarchar(max) ) as Equity
 , A.ExitValue ,
 A.ExitDate , A.UnRealizedValue , A.UnderWritingMultiple , A.TotalGain , 
 CASE WHEN MOIC > 0 THEN MOIC 
	  WHEN MOIC <0 THEN -(A.MOIC) END AS MOIC
,R.GIRR GrossIRR ,A.TotalValue
 from FinalResult A
 inner join [OPGC].[OpgcInvestment] B
 on  A.InvestmentId = B.InvestmentId
 INNER JOIN OPGC.OPGCResultGIRR R ON R.FundId = A.FundId AND R.ScenarioId = A.ScenarioId and R.InvestmentID = A.InvestmentId AND R.SnapshotDate = @SnapshotDate
  order by A.CreatedOn asc
 offset 0 rows
 )

-- ,OtherInvestmentType as
-- (  select A.FundId , A.ScenarioId , A.InvestmentId , B.InvestmentName ,  0.00 as TotalInvestment ,  0.00 as RealizedProceeds ,Null as AquistionDate , A.Equity , 0.00 ExitValue ,
-- Null as ExitDate , 0.00 as UnRealizedValue , 0.00 as UnderWritingMultiple , 0.00 as TotalGain , 0.00 as MOIC , 0.00 as GrossIRR ,0.00 as TotalValue
-- from [OPGC].[OpgcInvestmentCashFlow] A
--  inner join [OPGC].[OpgcInvestment] B
-- on  A.InvestmentId = B.InvestmentId
-- where A.FundId = @fundId and A.ScenarioId = @scenarioId and InvestmentCashflowTypeId in(4,5,6,7) and A.Isdeleted = 0
-- )


--  , FinalUnionResult
-- as
-- (
--  select FundId , ScenarioId , InvestmentId , InvestmentName ,   TotalInvestment , RealizedProceeds ,AquistionDate , Equity , ExitValue ,
-- ExitDate , UnRealizedValue , UnderWritingMultiple , TotalGain , MOIC , GrossIRR ,TotalValue
-- from FinalResult1
-- union All
--   select FundId , ScenarioId , InvestmentId , InvestmentName ,   TotalInvestment , RealizedProceeds ,AquistionDate , Equity , ExitValue ,
-- ExitDate , UnRealizedValue , UnderWritingMultiple , TotalGain , MOIC , GrossIRR ,TotalValue
-- from OtherInvestmentType

-- )

-- ,FinalCte
--as
--(  
-- select FundId , ScenarioId , InvestmentId , InvestmentName ,   TotalInvestment , RealizedProceeds ,AquistionDate , Equity , ExitValue ,
--        ExitDate , UnRealizedValue , UnderWritingMultiple , TotalGain , MOIC , GrossIRR ,TotalValue
-- from FinalUnionResult
-- )



SELECT 
  A.FundId as FundId
 ,A.ScenarioId AS ScenarioId
 ,cast ( Stuff (( select ';' + cast (B.InvestmentId as nvarchar (100) ) from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [InvestmentId]
 , cast ( replace ( Stuff (( select ';' + cast (B.InvestmentName as nvarchar (100) ) from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') ,'&amp;','&') as Nvarchar (Max) ) as [InvestmentName]
 ,cast ( Stuff (( select ';' + cast (B.Equity as nvarchar (100) ) from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [Equity]
 ,cast ( Stuff (( select ';' + ISNULL( cast (B.AquistionDate as nvarchar (100)) , ' ' ) from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'')  as Nvarchar (Max) ) as [AquistionDate]
 ,cast ( Stuff (( select ';' + ISNULL ( cast (B.UnderWritingMultiple as nvarchar (100) ) , 'NA') from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [UnderWritingMultiple]
 , cast ( Stuff (( select ';' + ISNULL ( cast (B.ExitDate as nvarchar (100) ) , ' ') from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [ExitDate]
 , cast ( Stuff (( select ';' + iSNULL ( cast (B.ExitValue as nvarchar (100) ) , '') from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [ExitValue]
 , cast ( Stuff (( select ';' + iSNULL ( cast (B.TotalInvestment as nvarchar (100) ) , 'NA') from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [TotalInvested]
 , cast ( Stuff (( select ';' + ISNULL ( cast (B.UnRealizedValue as nvarchar (100) ) , 'NA') from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [UnRealizedValue]
 , cast ( Stuff (( select ';' + cast (B.RealizedProceeds as nvarchar (100) ) from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [RealizedProceeds]
 ,cast ( Stuff (( select ';' + cast (B.TotalValue as nvarchar (100) ) from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [TotalValue]
 ,cast ( Stuff (( select ';' + ISNULL ( cast (B.TotalGain as nvarchar (100) ) , 'NA') from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [TotalGain]
 , cast ( Stuff (( select ';' + ISNULL ( cast (B.MOIC as nvarchar (100) ) , 'NA') from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [MOIC]
 , cast ( Stuff (( select ';' + ISNULL ( cast (B.GrossIRR as nvarchar (100) ) , 'NA') from FinalResult1 B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [GrossIRR]

FROM FinalResult1 A

GROUP BY fundId,ScenarioId --,B.InvestmentId ,b.investmentName

DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate

End

Else
Begin

  ;with CalcInvesmentcashFlowTypeId as (
   select FundId , ScenarioId , InvestmentId  , case when InvestmentCashflowTypeId in (1,2,4,6) then sum(Equity) else 0 End as TotalInvestment , 
          case when InvestmentCashflowTypeId in (3,5,7,8) then sum(Equity) else 0 End as RealizedProceeds, 
          case when InvestmentCashflowTypeId = 1 then  MIN(EventDate)  End as AquistionDate , InvestmentCashflowTypeId,
          sum(Equity) as Equity,
          case when InvestmentCashflowTypeId in (3,5,7,8) then sum(Equity) else 0 End as ExitValue , case when InvestmentCashflowTypeId = 3 then  Max(EventDate)  End as ExitDate , min(CreatedOn) as CreatedOn
		 
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId not in (100) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0
  group by FundId , ScenarioId , InvestmentId ,InvestmentCashflowTypeId

  
  )
  ,fundcalculatorInvestment as( 
     select FundId , ScenarioId , InvestmentId  , sum(Equity) as TotalInvestment , 0 as RealizedProceeds, 
            MIN(AquistionDate)  as AquistionDate ,
            sum(Equity) as Equity,
            sum(ExitValue) as ExitValue ,  Max(ExitDate)   as ExitDate  ,  min(CreatedOn) as CreatedOn
  from CalcInvesmentcashFlowTypeId 
  where InvestmentCashflowTypeId  in (1,2,4,6) and FundId = @fundId and ScenarioId = @scenarioId 
  group by FundId , ScenarioId , InvestmentId 
  union all
      select FundId , ScenarioId , InvestmentId  , 0 as TotalInvestment , sum(Equity) as RealizedProceeds, 
            MIN(AquistionDate)  as AquistionDate ,
            0 as Equity,
            sum(ExitValue) as ExitValue ,  Max(ExitDate)   as ExitDate   ,min(CreatedOn) as CreatedOn
  from CalcInvesmentcashFlowTypeId 
  where InvestmentCashflowTypeId  in (3,5,7,8) and FundId = @fundId and ScenarioId = @scenarioId 
  group by FundId , ScenarioId , InvestmentId 
  )
 , ResultInsvesment as ( 
 select FundId , ScenarioId , InvestmentId , sum(TotalInvestment) as TotalInvestment , sum(RealizedProceeds) as RealizedProceeds , 
        Min(AquistionDate) as AquistionDate , sum(Equity) as Equity , sum(ExitValue) as ExitValue , max(ExitDate) as ExitDate , min(CreatedOn) as CreatedOn
 from fundcalculatorInvestment
 group by FundId , ScenarioId , InvestmentId 
 )

, FinalResult as ( select FundId , ScenarioId , InvestmentId , TotalInvestment , RealizedProceeds , AquistionDate ,Equity , ExitValue , ExitDate , 
  case when Equity > ExitValue Then  ExitVAlue  - Equity    Else 0 End as UnRealizedValue , 

   case when Equity = 0 Then 0 
        when ExitValue = 0 Then 0 else CAST (( ExitVAlue / Equity) AS decimal (20,5)) End  as UnderWritingMultiple ,
   --'23' as GrossIRR,
  case when Equity < ExitValue Then ExitVAlue - Equity
		WHEN  ExitValue =0 THEN 0 
		WHEN ExitValue < Equity THEN -(Equity - ExitValue) Else 0 End as TotalGain ,
  case when Equity = 0 Then 0 
       when ExitVAlue = 0 Then 0 else  CAST(( ExitVAlue / Equity) AS decimal (20,5)) End as  MOIC
  --( ExitVAlue / Equity)  as  MOIC
  ,case when Equity > ExitValue Then (ExitVAlue - Equity) + (RealizedProceeds) Else RealizedProceeds End as TotalValue 
  ,min(CreatedOn) as CreatedOn
 from ResultInsvesment
 Group By  FundId , ScenarioId , InvestmentId , TotalInvestment , RealizedProceeds , AquistionDate ,Equity , ExitValue , ExitDate 
 )
 , FinalResult1 as (
 select A.FundId , A.ScenarioId , A.InvestmentId , B.InvestmentName ,  - (A.TotalInvestment) as TotalInvestment , A.RealizedProceeds ,A.AquistionDate , A.Equity , A.ExitValue ,
 A.ExitDate , A.UnRealizedValue , A.UnderWritingMultiple , A.TotalGain , A.MOIC ,R.GIRR GrossIRR ,A.TotalValue ,A.CreatedOn
 from FinalResult A
 inner join [OPGC].[OpgcInvestment] B
 on  A.InvestmentId = B.InvestmentId
 INNER JOIN OPGC.OPGCResultGIRR R ON R.FundId = A.FundId AND R.ScenarioId = A.ScenarioId and R.InvestmentID = A.InvestmentId AND R.SnapshotDate = @SnapshotDate
 -- order by A.CreatedOn asc
 --offset 0 rows
 )

, [Invesment100]
 as
 (
 select A.FundId , A.ScenarioId , A.InvestmentId , B.InvestmentName ,  0.00 as TotalInvestment ,  0.00 as RealizedProceeds ,Null as AquistionDate , A.Equity , 0.00 ExitValue ,
 Null as ExitDate , 0.00 as UnRealizedValue , 0.00 as UnderWritingMultiple , 0.00 as TotalGain , 0.00 as MOIC , 0.00 as GrossIRR ,0.00 as TotalValue , A.CreatedOn
 from [OPGC].[OpgcInvestmentCashFlow] A
  inner join [OPGC].[OpgcInvestment] B
 on  A.InvestmentId = B.InvestmentId
 where A.FundId = @fundId and A.ScenarioId = @scenarioId and InvestmentCashflowTypeId = 100 and A.Isdeleted = 0
 )

 , FinalUnionResult
 as
 (
  select FundId , ScenarioId , InvestmentId , InvestmentName ,   TotalInvestment , RealizedProceeds ,AquistionDate , Equity , ExitValue ,
 ExitDate , UnRealizedValue , UnderWritingMultiple , TotalGain , 
  MOIC
 , GrossIRR ,TotalValue , CreatedOn
 from FinalResult1
 union All
   select FundId , ScenarioId , InvestmentId , InvestmentName ,   TotalInvestment , RealizedProceeds ,AquistionDate , Equity , ExitValue ,
 ExitDate , UnRealizedValue , UnderWritingMultiple , TotalGain ,  MOIC , GrossIRR ,TotalValue , CreatedOn
 from [Invesment100]

 )

,FinalCte
as
(  
 select FundId , ScenarioId , InvestmentId , InvestmentName ,   TotalInvestment , RealizedProceeds ,AquistionDate
        --, Equity 
		 , cast ( cast ( round (Equity ,0) as decimal(30,0)) as nvarchar(max) ) as Equity
		, ExitValue ,
        ExitDate , UnRealizedValue , UnderWritingMultiple , TotalGain ,  
	CASE WHEN MOIC > 0 THEN MOIC 
	     WHEN MOIC <0 THEN -(MOIC) else cast (0 as decimal(18,2)) END AS MOIC  ,
	  GrossIRR ,TotalValue 
 from FinalUnionResult
 order by CreatedOn asc
 offset 0 rows
 )

SELECT 
  A.FundId as FundId
 ,A.ScenarioId AS ScenarioId
 ,cast ( Stuff (( select ';' + cast (B.InvestmentId as nvarchar (100) ) from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [InvestmentId]
 , cast ( replace ( Stuff (( select ';' + cast (B.InvestmentName as nvarchar (100) ) from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') ,'&amp;','&') as Nvarchar (Max) ) as [InvestmentName]
 ,cast ( Stuff (( select ';' + cast (B.Equity as nvarchar (100) ) from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [Equity]
 ,cast ( Stuff (( select ';' + ISNULL (cast (B.AquistionDate as nvarchar (100) ) , ' ' ) from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'')  as Nvarchar (Max) ) as [AquistionDate]
 ,cast ( Stuff (( select ';' + ISNULL ( cast (B.UnderWritingMultiple as nvarchar (100) ) , 'NA') from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [UnderWritingMultiple]
 , cast ( Stuff (( select ';' + ISNULL ( cast (B.ExitDate as nvarchar (100) ) , ' ') from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [ExitDate]
 , cast ( Stuff (( select ';' + iSNULL ( cast (B.ExitValue as nvarchar (100) ) , 'NA') from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [ExitValue]
 , cast ( Stuff (( select ';' + iSNULL ( cast (B.TotalInvestment as nvarchar (100) ) , 'NA') from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [TotalInvested]
 , cast ( Stuff (( select ';' + ISNULL ( cast (B.UnRealizedValue as nvarchar (100) ) , 'NA') from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [UnRealizedValue]
 , cast ( Stuff (( select ';' + cast (B.RealizedProceeds as nvarchar (100) ) from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [RealizedProceeds]
 ,cast ( Stuff (( select ';' + cast (B.TotalValue as nvarchar (100) ) from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [TotalValue]
 ,cast ( Stuff (( select ';' + ISNULL ( cast (B.TotalGain as nvarchar (100) ) , 'NA') from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [TotalGain]
 , cast ( Stuff (( select ';' + ISNULL ( cast (B.MOIC as nvarchar (100) ) , 'NA') from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [MOIC]
 , cast ( Stuff (( select ';' + ISNULL ( cast (B.GrossIRR as nvarchar (100) ) , 'NA') from FinalCte B where B.FundId = A.FundId and B.ScenarioId = A.ScenarioId 
            FOR XML PATH('')),1,1,'') as Nvarchar (Max) ) as [GrossIRR]

FROM FinalCte A

GROUP BY fundId,ScenarioId --,B.InvestmentId ,b.investmentName


DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate

end


--insert into [OPGC].[OPGCResultGIRR_History] ( FundId , ScenarioId , InvestmentID , GIRR, SnapshotDate , Modifiedon ,  ModifiedBy , InvestmentName)
--select  A.FundId , A.ScenarioId , A.InvestmentID , A.GIRR, A.SnapshotDate , GETDATE() , 'Select Investment details' ,B.InvestmentName
--from OPGC.OPGCResultGIRR A
--Left Join [OPGC].[OpgcInvestment] B
--on A.InvestmentID = B.InvestmentId and B.Isdeleted = 0


DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate


END






