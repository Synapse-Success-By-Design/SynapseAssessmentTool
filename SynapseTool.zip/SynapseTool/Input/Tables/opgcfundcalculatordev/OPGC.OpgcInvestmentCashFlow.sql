SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcInvestmentCashFlow](
	[InvestmenCashflowId] [int] IDENTITY(1,1) NOT NULL,
	[FundId] [int] NOT NULL,
	[ScenarioId] [int] NOT NULL,
	[InvestmentCashflowTypeId] [int] NOT NULL,
	[InvestmentId] [int] NOT NULL,
	[Equity] [decimal](30, 2) NULL,
	[EventDate] [date] NOT NULL,
	[IsActual] [bit] NULL,
	[IsHypothetical] [bit] NULL,
	[RecallableUntil] [datetime] NULL,
	[Tag] [nvarchar](250) NULL,
	[Isdeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
	[ValidFrom] [datetime2](0) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](0) GENERATED ALWAYS AS ROW END NOT NULL,
	[IsRecallable] [bit] NULL,
	[LimitedPartnerPercent] [decimal](5, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[InvestmenCashflowId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [OPGC].[OpgcInvestmentCashFlowHistory] )
)

ALTER TABLE [OPGC].[OpgcInvestmentCashFlow] ADD  DEFAULT ((0)) FOR [Isdeleted]
ALTER TABLE [OPGC].[OpgcInvestmentCashFlow] ADD  CONSTRAINT [df_OpgcInvestmentCashFlow_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
ALTER TABLE [OPGC].[OpgcInvestmentCashFlow] ADD  CONSTRAINT [DF_ValidFrom_InvestmentCashFlow1]  DEFAULT (dateadd(second,(-1),sysutcdatetime())) FOR [ValidFrom]
ALTER TABLE [OPGC].[OpgcInvestmentCashFlow] ADD  CONSTRAINT [DF_ValidTo_InvestmentCashFlow1]  DEFAULT ('9999.12.31 23:59:59.99') FOR [ValidTo]
ALTER TABLE [OPGC].[OpgcInvestmentCashFlow]  WITH CHECK ADD FOREIGN KEY([FundId])
REFERENCES [OPGC].[OpgcFund] ([FundId])
ALTER TABLE [OPGC].[OpgcInvestmentCashFlow]  WITH CHECK ADD FOREIGN KEY([InvestmentCashflowTypeId])
REFERENCES [OPGC].[OpgcInvestmentCashFlowType] ([InvestmentCashFlowTypeId])
ALTER TABLE [OPGC].[OpgcInvestmentCashFlow]  WITH CHECK ADD FOREIGN KEY([InvestmentId])
REFERENCES [OPGC].[OpgcInvestment] ([InvestmentId])
ALTER TABLE [OPGC].[OpgcInvestmentCashFlow]  WITH CHECK ADD FOREIGN KEY([ScenarioId])
REFERENCES [OPGC].[OpgcScenario] ([ScenarioId])
