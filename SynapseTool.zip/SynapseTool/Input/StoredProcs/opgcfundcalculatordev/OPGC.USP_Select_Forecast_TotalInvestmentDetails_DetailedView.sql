SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [OPGC].[USP_Select_Forecast_TotalInvestmentDetails_DetailedView] --'',56,171
(
	 @userAlias NVARCHAR(250)
	,@fundId INT
	,@scenarioId INT
	
)

as
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 


--;with Investment as
--(
--select FundId , ScenarioId , InvestmentId  , sum(Equity) as InitialInvestment , 0 as ExitValue 
--  from [OPGC].[OpgcInvestmentCashFlow] 
--  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0
--  group by FundId , ScenarioId , InvestmentId 
--  union all 
--  select FundId , ScenarioId , InvestmentId  , 0 as IntialInvestment , sum(Equity) as ExitValue   
--  from [OPGC].[OpgcInvestmentCashFlow] 
--  where InvestmentCashflowTypeId in (3,5,7) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0
--  group by FundId , ScenarioId , InvestmentId 
--  )
--, TotalInvestment as
--(
--  select FundId , ScenarioId , InvestmentId  , sum( InitialInvestment) as Investment , sum (ExitValue)  as ExitVAlue 
--  from Investment A
--   group by FundId , ScenarioId , InvestmentId 
--)

----select * from TotalIvestment

--, EventDate as
--(
--select A.FundId , A.ScenarioId , A.InvestmentId , B.InvestmentName ,A.InvestmentCashflowTypeId ,  
--      case when A.InvestmentCashflowTypeId in (1,2,4,6) then -(A.Equity) else A.Equity end as Equity,
--	   CAST(A.EventDate AS Date)  as EventDate 
--	  , CASE WHEN A.IsActual = 1 THEN 'Actual' ELSE 'Hypothetical' END AS [Status]
--	  ,A.CreatedON

--  from [OPGC].[OpgcInvestmentCashFlow]  A
--  inner join [OPGC].[OpgcInvestment] B
--  on A.InvestmentId = B.InvestmentId
--  where  A.FundId = @fundId and ScenarioId = @scenarioId and A.Isdeleted=0 and A.InvestmentCashflowTypeId in (1,2,3,4,5,6,7)
--  order by EventDate ,InvestmentCashflowTypeId
--  offset 0 rows
--)



--, [InvestmentandExitRealized] as (
--select A.FundId , A.ScenarioId , A.InvestmentId  , A.[EventDate],A.InvestmentCashflowTypeId,
--        case when (B.ExitValue > B.Investment ) then  A.Equity  else 0 end as Realized,
--	    case when (B.ExitValue <= B.Investment ) then A.Equity else 0 end as UnRealized
--    	,A.[Status]
--		,A.CreatedON
--  from EventDate  A
--  inner join TotalInvestment B 
--  on A.FundId = B.FundId and A.ScenarioId = B.ScenarioId and  A.InvestmentId = B.InvestmentId
--)




--select /*FundId , ScenarioId , InvestmentId  , */ 
--       [EventDate],  
--       cast ( round(( Realized + UnRealized ),0) as decimal(18,0)) as [RealizedandUnRealizedInvestment] , 
--      cast ( round(( Realized ),0) as decimal(18,0)) as  Realized ,
--	   cast ( round(( UnRealized ),0) as decimal(18,0)) as  UnRealized 
--	   ,[Status]
--      from [InvestmentandExitRealized]
--	  order by EventDate--,InvestmentCashflowTypeId,InvestmentId

----select /*FundId , ScenarioId , InvestmentId  , */ 
----       [EventDate],  
----       Realized + UnRealized as [RealizedandUnRealizedInvestment] , 
----       Realized ,
----	   UnRealized 
----      from [InvestmentandExitRealized]
----	  order by EventDate,InvestmentCashflowTypeId,InvestmentId

------------------------------------------------------------------------------------------------------------------------------

--select EventDate,
--       case when InvestmentCashflowTypeId in (1,2,4,6) then  -Equity else Equity end   as [RealizedandUnRealizedInvestment] ,
--	   0.00 as Realized,
--	   0.00 as UnRealized,
--	    CASE WHEN IsActual = 1 THEN 'Actual' ELSE 'Hypothetical' END AS [Status]
--	   from [OPGC].[OpgcInvestmentCashFlow] where FundID = @fundId and ScenarioId = @scenarioId and InvestmentCashflowTypeId in (1,2,3,4,5,6,7) and Isdeleted = 0
--order by EventDate

------------------------------------------------------------------------------------------------------

select 

       EventDate,
       case when InvestmentCashflowTypeId in (1,2,4,6) then   cast ( cast ( round (-Equity ,0) as decimal(30,0)) as nvarchar(max) ) else cast ( cast ( round (Equity ,0) as decimal(30,0)) as nvarchar(max) ) end   as [RealizedandUnRealizedInvestment] ,
	    0.00 as Realized,
	   0.00 as UnRealized,
	    CASE WHEN IsActual = 1 THEN 'Actual' ELSE 'Hypothetical' END AS [Status]
	   from [OPGC].[OpgcInvestmentCashFlow] where FundID = @fundId and ScenarioId = @scenarioId and InvestmentCashflowTypeId in (1,2,3,4,5,6,7,8) and Isdeleted = 0
order by EventDate 


END

