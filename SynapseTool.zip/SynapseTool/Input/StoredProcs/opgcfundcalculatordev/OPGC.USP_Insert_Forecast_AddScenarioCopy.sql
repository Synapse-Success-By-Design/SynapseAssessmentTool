SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Insert_Forecast_AddScenarioCopy] --'',6,95
(
	  @userAlias NVARCHAR(50)
	 ,@Fundid INT
	 ,@ScenarioId INt
	 --,@ScenarioName NVARCHAR(20)
	 --,@ScenarioDescription NVARCHAR(500)
	 --,@BaseLineStatus BIT
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

Begin Tran

BEGIN TRY

	  declare @CommittedCapital               DECIMAL(30,2)   = ( select CommittedCapital               from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId )
	  declare @OffsetsByQuarter               DECIMAL(30,2)   = ( select OffsetsByQuarter				  from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId )
	  declare @OtherPartnershipFeesByQuarter  DECIMAL(30,2)   = ( select OtherPartnershipFeesByQuarter  from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId )
	  declare @FundInceptionDate              DATETIME	    = ( select FundInceptionDate			  from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId )
	  declare @ManualStepdownDate​             DATETIME	    = ( select ManualStepdownDate			  from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId )
	  declare @LPPreferredReturnPercent       DECIMAL(5,2)    = ( select LPPreferredReturnPercent		  from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId )
	  declare @LPFinalSharePercent            DECIMAL(5,2)    = ( select LPFinalSharePercent			  from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId )
	  declare @GPPreferredReturnPercent       DECIMAL(5,2)    = ( select GPPreferredReturnPercent		  from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId )
	  declare @ManagementFeePercent​           DECIMAL(30,2)   = ( select ManagementFeePercent 		  from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId )


declare @Errortext nvarchar(250)
declare @ScenarionNameCount int  = (select count(1)   from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId /*and Isdeleted = 0*/ )

if @ScenarionNameCount = 0 
begin
SET @ErrorText = 'Please select valid scenario ID'
RAISERROR (@ErrorText, 16, 1)
end




declare @CopyNo int



--declare @FinalScenarioName nvarchar(250) 

declare @ScenarionName nvarchar (250)  = (select ScenarioName   from [OPGC].[OpgcScenario] where FundID = @Fundid and ScenarioId = @ScenarioId /* and Isdeleted = 0 */)

declare @CopyScenarioCount int = ( select count(1) from [OPGC].[OpgcScenario] where FundID = @Fundid and CopiedFrom =  @ScenarioId /*and Isdeleted = 0 */)

--declare @CopyNameCheck int = ( select len(ScenarioName) - len(replace(ScenarioName,'Copy','')) from [OPGC].[OpgcScenario]  where FundID = @Fundid and ScenarioId = @ScenarioId and Isdeleted = 0)

DECLARE @CopyFound int = ( SELECT CHARINDEX('copy',@ScenarionName) )
   declare @TempScenarioName nvarchar(250)
   declare @CopyScenarioName nvarchar(250)
   declare @FinalScenarioName nvarchar(250)

If @CopyScenarioCount = 0
begin


       -- set @ScenarionName = @ScenarionName + '_Copy01'
    If @CopyFound = 0
	begin
	   set @FinalScenarioName = concat ( @ScenarionName ,'_Copy01')

	end
	else 
	begin
	   --set @TempScenarioName = ( SELECT SUBSTRING(@ScenarionName, 0, CHARINDEX('_', @ScenarionName)) )
	   set @TempScenarioName = ( select SUBSTRING(@ScenarionName,1, LEN(@ScenarionName)-len  (right(@ScenarionName,7)  ) ) ) --new added
	   set @TempScenarioName = concat ( @TempScenarioName , '%')
	   set @CopyScenarioName = ( select Top 1 ScenarioName  from [OPGC].[OpgcScenario] where FundId = @Fundid  and ScenarioName like @TempScenarioName  order by 1 desc )

       set @CopyNo = max( cast (right(@CopyScenarioName,2) as int ))

	   If @CopyNo < 99
       begin
           SET @CopyNo = isnull ( @CopyNo ,0) +1    
          -- select @CopyNo
          SET @FinalScenarioName = SUBSTRING(@CopyScenarioName,1, LEN(@CopyScenarioName)-LEN(@CopyNo))+ CAST(@CopyNo AS Nvarchar(50)) 
          --select @FinalScenarioName
       end
       else
       begin
          SET @ErrorText = 'Cannot Copy Scenario. Copy limit count is reached  '
          RAISERROR (@ErrorText, 16, 1)
       end
       --SET @CopyNo = isnull ( @CopyNo ,0) +1                   
       --SET @FinalScenarioName = SUBSTRING(@CopyScenarioName,1, LEN(@CopyScenarioName)-LEN(@CopyNo))+ CAST(@CopyNo AS Nvarchar(50)) 
    End

	


      insert into [OPGC].[OpgcScenario]
      (
       FundID
      ,ScenarioName
      ,IsBaseline
      ,CreatedBy
      ,CreatedOn
      ,ModifiedBy
      ,ModifiedOn
      ,CopiedFrom
	  ,CommittedCapital
      ,OffsetsByQuarter
      ,OtherPartnershipFeesByQuarter
      ,FundInceptionDate
      ,ManualStepdownDate
      ,LPPreferredReturnPercent
      ,LPFinalSharePercent
      ,GPPreferredReturnPercent
      ,ManagementFeePercent
      )
      
      select 
       @Fundid
      ,@FinalScenarioName
      ,0
      ,@userAlias
      ,getdate()
      ,NULL
      ,NULL
      ,@ScenarioId
	  ,@CommittedCapital             
      ,@OffsetsByQuarter             
      ,@OtherPartnershipFeesByQuarter
      ,@FundInceptionDate            
      ,@ManualStepdownDate​           
      ,@LPPreferredReturnPercent     
      ,@LPFinalSharePercent          
      ,@GPPreferredReturnPercent     
      ,@ManagementFeePercent​  
	  

end

else 

begin


    If @CopyFound = 0
	begin
	   set @TempScenarioName = concat (@ScenarionName,'%')
	    

	end
	else 
	begin
	   --set @TempScenarioName = ( SELECT SUBSTRING(@ScenarionName, 0, CHARINDEX('_', @ScenarionName)) )
	   set @TempScenarioName = ( select SUBSTRING(@ScenarionName,1, LEN(@ScenarionName)-len  (right(@ScenarionName,7)  ) ) ) --new added
	   set @TempScenarioName = concat ( @TempScenarioName , '%')
    End

set @CopyScenarioName = ( select Top 1 ScenarioName  from [OPGC].[OpgcScenario] where FundId = @Fundid  and ScenarioName like @TempScenarioName  order by 1 desc )
--copy 100
------------------------------------------newly added 22 march ------------------------------------------------------------------------------

set @CopyFound = ( SELECT CHARINDEX('copy',@CopyScenarioName) )

    If @CopyFound = 0
	begin
	  -- print'@CopyFound = 0'
	   set @FinalScenarioName = concat ( @CopyScenarioName ,'_Copy01')

	end
  else
  begin


----------------------------------------------------------------------------------------------------------------------------------
IF  SUBSTRING(@CopyScenarioName,1, LEN(@CopyScenarioName)-LEN(right(@CopyScenarioName,2)) ) =  SUBSTRING(@ScenarionName,1, LEN(@ScenarionName)-LEN(right(@ScenarionName,2)) )
  BEGIN
     set @CopyNo = max( cast (right(@CopyScenarioName,2) as int ))

    If @CopyNo < 99
    begin
        SET @CopyNo = isnull ( @CopyNo ,0) +1    
       -- select @CopyNo
        SET @FinalScenarioName = SUBSTRING(@CopyScenarioName,1, LEN(@CopyScenarioName)-LEN(@CopyNo))+ CAST(@CopyNo AS Nvarchar(50)) 
        --select @FinalScenarioName
    end
    else
    begin
        SET @ErrorText = 'Cannot Copy Scenario. Copy limit count is reached  '
        RAISERROR (@ErrorText, 16, 1)
    end
  END
  ELSE
  BEGIN




-----------------------new part----------------------------
declare @DescNameCheck nvarchar(250) = ( select SUBSTRING(@CopyScenarioName,1, LEN(@CopyScenarioName)-LEN(right(@CopyScenarioName,7)) ) )
--select @DescNameCheck as DescNameCheck
--select @ScenarionName as  ScenarionName

If @DescNameCheck <> @ScenarionName
begin
set @FinalScenarioName = concat ( @ScenarionName ,'_Copy01')
end
else
begin
----------------------------------------------newpart--------------------
 DECLARE @CopyFoundCheck1 int = ( SELECT CHARINDEX('copy',@CopyScenarioName) )
     If @CopyFoundCheck1 = 0
	begin
	   set @FinalScenarioName = concat ( @CopyScenarioName ,'_Copy01')

	end
	else 
	begin
        set @CopyNo = max( cast (right(@CopyScenarioName,2) as int ))

    If @CopyNo < 99
    begin
        SET @CopyNo = isnull ( @CopyNo ,0) +1    
       -- select @CopyNo
        SET @FinalScenarioName = SUBSTRING(@CopyScenarioName,1, LEN(@CopyScenarioName)-LEN(@CopyNo))+ CAST(@CopyNo AS Nvarchar(50)) 
        --select @FinalScenarioName
    end
    else
    begin
        SET @ErrorText = 'Cannot Copy Scenario. Copy limit count is reached  '
        RAISERROR (@ErrorText, 16, 1)
    end
	end
	end
-- SET @CopyNo = isnull ( @CopyNo ,0) +1            
--SET @FinalScenarioName = SUBSTRING(@CopyScenarioName,1, LEN(@CopyScenarioName)-LEN(@CopyNo))+ CAST(@CopyNo AS Nvarchar(50)) 

END

End
         
      insert into [OPGC].[OpgcScenario]
      (
       FundID
      ,ScenarioName
      ,IsBaseline
      ,CreatedBy
      ,CreatedOn
      ,ModifiedBy
      ,ModifiedOn
      ,CopiedFrom
      ,CommittedCapital
      ,OffsetsByQuarter
      ,OtherPartnershipFeesByQuarter
      ,FundInceptionDate
      ,ManualStepdownDate
      ,LPPreferredReturnPercent
      ,LPFinalSharePercent
      ,GPPreferredReturnPercent
      ,ManagementFeePercent
      )
      
      select 
       @Fundid
      ,@FinalScenarioName
      ,0
      ,@userAlias
      ,getdate()
      ,NULL
      ,NULL
      ,@ScenarioId
      ,@CommittedCapital             
      ,@OffsetsByQuarter             
      ,@OtherPartnershipFeesByQuarter
      ,@FundInceptionDate            
      ,@ManualStepdownDate​           
      ,@LPPreferredReturnPercent     
      ,@LPFinalSharePercent          
      ,@GPPreferredReturnPercent     
      ,@ManagementFeePercent​  

end


Declare @FinalScenarioId int = ( select Top 1 ScenarioId from [OPGC].[OpgcScenario] where FundID = @FundId order by 1 desc )

declare @CashFlowEvent as table
(
	[FundId] [int] ,
	[ScenarioId] [int] ,
	[InvestmentCashflowTypeId] [int] ,
	[InvestmentId] [int] ,
	[Equity] [decimal](18, 2) ,
	[EventDate] [date] ,
	[IsActual] [bit] ,
	[IsHypothetical] [bit] ,
	[RecallableUntil] [datetime] ,
	[Tag] [nvarchar](250) ,
	[Isdeleted] [bit] ,
	[CreatedBy] [nvarchar](250) ,
	[CreatedOn] [datetime] ,
	[IsRecallable] [bit],
	LimitedPartnerPercent decimal(5,2)

)


declare @FundCashFlowEvent as table 
(
	[FundId] [int] ,
	[ScenarioId] [int] ,
	[FundCashflowTypeId] [int] ,
	[EventDate] [datetime]  ,
	[ValueAmount] [decimal](18, 2)  ,
	[IsActual] [bit] ,
	[IsHypothetical] [bit] ,
	[Tag] [nvarchar](250) ,
	[Isdeleted] [bit] ,
	[CreatedBy] [nvarchar](250) ,
	[CreatedOn] [datetime] ,
	LimitedPartnerPercent decimal(5,2)

	
)


insert into @CashFlowEvent
(
       [FundId]
      ,[ScenarioId]
      ,[InvestmentCashflowTypeId]
      ,[InvestmentId]
      ,[Equity]
      ,[EventDate]
      ,[IsActual]
      ,[IsHypothetical]
      ,[RecallableUntil]
      ,[Tag]
      ,[Isdeleted]
      ,[CreatedBy]  
	  ,[CreatedOn] 
      ,[IsRecallable]
	  ,LimitedPartnerPercent 
)

select [FundId]
      ,@FinalScenarioId as [ScenarioId]
      ,[InvestmentCashflowTypeId]
      ,[InvestmentId]
      ,[Equity]
      ,[EventDate]
      ,[IsActual]
      ,[IsHypothetical]
      ,[RecallableUntil]
      ,[Tag]
      ,[Isdeleted]
      ,@userAlias
      ,getdate()
      ,[IsRecallable]
	  ,LimitedPartnerPercent 
FROM [OPGC].[OpgcInvestmentCashFlow]
where FundId = @Fundid and ScenarioId = @ScenarioId and Isdeleted = 0


insert into [OPGC].[OpgcInvestmentCashFlow]
(
       [FundId]
      ,[ScenarioId]
      ,[InvestmentCashflowTypeId]
      ,[InvestmentId]
      ,[Equity]
      ,[EventDate]
      ,[IsActual]
      ,[IsHypothetical]
      ,[RecallableUntil]
      ,[Tag]
      ,[Isdeleted]
      ,[CreatedBy]
      ,[CreatedOn]
      ,[IsRecallable]
	  ,LimitedPartnerPercent
)

select 
       [FundId]
      ,[ScenarioId]
      ,[InvestmentCashflowTypeId]
      ,[InvestmentId]
      ,[Equity]
      ,[EventDate]
      ,[IsActual]
      ,[IsHypothetical]
      ,[RecallableUntil]
      ,[Tag]
      ,[Isdeleted]
      ,[CreatedBy]
      ,[CreatedOn]
      ,[IsRecallable]
	  ,LimitedPartnerPercent
from @CashFlowEvent

------------------------------------------------Inserting FundcashFlow - ---------------------------------------------

insert into @FundCashFlowEvent
(
       [FundId]
      ,[ScenarioId]
      ,[FundCashflowTypeId]
      ,[EventDate]
      ,[ValueAmount]
      ,[IsActual]
      ,[IsHypothetical]
      ,[Tag]
      ,[Isdeleted]
      ,[CreatedBy]
      ,[CreatedOn]
	  ,LimitedPartnerPercent
	  
)

select

       [FundId]	
      ,@FinalScenarioId as [ScenarioId]
      ,[FundCashflowTypeId]
      ,[EventDate]
      ,[ValueAmount]
      ,[IsActual]
      ,[IsHypothetical]
      ,[Tag]
      ,[Isdeleted]
	  ,CreatedBy
      ,getdate()
	  ,LimitedPartnerPercent

from [OPGC].[OpgcFundCashFlow]
where FundId = @Fundid and ScenarioId = @ScenarioId and Isdeleted = 0


insert into [OPGC].[OpgcFundCashFlow]
(
       [FundId]
      ,[ScenarioId]
      ,[FundCashflowTypeId]
      ,[EventDate]
      ,[ValueAmount]
      ,[IsActual]
      ,[IsHypothetical]
      ,[Tag]
      ,[Isdeleted]
      ,[CreatedBy]
      ,[CreatedOn]
	  ,LimitedPartnerPercent
)

select 
       [FundId]
      ,[ScenarioId]
      ,[FundCashflowTypeId]
      ,[EventDate]
      ,[ValueAmount]
      ,[IsActual]
      ,[IsHypothetical]
      ,[Tag]
      ,[Isdeleted]
      ,[CreatedBy]
      ,[CreatedOn]
	  ,LimitedPartnerPercent
from @FundCashFlowEvent

commit Tran

END TRY
BEGIN CATCH
Rollback Tran
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
    IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END  --Error Handling Messages 
END CATCH
END


