SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcUserRolePermission](
	[OpgcUserId] [int] NULL,
	[OpgcUserRoleId] [int] NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcUserRolePermission] ADD  CONSTRAINT [df_OpgcUserRolePermission_IsDeleted]  DEFAULT ((0)) FOR [IsDeleted]
ALTER TABLE [OPGC].[OpgcUserRolePermission] ADD  CONSTRAINT [df_OpgcUserRolePermission_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
ALTER TABLE [OPGC].[OpgcUserRolePermission]  WITH CHECK ADD  CONSTRAINT [FK__OpgcUserR__OpgcU__13F1F5EB] FOREIGN KEY([OpgcUserId])
REFERENCES [OPGC].[OpgcUser] ([OpgcUserId])
ALTER TABLE [OPGC].[OpgcUserRolePermission] CHECK CONSTRAINT [FK__OpgcUserR__OpgcU__13F1F5EB]
ALTER TABLE [OPGC].[OpgcUserRolePermission]  WITH CHECK ADD FOREIGN KEY([OpgcUserRoleId])
REFERENCES [OPGC].[OpgcUserRole] ([OpgcUserRoleId])
