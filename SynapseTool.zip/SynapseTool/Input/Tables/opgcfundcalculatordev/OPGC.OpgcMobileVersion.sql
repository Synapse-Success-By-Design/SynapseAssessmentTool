SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcMobileVersion](
	[OpgcMobileVersionId] [int] IDENTITY(1,1) NOT NULL,
	[OpgcPlatformName] [nvarchar](25) NULL,
	[OpgcEnvironment] [nvarchar](10) NULL,
	[OpgcVersionNumber] [nvarchar](5) NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[OpgcMobileVersionId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcMobileVersion] ADD  DEFAULT ((0)) FOR [IsDeleted]
