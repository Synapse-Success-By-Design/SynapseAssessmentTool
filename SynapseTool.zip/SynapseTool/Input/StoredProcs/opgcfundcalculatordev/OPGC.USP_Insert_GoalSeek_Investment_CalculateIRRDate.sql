SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [OPGC].[USP_Insert_GoalSeek_Investment_CalculateIRRDate] --'DB Team' , 5 , 30, 22,20,520000000000000,null
(  

@UserAlias      nvarchar(250),
@FundId         int,
@ScenarioId     int ,
@InvestmentId   int ,
@TargetIRR      decimal (30,10),
@TargetExitValue     decimal(30,2) ,
@GSInvestmentId int out
 
   
)  
  
As  
  
BEGIN  


BEGIN TRY


DECLARE @ErrorText NVARCHAR(MAX) =''

If  @TargetIRR <= 0 or @TargetIRR is null
begin
SET @ErrorText = 'Please enter valid Target IRR'
RAISERROR (@ErrorText, 16, 1)

end

If  @TargetExitValue is null or @TargetExitValue <= 0
begin
SET @ErrorText = 'Please enter valid Target ExitValue'
RAISERROR (@ErrorText, 16, 1)
end

   
DECLARE @cashflowdetails as table (
 FundID INT
,ScenarioId INT
,InvestmentId INT
, InvestmentCashFlowTypeId int
,EventDate DateTime
,Equity Decimal (30,2)

)
--declare @MindateAdd date = ( select min(EventDate)  from [OPGC].[OpgcInvestmentCashFlow]   where InvestmentCashflowTypeId  = 1 and 
--  FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentId and Isdeleted=0  )
declare @Invesmentname nvarchar(250) = (select InvestmentName from [OPGC].[OpgcInvestment] where FundID = @FundId and InvestmentId =@InvestmentId and Isdeleted = 0)

declare  @TargetIRR1 decimal(30,10) = ( select 1 + (@TargetIRR/100))


declare @InvesmentIdBase as table ( Id int)

declare @ExitValueCheck  int 


declare @CalcExitDateValue decimal(30,2)

declare @FinalExitDate date


;with investmentBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdBase
select A.InvestmentId from investmentBaseInitial A
join investmentBaseExit B
on A.InvestmentId =B.InvestmentId

--------insert target investment id --------------------------
insert into @InvesmentIdBase
select @InvestmentId


declare @MindateAdd date = ( select min(EventDate)  from [OPGC].[OpgcInvestmentCashFlow]   where InvestmentCashflowTypeId  in (1,2,4,6) and 
  FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId in (select Id from @InvesmentIdBase)  and Isdeleted=0  )


--Declare @MinDate table 
--( FundId int , 
--  ScenarioId int , 
--  InvestmentId int,
--  MinEvenDate date
--)

--;with mindate as
--(
--select FundId ,ScenarioId ,InvestmentId ,EventDate
--from [OPGC].[OpgcInvestmentCashFlow]
--where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentCashflowTypeId in (1,2,4,6) and InvestmentId in ( select Id from @InvesmentIdBase ) and Isdeleted = 0
--)

--insert into @MinDate
--select FundId ,ScenarioId ,InvestmentId ,Min(EventDate)
--from mindate
--group by FundId ,ScenarioId ,InvestmentId

Declare @EventCashFlow table
(
 Id Int Identity (1,1)
 ,FundId	   int
,ScenarioId	int
,InvestmentId	Int
,InvesmentName nvarchar(250)
,InvestmentCashflowTypeId int
,EventDate	Date
,Equity	Decimal (30,2)
,IsSelectedInvestment	bit
,MinDate	Date
)

insert into @EventCashFlow

select A.FundId , A.ScenarioId , A.InvestmentId, B.InvestmentName ,A.InvestmentCashflowTypeId
, A.EventDate ,
 case when A.InvestmentCashflowTypeId IN ( 1,2,4,6) then - A.Equity else A.Equity end as Equity ,
case when A.InvestmentId = @InvestmentId then 1 else 0 end as IsSelectedInvestment
--,C.MinEvenDate
,@MindateAdd as MinEvenDate
from [OPGC].[OpgcInvestmentCashFlow] A
join [OPGC].[OpgcInvestment] B
on A.FundId = B.FundID and A.InvestmentId = B.InvestmentId
--join @MinDate C
--on A.InvestmentId = C.InvestmentId
where A.FundId = @FundId and A.ScenarioId = @ScenarioId and A.InvestmentId in ( select Id from @InvesmentIdBase ) and A.Isdeleted = 0

insert into @EventCashFlow

select @FundId , @ScenarioId , @InvestmentId , @Invesmentname , 3 , Null , @TargetExitValue ,1,null

----------------------------------inserting GIRR---------------------------------------------------------
insert into @cashflowdetails
(
 FundID 
,ScenarioId 
,InvestmentId 
, InvestmentCashFlowTypeId 
,EventDate 
,Equity 
)

select 
 FundId	   
,ScenarioId	
,InvestmentId	
,InvestmentCashflowTypeId 
,EventDate
,Equity
from @EventCashFlow where EventDate is not null
----------------------------------------------------------------------------------------------------------------------------------

; with YearDiff as 
(
select 
 Id
 ,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
--, case when IsSelectedInvestment =0  then datediff(day,MinDate ,EventDate) / 365.2425 
--       else datediff(day,MinDate , @TargetDate)/ 365.2425 end  as  YearDiffernce 
, cast ( datediff(day,MinDate ,EventDate) as decimal(30,10))  as YearDiffernce 
,   @TargetIRR1 as  TargetIRR 
--,cast (POWER(@TargetIRR,YearDiffernce) as float)
from @EventCashFlow
)

--select * from YearDiff

, [YearDiffernce/365] as 
(
select 
 Id
 ,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate
, YearDiffernce
, cast ( YearDiffernce / 365  as decimal(30,10) ) as [YearDiffernce/365] 
,  TargetIRR 
--,cast (POWER(TargetIRR,YearDiffernce) as decimal(18,5)) as DcValue
from YearDiff
)

, DcValue as 
(
select 
 Id
 ,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
, [YearDiffernce/365]
--, YearDiffernce 
,  TargetIRR 
,cast (POWER(TargetIRR,[YearDiffernce/365]) as decimal(30,10)) as DcValue
from [YearDiffernce/365]
)


--; with YearDiff as 
--(
--select 
-- Id
-- ,FundId	   
--,ScenarioId	
--,InvestmentId	
--,InvesmentName 
--,InvestmentCashflowTypeId 
--,EventDate
--,Equity
--,IsSelectedInvestment
--,MinDate	
----, case when IsSelectedInvestment =0  then datediff(day,MinDate ,EventDate) / 365.2425 
----       else datediff(day,MinDate , @TargetDate)/ 365.2425 end  as  YearDiffernce 
--,cast ( datediff(day,MinDate ,EventDate) / 365.2425 as decimal(21,10))  as YearDiffernce 
--,   @TargetIRR1 as  TargetIRR 
----,cast (POWER(@TargetIRR,YearDiffernce) as float)
--from @EventCashFlow
--)
--, DcValue as 
--(
--select 
-- Id
-- ,FundId	   
--,ScenarioId	
--,InvestmentId	
--,InvesmentName 
--,InvestmentCashflowTypeId 
--,EventDate
--,Equity
--,IsSelectedInvestment
--,MinDate	
--, YearDiffernce 
--,  TargetIRR 
--,cast (POWER(TargetIRR,YearDiffernce) as decimal(18,2)) as DcValue
--from YearDiff
--)

, calcExitvalue as
(
select 
  Id
,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,   [YearDiffernce/365] 
,    TargetIRR 
, DCvalue
,  case when Equity =0 then 0.00 else cast (Equity / DCValue  as decimal(30,10)) end as CalDCValue
--, case when InvestmentCashflowTypeId in (1,2,4,6) then SUM(Equity) else 0 end as SumofInvesment 
from DCValue)

, Cumulative as
(
select 
  Id
,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,   [YearDiffernce/365] 
,    TargetIRR 
, DCvalue
,  CalDCValue

,sum(CalDCValue) OVER (ORDER BY Id) as Cumulative
--, case when InvestmentCashflowTypeId in (1,2,4,6) then SUM(Equity) else 0 end as SumofInvesment 
from calcExitvalue 
)
--select * from Cumulative

, CumulativeDivide as
(
select 
  Id
,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,   [YearDiffernce/365] 
,    TargetIRR 
, DCvalue
,  CalDCValue
, Cumulative
, case when cumulative < 0 then cast ( Equity / (Cumulative * -1) as decimal (30,10)) else 0.00 end as CumulativeDivide
--, case when InvestmentCashflowTypeId in (1,2,4,6) then SUM(Equity) else 0 end as SumofInvesment 
from Cumulative 
)

--select * from CumulativeDivide




, logValue as
(
select 
  Id
,FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,   [YearDiffernce/365] 
,    TargetIRR 
, DCvalue
,  CalDCValue
, Cumulative
,CumulativeDivide
--,case when Cumulative >= 0 then 0.00 else cast (  ( log (Equity / (Cumulative * -1)  ) /    (log ( @TargetIRR1 ) ) ) as decimal(18,2) ) end as CalcExitDateValue
, case when CumulativeDivide = 0.00 then Null else cast ( log(CumulativeDivide) / log ( @TargetIRR1 ) as decimal (30,10) ) End as CalcExitDateValue
from CumulativeDivide where EventDate is null
)

--select * from logValue



select @CalcExitDateValue  = ( select cast ( CalcExitdateValue * 365 as  decimal (30,10) ) from logValue )


  set @FinalExitDate = ( select  dateadd ( day , @CalcExitDateValue , @MindateAdd ) )

  declare @FinalExitDateCheck date = ( select case when @MindateAdd >= @FinalExitDate then null else  @FinalExitDate end )
  --declare @FinalExitDateCheck date = ( select   @FinalExitDate  )


 if @FinalExitDateCheck is null
--IF @MindateAdd > @FinalExitDateCheck
 begin
 insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType]
( 
FundId
,ScenarioId
,InvestmentId
,IRR
,ExitDate
,Exitvalue
,CreatedBy
,CreatedOn
,CalcIRR
)

select    
 @FundId        
,@ScenarioId    
,@InvestmentId
,@TargetIRR
,@FinalExitDateCheck
,@TargetExitValue
,@UserAlias 
,getdate()
,0.00
 end
 else 
 begin

  insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType]
( 
FundId
,ScenarioId
,InvestmentId
,IRR
,ExitDate
,Exitvalue
,CreatedBy
,CreatedOn

)

select    
 @FundId        
,@ScenarioId    
,@InvestmentId
,@TargetIRR
,@FinalExitDateCheck
,@TargetExitValue
,@UserAlias 
,getdate()


end


---------------------Girr---------------------------------------------------------------

--insert into @cashflowdetails
--(
-- FundID 
--,ScenarioId 
--,InvestmentId 
--, InvestmentCashFlowTypeId 
--,EventDate 
--,Equity 

--)
--select 
-- @FundId	   
--,@ScenarioId	
--,@InvestmentId	
--,3 
--,@FinalExitDateCheck
--,@TargetExitValue


----select * from @cashflowdetails
--DECLARE @SnapshotDate Datetime = GETDATE()  

--DECLARE @resultcount INT
--DECLARE @Test [OPGC].[GIRRTableTEST] -- [OPGC].[GIRRTable]

--INSERT  @Test
--SELECT  Equity , EventDate FROM @cashflowdetails

--  SET XACT_ABORT ON; 
--        BEGIN TRY
--        BEGIN TRANSACTION;
--INSERT INTO OPGC.OPGCResultGIRR
-- SELECT @fundid ,@ScenarioId, 0, 
--        case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 
--		     Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
--        @SnapshotDate  

-- COMMIT TRANSACTION ;  
--END TRY

--BEGIN CATCH 

--IF @@trancount > 0 ROLLBACK TRANSACTION

--END CATCH ;


--SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @ScenarioId  and SnapshotDate = @SnapshotDate and InvestmentID =0)

--IF @resultcount = 0
--BEGIN 
--INSERT INTO OPGC.OPGCResultGIRR
--SELECT @fundid,@ScenarioId, 0,0.0 AS GIRR, @SnapshotDate
--END

--DELETE FROM @Test
--declare @TotalGIRR decimal(21,10) = ( select GIRR  FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate  )
--declare  @TotalGIRRNull decimal(21,10) = ( select Isnull( @TotalGIRR , 0.00) )

--if @TotalGIRRNull = 0.00 or @TotalGIRR = 0.00
--begin
--insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType]
--( 
--FundId
--,ScenarioId
--,InvestmentId
--,IRR
--,ExitDate
--,Exitvalue
--,CreatedBy
--,CreatedOn
--,CalcIRR
--)

--select    
-- @FundId        
--,@ScenarioId    
--,@InvestmentId
--,@TargetIRR
--,@FinalExitDateCheck
--,@TargetExitValue
--,@UserAlias 
--,getdate()
--,@TotalGIRRNull
--end

--declare @DiffernceIRR decimal(6,2) = (select @TargetIRR - @TotalGIRR)
----Check Difference

--if @DiffernceIRR between -0.75 and 0.75
--begin
--insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType]
--( 
--FundId
--,ScenarioId
--,InvestmentId
--,IRR
--,ExitDate
--,Exitvalue
--,CreatedBy
--,CreatedOn
--)
--select    
-- @FundId        
--,@ScenarioId    
--,@InvestmentId
--,@TargetIRR
--,@FinalExitDateCheck  
--,@TargetExitValue
--,@UserAlias 
--,getdate()
--end

--else if @DiffernceIRR > 0.75

--begin
----Create cte

--DECLARE @cte AS table ([value] decimal (18,2), [Date] DATETIME, ID INT)

--INSERT INTO @cte
--select case when InvestmentCashflowTypeId in (1,2,4,6) then  - Equity  else Equity end as [value] , EventDate  as [Date]
--       , case when InvestmentCashflowTypeId in (1,2,4,6) then 1 else 2 End as ID
--from [OPGC].[OpgcInvestmentCashFlow]
--      where FundId = @FundId and ScenarioId = @ScenarioId  and InvestmentId in ( select Id from @InvesmentIdBase )
--       and Isdeleted = 0 

--WHILE( @TotalGIRR + 0.75) <= @TargetIRR
--BEGIN
----SET @Exitvallue = @Exitvallue * 1.025
--SET @FinalExitDateCheck  = dateadd(day,-5, @FinalExitDateCheck)

----SET @FinalExitDate = dateadd(month,-1, @FinalExitDate)

--DELETE FROM @Test

--INSERT INTO @Test
--SELECT [value], [Date] FROM @cte
--UNION
--SELECT @TargetExitValue, @FinalExitDateCheck FROM @cte

--SELECT @TotalGIRR = CAST(ROUND([OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) --AS GIRR, @SnapshotDate as SnapshotDate
----IF ABS(@target-@resulGirr) <= 0.75

--IF ABS(@TargetIRR-@TotalGIRR) <= 0.50
--BEGIN
--Print '(@TargetIRR-@TotalGIRR)'
--INSERT INTO OPGC.TargetGIRRcalculation
--SELECT  @TargetExitValue,@snapshotDate,@TotalGIRR,@TargetIRR,@FinalExitDateCheck
--END
--END
--DECLARE @searchvalue Decimal (18,2) = (SELECT MIN(ABS(CalulatedGIRR-TagetGIRR)) FROM OPGC.TargetGIRRcalculation WHERE Snapshotdate = @snapshotDate)
--select @FinalExitDateCheck = (SELECT top 1 TargetDate FROM OPGC.TargetGIRRcalculation  WHERE Snapshotdate = @snapshotDate and ABS(CalulatedGIRR-TagetGIRR) = @searchvalue )

----select @FinalExitDateCheck

----------------Inserting Goal Seek table ----------------------------------------------------

--insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
--(  
--FundId
--,ScenarioId
--,InvestmentId
--,IRR
--,ExitDate
--,Exitvalue 
--,CreatedBy
--,CreatedOn
--)
--select     
-- @FundId         
--,@ScenarioId     
--,@InvestmentId
--,@TargetIRR
--,@FinalExitDateCheck  
--,@TargetExitValue
--,@UserAlias  
--,getdate()
--End

--else if @DiffernceIRR <= -0.75
--begin
----Create cte

--DECLARE @cteLessThan AS table ([value] decimal (18,2), [Date] DATETIME, ID INT)
--INSERT INTO @cteLessThan

--select case when InvestmentCashflowTypeId in (1,2,4,6) then  - Equity  else Equity end as [value] , EventDate  as [Date]
--       , case when InvestmentCashflowTypeId in (1,2,4,6) then 1 else 2 End as ID
--from [OPGC].[OpgcInvestmentCashFlow]
-- where FundId = @FundId and ScenarioId = @ScenarioId  and InvestmentId in ( select Id from @InvesmentIdBase )
--       and Isdeleted = 0



--WHILe( @TotalGIRR - 0.75) >= @TargetIRR
--BEGIN 

--SET @FinalExitDateCheck  = dateadd(day,5, @FinalExitDateCheck)
----select @FinalExitDate
----select @TotalGIRR as WhileTotalGirr

--DELETE FROM @Test

--INSERT INTO @Test
--SELECT [value], [Date] FROM @cteLessThan
--UNION
--SELECT @TargetExitValue, @FinalExitDateCheck 

--set @TotalGIRR = CAST(ROUND([OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) --AS GIRR, @SnapshotDate as SnapshotDate

----select @TotalGIRR as FinalDate
----select @FinalExitDateCheck as FinalDate


----IF ABS(@target-@resulGirr) <= 0.75
--IF ABS(@TargetIRR-@TotalGIRR) <= 0.50

--BEGIN

--INSERT INTO OPGC.TargetGIRRcalculation
--SELECT  @TargetExitValue,@snapshotDate,@TotalGIRR,@TargetIRR,@FinalExitDateCheck


--END
--END

--DECLARE @searchvalueLess Decimal (18,2) = (SELECT MIN(ABS(CalulatedGIRR-TagetGIRR)) FROM OPGC.TargetGIRRcalculation WHERE Snapshotdate = @snapshotDate)
--select @FinalExitDateCheck = (SELECT top 1 TargetDate FROM OPGC.TargetGIRRcalculation  WHERE Snapshotdate = @snapshotDate and ABS(CalulatedGIRR-TagetGIRR) = @searchvalueLess )

----select @FinalExitDateCheck as FinalDate
----------------Inserting Goal Seek table ----------------------------------------------------

--insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
--(  
--FundId
--,ScenarioId
--,InvestmentId
--,IRR
--,ExitDate
--,Exitvalue 
--,CreatedBy
--,CreatedOn
--)
--select     
-- @FundId         
--,@ScenarioId     
--,@InvestmentId
--,@TargetIRR
--,@FinalExitDateCheck  
--,@TargetExitValue
--,@UserAlias  
--,getdate()


--End





----------------------------------------------------------------------------------------------------

set @GSInvestmentId = ( select top 1 GsInvestmentId from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentID order by 1 desc )

--delete from OPGC.TargetGIRRcalculation  where Snapshotdate = @snapshotDate

--delete  FROM OPGC.OPGCResultGIRR where Snapshotdate = @snapshotDate



END TRY  
BEGIN CATCH  
 DECLARE @ErrorNumber INT  
 DECLARE @Severity  INT  
 DECLARE @State   INT   
 DECLARE @Procedure  NVARCHAR(250)  
 DECLARE @LineNumber  INT  
 DECLARE @Message  NVARCHAR(MAX)  
 DECLARE @Originator NVARCHAR(250)   
 SELECT   
  @ErrorNumber = ERROR_NUMBER(),  
  @Severity = ERROR_SEVERITY(),  
  @State = ERROR_STATE(),   
  @Procedure = ERROR_PROCEDURE(),  
  @LineNumber = ERROR_LINE(),   
  @Message = ERROR_MESSAGE()     
 EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message,   
       'Database', null, null,null                
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END  
END CATCH
END

