SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [dbo].[USP_Select_Forecast_PerformanceCardDetails]  --'',171,171,56
(
	  @userAlias NVARCHAR(50)	  
	 ,@baseLineScenarioId INT
	 ,@NonBaseLineScenarioId NVARCHAR(10)
	 ,@FundId INT
	
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Appointment Details

Uses   
      [USP_Select_Appointment_GetAppointmentDetails]	    SP

Populates
      [WWMG].[ConfirmedScheduleDetails]			Table
	  [WWMG].[LocationDetails]					Table
	  [WWMG].[UserFamilyDetails]				Table
	  [WWMG].[FamilyDetails_Relations]			Table
**************************************************************************/
BEGIN TRY

SET @NonBaseLineScenarioId = CASE WHEN @NonBaseLineScenarioId IS NULL OR @NonBaseLineScenarioId=0 THEN 0 ELSE @NonBaseLineScenarioId END

DECLARE @GrossMOIC_Current DECIMAL(30,2) 
DECLARE @GrossMOIC_Selected DECIMAL(30,2)
--DECLARE @NetMOIC_Current DECIMAL(30,2)
--DECLARE @NetMOIC_Selected DECIMAL(30,2)
DECLARE @TotalFeesSelected DECIMAL(30,2)


--GROSS MOIC Current  

----------------new cr ------------------------------------------------------

declare @MoicCurrent as table ( MOIC decimal (30,2))
;with InvestmentId as  
(  
select FundId , ScenarioId , InvestmentId  , sum(Equity) as InitialInvestment --, 0 as ExitValue    
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @FundId and ScenarioId = @baseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, ExitId AS
(
  
  select FundId , ScenarioId  ,InvestmentId,-- 0 as IntialInvestment ,
  sum(Equity) as ExitValue     
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and FundId = @FundId and ScenarioId = @baseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId   , InvestmentId
  )  

, InvesmentExit as
(   select A.FundId , A.ScenarioId  ,A.InvestmentId , A.InitialInvestment , B.ExitValue

     from InvestmentId A
	 join ExitId B
	 On A.FundId = B.FundId and A.InvestmentId = B.InvestmentId

)


--select * from InvesmentExit
, TotalInvestmentExit as 
(

select FundId , ScenarioId  , SUM( InitialInvestment ) as Initial , Sum(ExitValue) as ExitValue
     from InvesmentExit
	 group by FundId , ScenarioId
)

--select * from TotalInvestmentExit

, MOIC as 

(

select  cast ( ( ExitValue / Initial ) as decimal (30,2)) as MOIC
     from TotalInvestmentExit
)

Insert into  @MoicCurrent
select * from MOIC

--select * from @moic

set @GrossMOIC_Current = ( select * from @MoicCurrent )







--------------------------------------------MOIC Old concept---------------------------------------------------------------------------------------------------------------------------

--DECLARE @ExitValuationCurrent DECIMAL(18,2) = (SELECT SUM (Equity) from [OPGC].[OpgcInvestmentCashFlow] A JOIN [OPGC].[OpgcScenario] B 
--										   ON A.ScenarioId=B.ScenarioId AND A.FundId=B.FundID WHERE A.FundId=@FundId AND A.ScenarioId=@baseLineScenarioId  AND
--										   A.InvestmentCashflowTypeId in (3,5,7) --AND B.IsBaseline=1 
--										   and A.Isdeleted=0)

--DECLARE @IntialandFollowupCurrent DECIMAL(18,2) =(SELECT SUM (Equity) from [OPGC].[OpgcInvestmentCashFlow] A JOIN [OPGC].[OpgcScenario] B 
--										   ON A.ScenarioId=B.ScenarioId AND A.FundId=B.FundID WHERE A.FundId=@FundId AND A.ScenarioId=@baseLineScenarioId AND
--										   A.InvestmentCashflowTypeId IN (1,2,4,6) --AND B.IsBaseline=1 
--										   and A.Isdeleted=0)

--IF (ISNULL(@ExitValuationCurrent,0) = 0 OR ISNULL(@IntialandFollowupCurrent,0)=0) 
--begin

--set @GrossMOIC_Current=0

--end

--else
--begin

--SET @GrossMOIC_Current = (@ExitValuationCurrent/@IntialandFollowupCurrenT) 

--end
-----------------------------------------------------------------




--GROSS MOIC Selected 

--------------------- new cr ----------------------------------------------------------------------

declare @MoicSelect as table ( MOIC decimal (30,2))
;with InvestmentIdSelect as  
(  
select FundId , ScenarioId , InvestmentId  , sum(Equity) as InitialInvestment --, 0 as ExitValue    
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @FundId and ScenarioId = @NonBaseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, ExitIdSelect AS
(
  
  select FundId , ScenarioId  ,InvestmentId,-- 0 as IntialInvestment ,
  sum(Equity) as ExitValue     
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and FundId = @FundId and ScenarioId = @NonBaseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId   , InvestmentId
  )  

, InvesmentExitSelect as
(   select A.FundId , A.ScenarioId  ,A.InvestmentId , A.InitialInvestment , B.ExitValue

     from InvestmentIdSelect A
	 join ExitIdSelect B
	 On A.FundId = B.FundId and A.InvestmentId = B.InvestmentId

)


--select * from InvesmentExit
, TotalInvestmentExitSelect as 
(

select FundId , ScenarioId  , SUM( InitialInvestment ) as Initial , Sum(ExitValue) as ExitValue
     from InvesmentExitSelect
	 group by FundId , ScenarioId
)

--select * from TotalInvestmentExit

, MOICSelect as 

(

select  cast ( ( ExitValue / Initial ) as decimal (30,2)) as MOIC
     from TotalInvestmentExitSelect
)

Insert into  @MoicSelect
select * from MOICSelect

--select * from @moic

set @GrossMOIC_Selected = ( select * from @MoicSelect )








----------------------------------------------------------MOIC OLd concept--------------------------------------------------------------------------------------------------------
--DECLARE @ExitValuationSelected DECIMAL(18,2) = (SELECT SUM (Equity) from [OPGC].[OpgcInvestmentCashFlow] A JOIN [OPGC].[OpgcScenario] B 
--										   ON A.ScenarioId=B.ScenarioId AND A.FundId=B.FundID WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId  AND
--										   A.InvestmentCashflowTypeId in (3,5,7) --AND B.IsBaseline=0 
--										   and A.Isdeleted=0)

--DECLARE @IntialandFollowupSelected DECIMAL(18,2) =(SELECT SUM (Equity) from [OPGC].[OpgcInvestmentCashFlow] A JOIN [OPGC].[OpgcScenario] B 
--										   ON A.ScenarioId=B.ScenarioId AND A.FundId=B.FundID WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId AND
--										   A.InvestmentCashflowTypeId IN (1,2,4,6) --AND B.IsBaseline=0 
--										   and A.Isdeleted=0)




--IF (ISNULL(@ExitValuationSelected,0) = 0 OR ISNULL(@IntialandFollowupSelected,0)=0) 
--begin

--set @GrossMOIC_Selected=0

--end

--ELSE 

--BEGIN

--set @GrossMOIC_Selected= (@ExitValuationSelected/@IntialandFollowupSelected) 

--END


-------------------------------------------NET OLD MOIC concet---------------25-04-22----------------------------------

--NET MOIC Current

--DECLARE @NetMOICCurrentContribution DECIMAL(30,2) = (SELECT SUM (ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
--										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
--										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
--										WHERE A.FundId=@FundId AND A.ScenarioId=@baseLineScenarioId --AND C.IsBaseline=1
--										AND B.FundCashFlowTypeId=1 and A.Isdeleted=0)


--DECLARE @NetMOICCurrentDistrubution DECIMAL(30,2) = (SELECT SUM(ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
--										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
--										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
--										WHERE A.FundId=@FundId AND A.ScenarioId=@baseLineScenarioId -- AND C.IsBaseline=1
--										and B.FundCashFlowTypeId=2 and A.Isdeleted=0)

--IF (ISNULL(@NetMOICCurrentContribution,0) = 0 OR ISNULL(@NetMOICCurrentDistrubution,0)=0) 
--begin

--set @NetMOIC_Current=0

--end

--ELSE 

--BEGIN

--set @NetMOIC_Current= (@NetMOICCurrentDistrubution/@NetMOICCurrentContribution) 

--END

--------------Net Moic current -------------------------

--DECLARE @NetMOICCurrentContribution DECIMAL(30,2) = (SELECT abs (SUM (NetLPContribution)) FROM @CurrentFinalLPCostReturn  
--										              WHERE InvesmentCashFlowTypeId in (1,2,4,6) or CashFlowTypeId in (6,7) or TypeId in (10,11)  )

--DECLARE @NetMOICCurrentDistrubution DECIMAL(30,2) = (SELECT abs (SUM (NetLPContribution)) FROM @CurrentFinalLPCostReturn  
--										              WHERE InvesmentCashFlowTypeId in (3,5,7,8) or CashFlowTypeId in (8,9)   )


--IF (ISNULL(@NetMOICCurrentContribution,0) = 0 OR ISNULL(@NetMOICCurrentDistrubution,0)=0) 
--begin

--set @NetMOIC_Current=0

--end

--ELSE 

--BEGIN

--set @NetMOIC_Current= (@NetMOICCurrentDistrubution/@NetMOICCurrentContribution) 

--END


-------------------------------------------------------------------------------------------------------------------------------------

--NET MOIC Selected
--DECLARE @NetMOICSelectedContribution DECIMAL(30,2) = (SELECT SUM (ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
--										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
--										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
--										WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId --AND C.IsBaseline=0 
--										AND B.FundCashFlowTypeId=1 and A.Isdeleted=0)


--DECLARE @NetMOICSelectedDistrubution DECIMAL(30,2) = (SELECT SUM(ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
--										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
--										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
--										WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId  --AND C.IsBaseline=0 
--										and B.FundCashFlowTypeId=2 and A.Isdeleted=0)

--IF (ISNULL(@NetMOICSelectedContribution,0) = 0 OR ISNULL(@NetMOICSelectedDistrubution,0)=0) 
--begin

--set @NetMOIC_Selected=0

--end

--ELSE 

--BEGIN

--set @NetMOIC_Selected= (@NetMOICSelectedDistrubution/@NetMOICSelectedContribution) 

--END

-------------NET MOIC Selected

--DECLARE @NetMOICSelectedContribution DECIMAL(30,2) = (SELECT abs (SUM (NetLPContribution)) FROM @SelectedFinalLPCostReturn  
--										              WHERE InvesmentCashFlowTypeId in (1,2,4,6) or CashFlowTypeId in (6,7) or TypeId in (10,11)  )

--DECLARE @NetMOICSelectedDistrubution DECIMAL(30,2) = (SELECT abs(SUM (NetLPContribution)) FROM @SelectedFinalLPCostReturn  
--										              WHERE InvesmentCashFlowTypeId in (3,5,7,8) or CashFlowTypeId in (8,9)   )


--IF (ISNULL(@NetMOICSelectedContribution,0) = 0 OR ISNULL(@NetMOICSelectedDistrubution,0)=0) 
--begin

--set @NetMOIC_Selected=0

--end

--ELSE 

--BEGIN

--set @NetMOIC_Selected= (@NetMOICSelectedDistrubution/@NetMOICSelectedContribution) 

--END

------------------------------------------------------------------------------------------------











DECLARE @CurrentDate DATETIME = GETDATE()
DECLARE @TTMDate DATETIME = DATEADD (MM,-12,@CurrentDate)

--Expense Current

DECLARE @TotalExpenseCurrent DECIMAL(30,2)=(SELECT SUM (ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
										WHERE A.FundId=@FundId AND A.ScenarioId=@baseLineScenarioId-- AND C.IsBaseline=1 
										and B.FundCashFlowTypeId in (3,5)
										AND A.EventDate BETWEEN CAST (@TTMDate AS DATE) AND CAST (@CurrentDate AS DATE) and A.Isdeleted=0)

DECLARE @TotalExpenseSelected DECIMAL(30,2)


IF coalesce(@NonBaseLineScenarioId,'') =''
begin
set @TotalExpenseSelected = 0
end
else
begin
set @TotalExpenseSelected = (SELECT SUM (ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
							 ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
							 JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
							 WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId --AND C.IsBaseline=0 
							 and B.FundCashFlowTypeId in (3,5)
							 AND A.EventDate BETWEEN CAST (@TTMDate AS DATE) AND CAST (@CurrentDate AS DATE) and A.Isdeleted=0)

end
---------------------------------------------------------------------------------------------

--Fees Current
DECLARE @TotalFeesCurrent DECIMAL(30,2)=(SELECT SUM (ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
										ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
										JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
										WHERE A.FundId=@FundId AND A.ScenarioId=@baseLineScenarioId --AND C.IsBaseline=1
										and B.FundCashFlowTypeId=4 AND
										A.EventDate BETWEEN CAST (@TTMDate AS DATE) AND CAST (@CurrentDate AS DATE)and A.Isdeleted=0)


IF coalesce(@NonBaseLineScenarioId,'') =''
begin
set @TotalFeesSelected = 0
end
else
begin
set @TotalFeesSelected = (SELECT SUM (ValueAmount) FROM [OPGC].[OpgcFundCashFlow] A JOIN [OPGC].[OpgcFundCashFlowType] B 
							 ON A.FundCashflowTypeId=B.FundCashFlowTypeId 
							 JOIN [OPGC].[OpgcScenario] C ON A.ScenarioId=C.ScenarioId 
							 WHERE A.FundId=@FundId AND A.ScenarioId=@NonBaseLineScenarioId --AND C.IsBaseline=0 
							 and B.FundCashFlowTypeId=4
							 AND A.EventDate BETWEEN CAST (@TTMDate AS DATE) AND CAST (@CurrentDate AS DATE) and A.Isdeleted=0)

end

----------------------------------GIRR---------------------------------

-----------------------------New CR for Baseline----------------------------------------------------------------------------------------
declare @InvesmentIdBase as table ( Id int)



;with investmentBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @fundid and ScenarioId = @baseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and 
  FundId = @fundid and ScenarioId = @baseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdBase
select A.InvestmentId from investmentBaseInitial A
join investmentBaseExit B
on A.InvestmentId =B.InvestmentId
-------------------------------------------New CR for Non baseline----------------------------------------------------------------------------------------

declare @InvesmentIdNonBase as table ( Id int)



;with investmentNonBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @fundid and ScenarioId = @NonBaseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentNonBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and 
  FundId = @fundid and ScenarioId = @NonBaseLineScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdNonBase
select A.InvestmentId from investmentNonBaseInitial A
join investmentNonBaseExit B
on A.InvestmentId =B.InvestmentId


----------------------------------------------------------------------------------------------------------------------------------

DECLARE @investmentCashflow as table (
 FundID int
,ScenarioID Int
,InvestmentCashFlowtypeID int
,InvestmentID INT
,Equity Decimal (30,2)
,Eventdate DateTime
,IsBaseline Int
,Isinvestment int
)


DECLARE @resultcount INT

INSERT INTO @investmentCashflow
--Values (@FundID,@baseLineScenarioId,1,1,10000,'2018-12-01 07:10:20.833',1),
--	   (@FundID,@baseLineScenarioId,1,2,6000,'2019-12-01 07:10:20.833',1),
--	   (@FundID,@baseLineScenarioId,1,3,25000,'2023-12-01 07:10:20.833',1),
--	   (@FundID,@NonBaseLineScenarioId,2,1,10000,'2018-10-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,2,2,5000,'2019-10-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,2,3,27000,'2023-10-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,3,1,8000,'2018-11-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,3,2,4000,'2019-11-01 07:10:20.833',0),
--	   (@FundID,@NonBaseLineScenarioId,3,3,22000,'2023-11-01 07:10:20.833',0)

SELECT o.FundId,o.ScenarioId, O.InvestmentCashflowTypeId, 0 as investmentID,Sum(Equity) Equity, Cast(EventDate as Date) EventDate,1 as IsBaseline,1 as Isinvestment  FROM opgc.OpgcInvestmentCashFlow o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1
WHERE O.InvestmentCashflowTypeId in (1,2,4,6) and o. FundId = @FundId and o.ScenarioId = @baseLineScenarioId and o.InvestmentId in ( select Id from @InvesmentIdBase) and o.Isdeleted=0
GROUP BY o.FundId,o.ScenarioId, O.InvestmentCashflowTypeId, o.InvestmentId,  Cast(EventDate as Date) 
UNION ALL 
SELECT o.FundId,o.ScenarioId, O.InvestmentCashflowTypeId, 0 as investmentID, Sum(Equity) Equity, Cast(EventDate as Date) EventDate,1 as IsBaseline ,1 as Isinvestment FROM opgc.OpgcInvestmentCashFlow o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1
WHERE O.InvestmentCashflowTypeId in (3,5,7,8) and o. FundId = @FundId and o.ScenarioId = @baseLineScenarioId and o.InvestmentId in ( select Id from @InvesmentIdBase) and o.Isdeleted=0
GROUP BY o.FundId,o.ScenarioId, O.InvestmentCashflowTypeId,  o.InvestmentId, Cast(EventDate as Date) 
-----------------------------------------------------------------------------------------------------------------
UNION ALL
SELECT o.FundId,o.ScenarioId, O.InvestmentCashflowTypeId, 1 as investmentID,Sum(Equity) Equity, Cast(EventDate as Date) EventDate,1 as IsBaseline,1 as Isinvestment  FROM opgc.OpgcInvestmentCashFlow o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 0
WHERE O.InvestmentCashflowTypeId in (1,2,4,6) and o. FundId = @FundId and o.ScenarioId = @NonBaseLineScenarioId and o.InvestmentId in ( select Id from @InvesmentIdNonBase) and o.Isdeleted=0
GROUP BY o.FundId,o.ScenarioId, O.InvestmentCashflowTypeId, o.InvestmentId,  Cast(EventDate as Date) 
UNION ALL 
SELECT o.FundId,o.ScenarioId, O.InvestmentCashflowTypeId, 1 as investmentID, Sum(Equity) Equity, Cast(EventDate as Date) EventDate,1 as IsBaseline ,1 as Isinvestment FROM opgc.OpgcInvestmentCashFlow o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId-- and S.IsBaseline = 0
WHERE O.InvestmentCashflowTypeId in (3,5,7,8) and o. FundId = @FundId and o.ScenarioId = @NonBaseLineScenarioId and o.InvestmentId in ( select Id from @InvesmentIdNonBase) and o.Isdeleted=0
GROUP BY o.FundId,o.ScenarioId, O.InvestmentCashflowTypeId,  o.InvestmentId, Cast(EventDate as Date) 
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--UNION ALL
--SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 2 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
--		,Max(CAST(isbaseline AS INT)) isbaseline, 0 as IsInvestment
--FROM [OPGC].[OpgcFundCashFlow] o
--INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1 
--WHERE O.FundCashflowTypeId in (1) and o.ScenarioId = @baseLineScenarioId and o.Isdeleted=0
--GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)
--UNION ALL
--SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 2 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
--		,Max(CAST(isbaseline AS INT)) isbaseline, 0 as IsInvestment
--FROM [OPGC].[OpgcFundCashFlow] o
--INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1
--WHERE O.FundCashflowTypeId in (2) and o.ScenarioId = @baseLineScenarioId and o.Isdeleted=0
--GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--UNION ALL
--SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 3 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
--		,Max(CAST(isbaseline AS INT)) isbaseline, 0 as IsInvestment
--FROM [OPGC].[OpgcFundCashFlow] o
--INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 0
--WHERE O.FundCashflowTypeId in (1) and o.ScenarioId = @NonBaseLineScenarioId and o.Isdeleted=0
--GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)
--UNION ALL
--SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 3 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
--		,Max(CAST(isbaseline AS INT)) isbaseline, 0 as IsInvestment
--FROM [OPGC].[OpgcFundCashFlow] o
--INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 0
--WHERE O.FundCashflowTypeId in (2) and o.ScenarioId = @NonBaseLineScenarioId and o.Isdeleted=0
--GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)
------------------------------------------------------------------------------------------------------------------------------------------------------------------

--UNION ALL
--SELECT FundId,ScenarioId,CashflowTypeId as InvestmentCashflowTypeId, 2 as investmentID , NetLPContribution as  Equity, EventDate
--		,0 isbaseline, 0 as IsInvestment
--FROM @CurrentFinalLPCostReturn

--UNION ALL
--SELECT FundId,ScenarioId,CashflowTypeId as InvestmentCashflowTypeId, 3 as investmentID , NetLPContribution as  Equity, EventDate
--		,0 isbaseline, 0 as IsInvestment
--FROM @SelectedFinalLPCostReturn




DECLARE @Test [OPGC].[GIRRTable] -- [OPGC].[GIRRTableTEST]
DECLARE @snapshotdatecurrentGIRR Datetime = GEtdate ();

;with Currentscenariodata as (
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, -SUM(Equity) Equity FROM @investmentCashflow
WHERE InvestmentCashFlowtypeID in (1,2,4,6) and Isinvestment = 1 and  InvestmentID = 0
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
UNION ALL
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @investmentCashflow
WHERE  InvestmentCashFlowtypeID in (3,5,7,8) and Isinvestment = 1 and InvestmentID = 0
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
)
INSERT  @Test
SELECT Equity , EventDate FROM Currentscenariodata
WHERE FundID = @fundid and ScenarioId = @baseLineScenarioId



  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @fundid ,@baseLineScenarioId, 0, 
        --case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
        cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
		@snapshotdatecurrentGIRR  




 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;



SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @baseLineScenarioId  and SnapshotDate = @snapshotdatecurrentGIRR and InvestmentID =0)

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@baseLineScenarioId, 0,0.0 AS GIRR, @snapshotdatecurrentGIRR
END

DELETE FROM @Test

-------------------------------------------------------------------------------------------------------------------------------------------------------------------
;with Selectedscenariodata as (
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, -SUM(Equity) Equity FROM @investmentCashflow
WHERE  InvestmentCashFlowtypeID in (1,2,4,6) and Isinvestment = 1 and InvestmentID = 1
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
UNION ALL
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @investmentCashflow
WHERE  InvestmentCashFlowtypeID in (3,5,7,8) and Isinvestment = 1 and InvestmentID = 1
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
)


INSERT  @Test
SELECT  Equity , EventDate FROM Selectedscenariodata
WHERE FundID = @fundid and ScenarioId = @NonBaseLineScenarioId

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @fundid ,@NonBaseLineScenarioId, 1, 
        -- case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
       cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
		 @snapshotdatecurrentGIRR  


 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;

SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @NonBaseLineScenarioId  and SnapshotDate = @snapshotdatecurrentGIRR and InvestmentID = 1)

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@NonBaseLineScenarioId, 1,0.0 AS GIRR, @snapshotdatecurrentGIRR
END

DELETE FROM @Test

--------- Perfomance issue created new SP for NET moic and Net IRR--------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
--;with CurrentscenariodataNet as (
----SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate,  Equity FROM @investmentCashflow
----WHERE InvestmentCashFlowtypeID in (1) and Isinvestment = 0
----GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
----UNION ALL
----SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @investmentCashflow
----WHERE  InvestmentCashFlowtypeID in (2) and Isinvestment = 0
----GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
--SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate,  Equity FROM @investmentCashflow
--WHERE InvestmentID = 2 and Isinvestment = 0

----GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
--)
--INSERT  @Test
--SELECT  Equity , EventDate FROM CurrentscenariodataNet
--WHERE FundID = @fundid and ScenarioId = @baseLineScenarioId

--  SET XACT_ABORT ON; 
--        BEGIN TRY
--        BEGIN TRANSACTION;
--INSERT INTO OPGC.OPGCResultGIRR
-- SELECT @fundid ,@baseLineScenarioId, 2, 
--        -- case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
--         cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
--		 @snapshotdatecurrentGIRR  


-- COMMIT TRANSACTION ;  
--END TRY

--BEGIN CATCH 


--IF @@trancount > 0 ROLLBACK TRANSACTION



--END CATCH ;

--SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @baseLineScenarioId  and SnapshotDate = @snapshotdatecurrentGIRR and InvestmentID = 2)

--IF @resultcount = 0
--BEGIN 
--INSERT INTO OPGC.OPGCResultGIRR
--SELECT @fundid,@baseLineScenarioId, 2,0.0 AS GIRR, @snapshotdatecurrentGIRR
--END

--DELETE FROM @Test

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--;with SelectedscenariodataNet as (
----SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, -SUM(Equity) Equity FROM @investmentCashflow
----WHERE  InvestmentCashFlowtypeID in (1) and Isinvestment = 0
----GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
----UNION ALL
----SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @investmentCashflow
----WHERE  InvestmentCashFlowtypeID in (2) and Isinvestment = 0
----GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )

--SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate,  Equity FROM @investmentCashflow
--WHERE InvestmentID = 3 and Isinvestment = 0
----GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
--)
--INSERT  @Test
--SELECT  Equity , EventDate FROM SelectedscenariodataNet
--WHERE FundID = @fundid and ScenarioId = @NonBaseLineScenarioId

--  SET XACT_ABORT ON; 
--        BEGIN TRY
--        BEGIN TRANSACTION;
--INSERT INTO OPGC.OPGCResultGIRR
-- SELECT @fundid ,@NonBaseLineScenarioId, 3, 
--       -- case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
--        cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
--		@snapshotdatecurrentGIRR  


-- COMMIT TRANSACTION ;  
--END TRY

--BEGIN CATCH 


--IF @@trancount > 0 ROLLBACK TRANSACTION



--END CATCH ;

--SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @NonBaseLineScenarioId  and SnapshotDate = @snapshotdatecurrentGIRR and InvestmentID = 3)

--IF @resultcount = 0
--BEGIN 
--INSERT INTO OPGC.OPGCResultGIRR
--SELECT @fundid,@NonBaseLineScenarioId, 3,0.0 AS GIRR, @snapshotdatecurrentGIRR
--END


----------------------------------------------------------------------------------------------------------------------
DECLARE @GrossIRR_Current DECIMAL(18,2),
		@GrossIRR_selected DECIMAL(18,2)
		--@NetIRR_Current DECIMAL(18,2),
		--@NetIRR_selected DECIMAL(18,2)



SELECT 
@GrossIRR_Current = (SELECT GIRR FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR AND InvestmentID = 0),
@GrossIRR_selected = (SELECT GIRR FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR AND InvestmentID = 1)
--@NetIRR_Current = (SELECT GIRR FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR AND InvestmentID = 2),
--@NetIRR_selected = (SELECT GIRR FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR AND InvestmentID = 3)
-------------------------------------------------------------------------



SELECT 
 ISNULL(@GrossMOIC_Current,0) AS GrossMOIC_Current
,ISNULL(@GrossMOIC_Selected,0) AS GrossMOIC_Selected
--,ISNULL(@NetMOIC_Current,0) AS  NetMOIC_Current
--,ISNULL(@NetMOIC_Selected,0) AS NetMOIC_Selected
,ISNULL(@GrossIRR_Current,0) AS GrossIRR_Current
,ISNULL(@GrossIRR_selected,0) AS GrossIRR_Selected
--,ISNULL(@NetIRR_Current,0) AS  NetIRR_Current
--,ISNULL(@NetIRR_selected,0) AS NetIRR_Selected
,ISNULL(@TotalExpenseCurrent,0) AS TotalExpense_Current
,ISNULL(@TotalExpenseSelected,0) AS TotalExpense_Selected
,ISNULL(@TotalFeesCurrent,0) AS TotalFees_Current
,ISNULL(@TotalFeesSelected,0) AS TotalFees_Selected


--insert into [OPGC].[OPGCResultGIRR_History] ( FundId , ScenarioId , InvestmentID , GIRR, SnapshotDate , Modifiedon ,  ModifiedBy , InvestmentName)
--select  A.FundId , A.ScenarioId , A.InvestmentID , A.GIRR, A.SnapshotDate , GETDATE() , 'Perfomance card detauls' ,B.InvestmentName
--from OPGC.OPGCResultGIRR A
--Left Join [OPGC].[OpgcInvestment] B
--on A.InvestmentID = B.InvestmentId and B.Isdeleted = 0

DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR



END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


