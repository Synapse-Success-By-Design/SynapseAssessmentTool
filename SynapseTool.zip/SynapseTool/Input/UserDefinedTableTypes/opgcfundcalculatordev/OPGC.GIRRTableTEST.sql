CREATE TYPE [OPGC].[GIRRTableTEST] AS TABLE(
	[Value] [decimal](38, 9) NULL,
	[Date] [datetime] NOT NULL
)
