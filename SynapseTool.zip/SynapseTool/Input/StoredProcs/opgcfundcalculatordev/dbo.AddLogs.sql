SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE proc [dbo].[AddLogs](@ServiceName nvarchar(max),@Msg  nvarchar(max))
as
begin

insert into [dbo].[AddLogs](ServiceName,Msg)values(@ServiceName,@Msg)

end
