SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [OPGC].[USP_Select_GoalSeek_Investment_CalculateIRR] --'',1
(  

@UserAlias      nvarchar(250),
@GSInvestmentId int
)

as

Begin

BEGIN TRY

select 
  A.GsInvestmentId
 ,A.FundId 
 ,C.[FundName​] as FundName
, A.ScenarioId
, D.ScenarioName
, A.InvestmentId
, B.InvestmentName
, A.ExitDate
, A.Exitvalue
, A.IRR
, A.CalcIRR

from [OPGC].[OpgcGoalSeekInvestmentcashflowType] A
join [OPGC].[OpgcInvestment] B
on A.InvestmentId = B.InvestmentId
join [OPGC].[OpgcFund] C
on A.FundId = C.FundId
join [OPGC].[OpgcScenario] D
on A.ScenarioId =D.ScenarioId

where GsInvestmentId = @GSInvestmentId

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END
