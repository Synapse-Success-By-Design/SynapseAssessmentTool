SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

--http://localhost:4200/api/Fund/GetFundMOICComparision?FundId=2&ScenarioId=1534&UserAlias=admin&IndustryId=&CountryId=&ActiveScenarioId=1555

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_FundPerformance_GrossMOICComparision] --'',1,1,null,null,1
(
	 @userAlias NVARCHAR(100)
    ,@FundId  INT
    ,@ScenarioId INT
    ,@IndustryId INT = NULL,
     @CountryId  INT = NULL
	,@ActiveScenarioId int 
 
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Appointment Details


Uses   
      [USP_Select_Appointment_GetAppointmentDetails]	    SP

Populates
      [WWMG].[ConfirmedScheduleDetails]			Table
	  [WWMG].[LocationDetails]					Table
	  [WWMG].[UserFamilyDetails]				Table
	  [WWMG].[FamilyDetails_Relations]			Table
**************************************************************************/
BEGIN TRY

DECLARE @BaseLineScenarioID INT --= (SELECT ScenarioId FROM [OPGC].[OpgcScenario] WHERE FundID =@FundId AND IsBaseline=1  and Isdeleted = 0)
set @BaseLineScenarioID = @ActiveScenarioId

declare @ScenarioIDchecktable as table (id int)

----------------------------------------------------------------------------------------------------------------------------------------

;with BaseLineScenarioCheck as
(
  SELECT distinct FundId , ScenarioId , InvestmentId FROM  [OPGC].[OpgcInvestmentCashFlow] 
 where  ScenarioId = @BaseLineScenarioID and FundId = @FundId and Isdeleted = 0
 
 )
, CurrentScenarioCheck as
(
 SELECT distinct FundId , ScenarioId , InvestmentId FROM  [OPGC].[OpgcInvestmentCashFlow]
 where  ScenarioId = @ScenarioId and FundId = @FundId and Isdeleted = 0
 )


insert into @ScenarioIDchecktable
select count(1) as ID
from BaseLineScenarioCheck A
inner join CurrentScenarioCheck B
on A.InvestmentId = B.InvestmentId

------------------------------------------------------------------------------------------------------------------------------

Declare @ScenarioIDcheck int = (Select * from @ScenarioIDchecktable )


If coalesce ( @ScenarioId,'') = '' or @ScenarioIDcheck = 0
begin

;with Investment as ( select FundId , ScenarioId , InvestmentId ,   sum(Equity) as Equity, 0 as ExitValue     
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
  group by FundId , ScenarioId , InvestmentId 
  union all 
  select FundId , ScenarioId , InvestmentId    , 0 as Equity, sum(Equity) as ExitValue   
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
  group by FundId , ScenarioId , InvestmentId
  )
, ResultInsvesment as ( select FundId , ScenarioId , InvestmentId    , sum(Equity) as Equity , sum(ExitValue) as ExitValue 
 from Investment
 group by FundId , ScenarioId , InvestmentId
 )

 --select * from ResultInsvesment

, MOIC as ( select FundId , ScenarioId , InvestmentId , 
  case when Equity = 0 Then 0 
       when ExitVAlue = 0 Then 0 else  CAST(( ExitVAlue / Equity) AS decimal (18,2)) End as  ActiveMOIC
  --( ExitVAlue / Equity)  as  MOIC
 from ResultInsvesment
 Group By  FundId , ScenarioId , InvestmentId ,Equity , ExitValue 
 )

 --select * from FinalResult

 , ActiveMOIC as (
 select A.FundId , A.ScenarioId ,A.InvestmentId , B.InvestmentName ,
 CASE WHEN A.ActiveMOIC < 0 THEN -( A.ActiveMOIC ) ELSE  A.ActiveMOIC  END AS  ActiveMOIC  
 from MOIC A
 inner join [OPGC].[OpgcInvestment] B
 on  A.InvestmentId = B.InvestmentId

 )

   select A.FundId , A.InvestmentName , A.ScenarioId as BaselineScenarioId , cast (0 as int ) as CompareScenarioId ,
    CASE WHEN A.ActiveMOIC < 0 THEN -( A.ActiveMOIC ) ELSE  A.ActiveMOIC END as BaselineMOIC,
   cast (0 as decimal(18,2)) as CompareMOIC
   from ActiveMOIC A
  -- order by InvestmentName asc


end
else
begin

;with Investment as ( select FundId , ScenarioId , InvestmentId ,   sum(Equity) as Equity, 0 as ExitValue     
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
  group by FundId , ScenarioId , InvestmentId 
  union all 
  select FundId , ScenarioId , InvestmentId    , 0 as Equity, sum(Equity) as ExitValue   
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
  group by FundId , ScenarioId , InvestmentId
  )
, ResultInsvesment as ( select FundId , ScenarioId , InvestmentId    , sum(Equity) as Equity , sum(ExitValue) as ExitValue 
 from Investment
 group by FundId , ScenarioId , InvestmentId
 )

 --select * from ResultInsvesment

, MOIC as ( select FundId , ScenarioId , InvestmentId , 
  case when Equity = 0 Then 0 
       when ExitVAlue = 0 Then 0 else  CAST(( ExitVAlue / Equity) AS decimal (18,2)) End as  ActiveMOIC
  --( ExitVAlue / Equity)  as  MOIC
 from ResultInsvesment
 Group By  FundId , ScenarioId , InvestmentId ,Equity , ExitValue 
 )

 --select * from FinalResult

 , ActiveMOIC as (
 select A.FundId , A.ScenarioId ,A.InvestmentId , B.InvestmentName ,  
 
  CASE WHEN A.ActiveMOIC < 0 THEN -( A.ActiveMOIC ) ELSE  A.ActiveMOIC  END AS ActiveMOIC 
 from MOIC A
 inner join [OPGC].[OpgcInvestment] B
 on  A.InvestmentId = B.InvestmentId

 )

--select * from FinalResult1


-------------------------------------------------------------------------------------------------
, CompareInvestment 
  as 
  ( select FundId , ScenarioId , InvestmentId ,   sum(Equity) as Equity, 0 as ExitValue     
    from [OPGC].[OpgcInvestmentCashFlow] 
	where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0
    group by FundId , ScenarioId , InvestmentId 

    union all 

    select FundId , ScenarioId , InvestmentId    , 0 as Equity, sum(Equity) as ExitValue   
    from [OPGC].[OpgcInvestmentCashFlow] 
	where InvestmentCashflowTypeId in (3,5,7,8) and FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0
    group by FundId , ScenarioId , InvestmentId
  )

, CompareResultInsvesment 
  as 
  ( 
    select FundId , ScenarioId , InvestmentId    , sum(Equity) as Equity , sum(ExitValue) as ExitValue 
    from CompareInvestment
    group by FundId , ScenarioId , InvestmentId
  )

 --select * from ResultInsvesment

, CompareMOIC
  as 
  ( select FundId , ScenarioId , InvestmentId , 
          case when Equity = 0 Then 0 
               when ExitVAlue = 0 Then 0 else  CAST(( ExitVAlue / Equity) AS decimal (18,2)) End as  CompareMOIC
              --( ExitVAlue / Equity)  as  MOIC
     from CompareResultInsvesment
     Group By  FundId , ScenarioId , InvestmentId ,Equity , ExitValue 
   )

 --select * from FinalResult

 , CompareMOIC1
   as 
    (
        select A.FundId , A.ScenarioId ,A.InvestmentId , B.InvestmentName ,  
		 CASE WHEN A.CompareMOIC  < 0 THEN -( A.CompareMOIC  ) ELSE  A.CompareMOIC   end as CompareMOIC 
        from CompareMOIC A
        inner join [OPGC].[OpgcInvestment] B
        on  A.InvestmentId = B.InvestmentId

    )

   select A.FundId , A.InvestmentName , A.ScenarioId as BaselineScenarioId , isnull(B.ScenarioId,@ScenarioId) as CompareScenarioId
   ,isnull(A.ActiveMOIC,0.00) as BaselineMOIC
   , CASE WHEN B.CompareMOIC  < 0 THEN -( B.CompareMOIC  )  else isnull(B.CompareMOIC,0.00) end as CompareMOIC
   from ActiveMOIC A
   Left join CompareMOIC1 B
   on A.FundId = B.FundId  and A.InvestmentId = B.InvestmentId
 --  order by InvestmentName asc

end
END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


