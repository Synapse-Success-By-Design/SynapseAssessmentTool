;with a as (
select 
user_name(dpe.grantee_principal_id) as Principal_Name,
dpr.principal_id, 
dpe.class_desc, 
dpr.type_desc,
dpr.default_schema_name,
dpe.permission_name,
dpe.state_desc
from sys.database_permissions as dpe WITH(NOLOCK)
 inner join sys.database_principals as dpr WITH(NOLOCK)
on dpe.grantee_principal_id=dpr.principal_id)
select 
db_name() as DB_Name,
a.default_schema_name as Schema_Name,
b.Principal_Name as User_Name,
b.Role,
a.permission_name as Permission
 from a 
 right outer join
(select  dpr.type_desc, role_principal_id,user_name(member_principal_id) as Principal_Name, member_principal_id,
user_name(role_principal_id) as Role
from sys.database_role_members ro WITH(NOLOCK)
    INNER   JOIN sys.database_principals dpr WITH(NOLOCK)
    ON     ro.member_principal_id = dpr.principal_id
) as b
on b.role_principal_id=a.principal_id
where a.Principal_Name != 'R'
order by 1