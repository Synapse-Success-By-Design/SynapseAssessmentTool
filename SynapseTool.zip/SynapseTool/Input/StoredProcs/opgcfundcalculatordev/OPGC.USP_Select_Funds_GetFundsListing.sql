SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE PROCEDURE [OPGC].[USP_Select_Funds_GetFundsListing] --'Sriram.rajan'
(
	@userAlias NVARCHAR(250)
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 


BEGIN TRY

--Declare @symbol int = CHARINDEX('@',@userAlias)

--Declare @DomainName NVARCHAR(20) = SUBSTRING (@userAlias,@symbol+1,len(@userAlias)-1)
;with scenariocount as(
select O.FundId,count(OS.ScenarioId) as ScenarioCount 
from OPGC.OpgcFund O LEFT join OPGC.OpgcScenario OS on o.FundId = OS.FundId AND OS.Isdeleted = 0  group by O.FundId)

SELECT 
      f.[FundId]​ as FundId
	 ,CASE WHEN S.ScenarioCount =0 THEN 0 ELSE S.ScenarioCount END AS ScenarioCount 
     ,[FundName​]   FundName​           
     --,CAST ([TotalInvestment​] AS Decimal(30,2)) TotalInvestment      
     --,CAST([TotalRealized​] AS Decimal(30,2))   TotalRealized​     
     --,CAST([TotalUnrealized​] AS Decimal(30,2)) TotalUnrealized​ 
   --  ,  cast ( CAST ([TotalInvestment​] AS Decimal(30,0)) AS nvarchar(max)) TotalInvestment      
   --  ,cast ( CAST([TotalRealized​] AS Decimal(30,0)) AS nvarchar(max))  TotalRealized​ 	 
	  --,cast ( CAST([TotalUnrealized​] AS Decimal(30,0)) AS nvarchar(max)) TotalUnrealized​ 
	 ,cast ( CAST([CommittedCapital] AS Decimal(30,0)) AS nvarchar(max))   CommittedCapital
	 ,cast ( CAST([OffsetsByQuarter] AS Decimal(30,0)) AS nvarchar(max))   OffsetsByQuarter
	 ,cast ( CAST([OtherPartnershipFeesByQuarter] AS Decimal(30,0)) AS nvarchar(max))  OtherPartnershipFeesByQuarter	  
     ,[Description​]   Description​        
     --,cast ( CAST([ExpenseCap​] AS Decimal(30,0)) AS nvarchar(max))     ExpenseCap​  
	 ,CAST ([FundInceptionDate] AS DATE)    FundInceptionDate
     ,CAST ([ManualStepdownDate​] AS DATE)   ManualStepdownDate 
     --,CAST ([LimitedPartnerPercent​] AS Decimal(30,2)) LimitedPartnerPercent
	 ,[LPPreferredReturnPercent]  LPPreferredReturnPercent
	 ,[LPFinalSharePercent]	 	  LPFinalSharePercent	 
	 ,[GPPreferredReturnPercent]  GPPreferredReturnPercent
     ,CAST ([ManagementFeePercent​] AS Decimal(30,2))  ManagementFeePercent
	 ,CASE WHEN [CreatedOn​] IS NOT NULL AND [ModifiedOn​] IS NULL THEN DATEDIFF(Day,CAST([CreatedOn​] AS DATE),CAST(getdate() AS DATE)) ELSE 0 END  AS CreatedDateCount
	 ,CASE WHEN [CreatedOn​] IS NOT NULL AND [ModifiedOn​] IS NOT NULL THEN DATEDIFF(Day,CAST([ModifiedOn​] AS DATE),CAST(getdate() AS DATE)) ELSE 0 END  AS ModifiedDateCount


from [OPGC].[OpgcFund]	F 
JOIN scenariocount S ON F.Fundid =S.fundid
--where F.[CreatedBy​] =@DomainName


END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


