SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_LPPerformance_NetMOICComparision] --'',56,11,12
(
	 @userAlias NVARCHAR(100)
    ,@FundId  INT
    ,@ScenarioId INT
	,@ActiveScenarioId INT
    --,@IndustryId INT = NULL,
    -- @CountryId  INT = NULL 
)

As
BEGIN


BEGIN TRY

----Currently we are getting Output for  [OPGC].[USP_Select_Forecast_PerformanceCardDetails_LPPerfomance] this SP in UI level ---------------------------------

--DECLARE @BaseLineScenarioID INT --= (SELECT ScenarioId FROM [OPGC].[OpgcScenario] WHERE FundID =@FundId AND IsBaseline=1 and Isdeleted = 0)
--set @BaseLineScenarioID = @ActiveScenarioId


--DECLARE @validateCount INT = (SELECT COUNT(*) FROM  [OPGC].[OpgcFundCashFlow] WHERE FundID =@FundId AND ScenarioId = @BaseLineScenarioID and FundCashflowTypeId  in (1,2)  and Isdeleted = 0)
--DECLARE @ComparescenarioName Nvarchar (500) = (SELECT ScenarioName  FROM OPGC.OpgcScenario WHERE ScenarioId = @ScenarioId and Isdeleted = 0)
Declare @fundname nvarchar(200)= (select [FundName​] from [OPGC].[OpgcFund] where FundId = @FundId)


select   @FundId as  FundId 
       , @fundname as FundName 
	   , @ActiveScenarioId as  BaseleineScenarioId  
	   , @ScenarioId as CompareScenarioId 
	   , 0.00 as BaseleineNetMOIC 
	   , 0.00 as CompareNetMOIC



--If coalesce ( @ScenarioId,'') = '' and @validateCount > 0
--begin


--;with BaselineAmount as
--(
--SELECT FundId , ScenarioId , FundCashFlowTypeId , case when FundCashFlowTypeId=1 then sum (ValueAmount) else 0 End  as ContributionAmount ,
--        case when FundCashFlowTypeId=2 then sum (ValueAmount) else 0 End  as DistributionAmount
--FROM [OPGC].[OpgcFundCashFlow]  
--WHERE FundId=@FundId AND ScenarioId=@BaseLineScenarioID  and Isdeleted = 0
--group by FundId , ScenarioId , FundCashFlowTypeId 
--)
--, BaselineTotalAmount as (
--select FundId , ScenarioId , sum (ContributionAmount) as ContributionAmount  , sum (DistributionAmount) as DistributionAmount  
--from BaselineAmount
--group by FundId , ScenarioId
--)

----select * from cte1

--, BaselineNetMOIC as (
--select FundId as FundId , ScenarioId as BaseleineScenarioId ,  
--CASE WHEN (ContributionAmount = 0 OR DistributionAmount = 0) THEN 0
--ELSE cast ( ( (DistributionAmount / ContributionAmount) ) as decimal (18,2)) END as BaseleineNetMOIC 
--from BaselineTotalAmount
--)

--select  A.FundId ,@fundname as FundName, A.BaseleineScenarioId , cast ( 0 as int ) as CompareScenarioId , A.BaseleineNetMOIC , cast ( 0 as decimal(18,2)) as CompareNetMOIC
--from BaselineNetMOIC A
----INNER JOIN [OPGC].[OpgcFund] C
----ON A.FundId = C.FundId 

--end

--If coalesce ( @ScenarioId,'') = ''  and @validateCount = 0
--begin

--select @FundId as FundId,
--      @fundname as FundName,
--       @BaseLineScenarioID as BaseleineScenarioId ,
--	   cast ( 0 as int ) as CompareScenarioId , 
--	   cast ( 0 as decimal(18,2)) as BaseleineNetMOIC , 
--	   cast ( 0 as decimal(18,2)) as CompareNetMOIC

----;with BaselineAmount as
----(
----SELECT FundId , ScenarioId , FundCashFlowTypeId , 0  as ContributionAmount ,
----        0 as DistributionAmount
----FROM [OPGC].[OpgcFundCashFlow]  
----WHERE FundId=@FundId AND ScenarioId=@BaseLineScenarioID  and Isdeleted = 0
----group by FundId , ScenarioId , FundCashFlowTypeId 
----)
----, BaselineTotalAmount as (
----select FundId , ScenarioId , sum (ContributionAmount) as ContributionAmount  , sum (DistributionAmount) as DistributionAmount  
----from BaselineAmount
----group by FundId , ScenarioId
----)

------select * from cte1

----, BaselineNetMOIC as (
----select FundId as FundId , ScenarioId as BaseleineScenarioId ,  
----CASE WHEN (ContributionAmount = 0 OR DistributionAmount = 0) THEN 0
----ELSE cast ( ( (DistributionAmount / ContributionAmount) ) as decimal (18,2)) END as BaseleineNetMOIC 
----from BaselineTotalAmount
----)

----select  A.FundId ,C.[FundName​] as FundName, A.BaseleineScenarioId , cast ( 0 as int ) as CompareScenarioId , A.BaseleineNetMOIC , cast ( 0 as decimal(18,2)) as CompareNetMOIC
----from BaselineNetMOIC A
----INNER JOIN [OPGC].[OpgcFund] C
----ON A.FundId = C.FundId 

--end


----------------------------------------------------------------------------------------------

--IF coalesce ( @ScenarioId,'') != ''  AND @validateCount > 0 

--begin

--;with BaselineAmount as
--(
--SELECT FundId , ScenarioId , FundCashFlowTypeId , case when FundCashFlowTypeId=1 then sum (ValueAmount) else 0 End  as ContributionAmount ,
--        case when FundCashFlowTypeId=2 then sum (ValueAmount) else 0 End  as DistributionAmount
--FROM [OPGC].[OpgcFundCashFlow]  
--WHERE FundId=@FundId AND ScenarioId=@BaseLineScenarioID  and Isdeleted = 0
--group by FundId , ScenarioId , FundCashFlowTypeId 
--)
--, BaselineTotalAmount as (
--select FundId , ScenarioId , sum (ContributionAmount) as ContributionAmount  , sum (DistributionAmount) as DistributionAmount  
--from BaselineAmount
--group by FundId , ScenarioId
--)

----select * from cte1

--, BaselineNetMOIC as (
--select FundId as FundId , ScenarioId as BaseleineScenarioId ,  
--CASE WHEN (ContributionAmount = 0 OR DistributionAmount = 0) THEN 0
--ELSE cast ( ( (DistributionAmount / ContributionAmount) ) as decimal (18,2)) END as BaseleineNetMOIC 
--from BaselineTotalAmount
--)

----select * from BaselineNetMOIC

------------------------------------------COMPARE NET MOIC -----------------------------------------------------------------

--, CompareAmount as
--(
--SELECT FundId , ScenarioId , FundCashFlowTypeId , case when FundCashFlowTypeId=1 then sum (ValueAmount) else 0 End  as ContributionAmount ,
--        case when FundCashFlowTypeId=2 then sum (ValueAmount) else 0 End  as DistributionAmount
--FROM [OPGC].[OpgcFundCashFlow]  
--WHERE FundId=@FundId AND ScenarioId=@ScenarioId  and Isdeleted = 0
--group by FundId , ScenarioId , FundCashFlowTypeId 
--)
--, CompareTotalAmount as (
--select FundId , ScenarioId , sum (ContributionAmount) as ContributionAmount  , sum (DistributionAmount) as DistributionAmount   
--from CompareAmount
--group by FundId , ScenarioId
--)

----select * from cte1

--, CompareNetMOIC as (
--select FundId as FundId , ScenarioId as CompareScenarioId , 
--CASE WHEN (ContributionAmount = 0 OR DistributionAmount = 0 ) THEN 0
--ELSE cast ( ( (DistributionAmount / ContributionAmount) ) as decimal (18,2)) END as CompareNetMOIC 
--from CompareTotalAmount
--)

--select  A.FundId ,@fundname as FundName, A.BaseleineScenarioId , isnull(B.CompareScenarioId,0) as CompareScenarioId , A.BaseleineNetMOIC , isnull(B.CompareNetMOIC,0.00) as CompareNetMOIC
--from BaselineNetMOIC A
--Left join  CompareNetMOIC B
--on A.FundId = B.FundId
----INNER JOIN [OPGC].[OpgcFund] C
----ON A.FundId = C.FundId AND B.FundId = C.FundId

--end

--IF coalesce ( @ScenarioId,'') != ''  AND @validateCount = 0 

--begin

----;with BaselineAmount as
----(
----SELECT FundId , ScenarioId , FundCashFlowTypeId , case when FundCashFlowTypeId=1 then sum (ValueAmount) else 0 End  as ContributionAmount ,
----        case when FundCashFlowTypeId=2 then sum (ValueAmount) else 0 End  as DistributionAmount
----FROM [OPGC].[OpgcFundCashFlow]  
----WHERE FundId=@FundId AND ScenarioId=@BaseLineScenarioID  and Isdeleted = 0
----group by FundId , ScenarioId , FundCashFlowTypeId 
----)
----, BaselineTotalAmount as (
----select FundId , ScenarioId , sum (ContributionAmount) as ContributionAmount  , sum (DistributionAmount) as DistributionAmount  
----from BaselineAmount
----group by FundId , ScenarioId
----)

------select * from cte1

----,BaselineNetMOIC as (


----select FundId as FundId , ScenarioId as BaseleineScenarioId ,  
----CASE WHEN (ContributionAmount = 0 OR DistributionAmount = 0) THEN 0
----ELSE cast ( ( (DistributionAmount / ContributionAmount) ) as decimal (18,2)) END as BaseleineNetMOIC 
----from BaselineTotalAmount
----)

----select * from BaselineNetMOIC

------------------------------------------COMPARE NET MOIC -----------------------------------------------------------------

--;with CompareAmount as
--(
--SELECT FundId , ScenarioId , FundCashFlowTypeId , case when FundCashFlowTypeId=1 then sum (ValueAmount) else 0 End  as ContributionAmount ,
--        case when FundCashFlowTypeId=2 then sum (ValueAmount) else 0 End  as DistributionAmount
--FROM [OPGC].[OpgcFundCashFlow]  
--WHERE FundId=@FundId AND ScenarioId=@ScenarioId  and Isdeleted = 0
--group by FundId , ScenarioId , FundCashFlowTypeId 
--)
--, CompareTotalAmount as (
--select FundId , ScenarioId , sum (ContributionAmount) as ContributionAmount  , sum (DistributionAmount) as DistributionAmount   
--from CompareAmount
--group by FundId , ScenarioId
--)

----select * from cte1

--, CompareNetMOIC as (
--select FundId as FundId , ScenarioId as CompareScenarioId , 
--CASE WHEN (ContributionAmount = 0 OR DistributionAmount = 0 ) THEN 0
--ELSE cast ( ( (DistributionAmount / ContributionAmount) ) as decimal (18,2)) END as CompareNetMOIC 
--from CompareTotalAmount
--)

--select  @FundId as FundId ,@fundname as FundName, @BaseLineScenarioID as BaseleineScenarioId  , isnull(B.CompareScenarioId,0) as CompareScenarioId , 0.00 as BaseleineNetMOIC , isnull(B.CompareNetMOIC,0.00) as CompareNetMOIC
--from CompareNetMOIC B


------from BaselineNetMOIC A
----Left join  CompareNetMOIC B
----on A.FundId = B.FundId
----INNER JOIN [OPGC].[OpgcFund] C
----ON A.FundId = C.FundId AND B.FundId = C.FundId

--end



END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


