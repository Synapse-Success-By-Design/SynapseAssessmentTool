SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Update_Forecast_Fund_EditCashFlowEvent] --1
(
	    @fundId                INT
	   ,@scenarioId            INT
	   ,@fundCashflowId       INT
	   ,@fundCashflowTypeId    INT
	   ,@eventDate             DATETIME
       ,@valueAmount           DECIMAL (30,2)
       ,@tag                   NVARCHAR(250)
       ,@status                NVARCHAR(250)
	   ,@userAlias             NVARCHAR(250)
	   ,@LimitedPartnerPercent DECIMAL (5,2)
	  
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    17/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 


BEGIN TRY

declare @FundMindate date = ( select FundInceptionDate from [OPGC].[OpgcScenario]  where FundId =@fundId and ScenarioId = @scenarioId)


DECLARE @ErrorText NVARCHAR(MAX)

 if @FundMindate > @eventDate
begin
SET @ErrorText = 'Date is less than Fund Inception Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)
end 

 

UPDATE [OPGC].[OpgcFundCashFlow]
SET  EventDate = CASE WHEN @eventDate IS NOT NULL THEN @eventDate ELSE EventDate END
	,FundCashflowTypeId = CASE WHEN @fundCashflowTypeId IS NOT NULL THEN @fundCashflowTypeId ELSE FundCashflowTypeId END
	,ValueAmount = CASE WHEN @valueAmount IS NOT NULL THEN @valueAmount ELSE ValueAmount END
	,IsActual = IIF(@status is not null ,iif(@status ='Actual',1,0),IsActual) 
	,IsHypothetical = IIF(@status is not null ,iif(@status ='Hypothetical',1,0),IsHypothetical) 
	,LimitedPartnerPercent = @LimitedPartnerPercent
	,Tag = CASE WHEN @tag IS NOT NULL THEN @tag ELSE Tag END
	,ModifiedBy = @userAlias
	,modifiedOn = Getdate()

	where fundid = @fundid and ScenarioId = @scenarioId  and FundCashflowId = @fundCashflowId

-------------------------------------------------------------update fot OPGC.OPGCFund Table with Baselinescenario investmnents------------------------------------------------------------
--DECLARE @BaselineScenarioid INT 
--SET @BaselineScenarioid = (SELECT ScenarioId from OPGC.OpgcScenario WHERE FundID = @fundid AND IsBaseline = 1)
--DECLARE @Investment Decimal (30,2) = (SELECT SUM(Equity) FROM OPGC.OpgcInvestmentCashFlow WHERE Fundid = @fundid and ScenarioId = @BaselineScenarioid and InvestmentCashflowTypeId in (1,2) and Isdeleted = 0)
--DECLARE @totalInvestment Decimal (30,2), @realizedinvestment Decimal (30,2), @Unrealizedinvestment Decimal (30,2)
--;with Investment as  
--(  
--select FundId , ScenarioId , InvestmentId  , sum(Equity) as InitialInvestment , 0 as ExitValue   
--  from [OPGC].[OpgcInvestmentCashFlow]   
--  where InvestmentCashflowTypeId in (1,2) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
--  group by FundId , ScenarioId , InvestmentId   
--  union all   
--  select FundId , ScenarioId , InvestmentId  , 0 as IntialInvestment , sum(Equity) as ExitValue     
--  from [OPGC].[OpgcInvestmentCashFlow]   
--  where InvestmentCashflowTypeId in (3) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
--  group by FundId , ScenarioId , InvestmentId   
--  )  
--, TotalIvestment as  
--(  
--  select FundId , ScenarioId , InvestmentId  , sum( InitialInvestment) as Investment , sum (ExitValue)  as ExitVAlue   
--  from Investment A  
--   group by FundId , ScenarioId , InvestmentId   
--),
--Realizedvalidation as(
--SELECT FundId , ScenarioId , InvestmentId  ,  Investment ,  ExitVAlue ,
--CASE WHEN ExitVAlue > Investment THEN 1 ELSE 0 END AS IsRealized
--FROM TotalIvestment
--),
--------------------Investmet by Eventdate-----------------------------
--Investmentbyeventdate AS (
--select FundId , ScenarioId , InvestmentId  , CAST(EventDate AS DATE) EventDate,sum(Equity) as InitialInvestment , 0 as ExitValue   
--  from [OPGC].[OpgcInvestmentCashFlow]   
--  where InvestmentCashflowTypeId in (1,2) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
--  group by FundId , ScenarioId , InvestmentId ,CAST(EventDate AS DATE)  
--  union all   
--  select FundId , ScenarioId , InvestmentId  , CAST(EventDate AS DATE) EventDate,0 as IntialInvestment , sum(Equity) as ExitValue     
--  from [OPGC].[OpgcInvestmentCashFlow]   
--  where InvestmentCashflowTypeId in (3) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
--  group by FundId , ScenarioId , InvestmentId,CAST(EventDate AS DATE)
--  ),
--  TotalInvestmentbyeventdate AS (
--  select FundId , ScenarioId , InvestmentId  ,  EventDate,sum(InitialInvestment) as Investment ,  SUM(ExitValue) ExitValue
--  FROM Investmentbyeventdate
--  GROUP BY FundId , ScenarioId , InvestmentId  ,  EventDate
--  ),
--  Categorization as (
--  SELECT T.FundId , T.ScenarioId , T.InvestmentId  ,  T.EventDate,
--  CASE WHEN R.IsRealized = 1 THEN T.Investment *-1 ELSE 0 End AS Realizedinvestment,
--  CASE WHEN R.IsRealized = 0 THEN T.Investment *-1 ELSE 0 End AS UnRealizedinvestment,
--  CASE WHEN R.IsRealized = 1 THEN T.ExitValue  ELSE 0 End AS RealizedExitValue,
--  CASE WHEN R.IsRealized = 0 THEN T.ExitValue  ELSE 0 End AS UnRealizedExitValue
--  FROM TotalInvestmentbyeventdate T
--  INNER JOIN Realizedvalidation R On T.FundId = R.FundId and  T.ScenarioId  = R.ScenarioId and  T.InvestmentId =  R.InvestmentId
--  ),FinalResul As(
--  SELECT FundId,SUM(Realizedinvestment)*-1 Realizedinvestment, SUM(UnRealizedinvestment)*-1 UnRealizedinvestment , Sum(Realizedinvestment+UnRealizedinvestment)*-1 as TotalInvestment
--		FROM Categorization
--		GROUP BY FundId
--		)
--		SELECT @totalInvestment = TotalInvestment,
--			   @realizedinvestment = Realizedinvestment,
--			   @Unrealizedinvestment = UnRealizedinvestment
--			   FROM FinalResul

--If (Select count(InvestmentCashflowTypeId) FROM OPGC.OpgcInvestmentCashFlow WHERE fundId = @fundid and ScenarioId = @BaselineScenarioid and InvestmentCashflowTypeId = 3 AND Isdeleted = 0) >=1
--BEGIN

--UPDATE OPGC.OpgcFund
--SET [TotalInvestment​] = IIF(COALESCE([TotalInvestment​],0.00) = 0.00,@totalInvestment,[TotalInvestment​]),
--	[TotalRealized​] = IIF(COALESCE([TotalRealized​],0.00) = 0.00,@realizedinvestment,[TotalRealized​]),
--	[TotalUnrealized​] = IIF(COALESCE([TotalUnrealized​],0.00) = 0.00,@Unrealizedinvestment,[TotalUnrealized​])
--	WHERE Fundid = @fundid


--END 


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END   
END CATCH
END


