SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcCountry](
	[CountryId] [int] IDENTITY(1,1) NOT NULL,
	[CountryName] [nvarchar](50) NOT NULL,
	[CreatedBy​] [nvarchar](50) NOT NULL,
	[CreatedOn​] [datetime] NOT NULL,
	[ModifiedBy​] [nvarchar](50) NULL,
	[ModifiedOn​] [datetime] NULL,
	[CountryCode] [nvarchar](10) NULL,
	[Isdeleted] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[CountryId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcCountry] ADD  CONSTRAINT [df_OpgcCountry_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn​]
ALTER TABLE [OPGC].[OpgcCountry] ADD  DEFAULT ((0)) FOR [Isdeleted]
