SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
                --  [OPGC].[USP_Select_GoalSeek_Investment_Dropdown] '',44,143 
CREATE PROCEDURE [OPGC].[USP_Select_GoalSeek_Investment_Dropdown_Test]--'',44,143  
(  
  @userAlias NVARCHAR(250)  
 ,@fundId INT  
 ,@scenarioId INT  
   
)  
  
As  
  
BEGIN  

BEGIN TRY

declare @InvestmentId as table ( Id int)

  ;with investment as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, Exitvalue as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3) and 
  FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

,withouExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (5,7) and 
  FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

,InvesmentExit as(
select A.InvestmentId from investment A
join Exitvalue B
on A.InvestmentId =B.InvestmentId
)

--select * from InvesmentExit

, InvesmentWithoutExit as
(
select A.InvestmentId from investment A
 join withouExit B
on A.InvestmentId =B.InvestmentId 
)


,investmentwithUnion as
(
select  InvestmentId from investment
union all 
select  InvestmentId from InvesmentWithoutExit
)

, ExceptInvestment as 
( 
select distinct InvestmentId from investmentwithUnion
except
select  InvestmentId from InvesmentExit
)


insert into @InvestmentId
select * from ExceptInvestment


select InvestmentId , InvestmentName from [OPGC].[OpgcInvestment]
where FundId = @fundId and InvestmentId in ( select Id from @InvestmentId ) and Isdeleted = 0
order by InvestmentName asc

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END

