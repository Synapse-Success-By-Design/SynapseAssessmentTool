SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_FundPerformance_GrossGIRRComparision] --'',3,17,null,null,17
(
	 @userAlias NVARCHAR(100)
    ,@FundId  INT
    ,@ScenarioId INT
    ,@IndustryId INT = NULL,
     @CountryId  INT = NULL
	,@ActiveScenarioId int
 
)

As

--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Appointment Details


Uses   
      [USP_Select_Appointment_GetAppointmentDetails]	    SP

Populates
      [WWMG].[ConfirmedScheduleDetails]			Table
	  [WWMG].[LocationDetails]					Table
	  [WWMG].[UserFamilyDetails]				Table
	  [WWMG].[FamilyDetails_Relations]			Table
**************************************************************************/
BEGIN 

DECLARE @BaseLineScenarioID INT --= (SELECT ScenarioId FROM [OPGC].[OpgcScenario] WHERE FundID =@FundId AND IsBaseline=1  and Isdeleted = 0)
set @BaseLineScenarioID  = @ActiveScenarioId 

declare @CompareScenarioID1 int = ( select distinct FundId from [OPGC].[OpgcInvestmentCashFlow] where FundId = @ScenarioId AND Isdeleted = 0 )

declare @ScenarioIDchecktable as table (id int)

----------------------------------------------------------------------------------------------------------------------------------------

;with BaseLineScenarioCheck as
(
  SELECT distinct FundId , ScenarioId , InvestmentId FROM  [OPGC].[OpgcInvestmentCashFlow] 
 where  ScenarioId = @BaseLineScenarioID and FundId = @FundId AND Isdeleted = 0
 
 )
, CurrentScenarioCheck as
(
 SELECT distinct FundId , ScenarioId , InvestmentId FROM  [OPGC].[OpgcInvestmentCashFlow]
 where  ScenarioId = @ScenarioId and FundId = @FundId AND Isdeleted = 0
 )


insert into @ScenarioIDchecktable
select count(1) as ID
from BaseLineScenarioCheck A
inner join CurrentScenarioCheck B
on A.InvestmentId = B.InvestmentId

------------------------------------------------------------------------------------------------------------------------------

Declare @ScenarioIDcheck int = (Select * from @ScenarioIDchecktable )

DECLARE @SnapshotDate Datetime = GETDATE()


If coalesce ( @ScenarioId,'') = ''-- or @ScenarioIDcheck = 0
begin


EXEC OPGC.Proc_CalculateGIRR @FundId , @BaseLineScenarioID , @SnapshotDate


--;with ActiveInvestment as ( select FundId , ScenarioId , InvestmentId ,   sum(Equity) as Equity,0 as ExitValue   
--  from [OPGC].[OpgcInvestmentCashFlow] 
--  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
--  group by FundId , ScenarioId , InvestmentId 
--  union all 
--  select FundId , ScenarioId , InvestmentId  ,  0 as Equity, sum(Equity) as ExitValue 
--  from [OPGC].[OpgcInvestmentCashFlow] 
--  where InvestmentCashflowTypeId in (3,5,7) and FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
--  group by FundId , ScenarioId , InvestmentId
--  )
--, ActiveResultInsvesment as ( select FundId , ScenarioId , InvestmentId , sum(Equity) as Equity , sum(ExitValue) as ExitValue 
-- from ActiveInvestment
-- group by FundId , ScenarioId , InvestmentId
-- )
; with ActiveResultInsvesment as(
 select  FundId , ScenarioId , InvestmentId , min(CreatedOn) as CreatedOn from [OPGC].[OpgcInvestmentCashFlow]  where FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
group by FundId , ScenarioId , InvestmentId 
 order by InvestmentId 
 offset 0 rows
 )
 --select * from ActiveResultInsvesment

 , ActiveGIRR as (
 select A.FundId , A.ScenarioId , A.InvestmentId , B.InvestmentName ,R.GIRR
 from ActiveResultInsvesment A
 inner join [OPGC].[OpgcInvestment] B
 on  A.InvestmentId = B.InvestmentId
 INNER JOIN OPGC.OPGCResultGIRR R ON R.FundId = A.FundId AND R.ScenarioId = A.ScenarioId and R.InvestmentID = A.InvestmentId AND R.SnapshotDate = @SnapshotDate
 )

  select A.FundId , A.InvestmentName  , A.ScenarioId as BaselineScenarioId  , cast ( 0 as int) as CompareScenarioId ,A.GIRR as BaselineIRR ,cast (0 as decimal(18,2) ) AS CompareIRR
 from ActiveGIRR A

 
--insert into [OPGC].[OPGCResultGIRR_History] ( FundId , ScenarioId , InvestmentID , GIRR, SnapshotDate , Modifiedon ,  ModifiedBy , InvestmentName)
--select  A.FundId , A.ScenarioId , A.InvestmentID , A.GIRR, A.SnapshotDate , GETDATE() , 'Fund Perfomance Graph' ,B.InvestmentName
--from OPGC.OPGCResultGIRR A
--Left Join [OPGC].[OpgcInvestment] B
--on A.InvestmentID = B.InvestmentId and B.Isdeleted = 0


 DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate

end

else
begin


EXEC OPGC.Proc_CalculateGIRR @FundId , @BaseLineScenarioID , @SnapshotDate
EXEC OPGC.Proc_CalculateGIRR @FundId , @ScenarioId , @SnapshotDate



--;with ActiveInvestment as ( select FundId , ScenarioId , InvestmentId ,   sum(Equity) as Equity,0 as ExitValue   
--  from [OPGC].[OpgcInvestmentCashFlow] 
--  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
--  group by FundId , ScenarioId , InvestmentId 
--  union all 
--  select FundId , ScenarioId , InvestmentId  ,  0 as Equity, sum(Equity) as ExitValue 
--  from [OPGC].[OpgcInvestmentCashFlow] 
--  where InvestmentCashflowTypeId in (3,5,7) and FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
--  group by FundId , ScenarioId , InvestmentId
--  )
--, ActiveResultInsvesment as ( select FundId , ScenarioId , InvestmentId , sum(Equity) as Equity , sum(ExitValue) as ExitValue 
-- from ActiveInvestment
-- group by FundId , ScenarioId , InvestmentId
-- )

; with ActiveResultInsvesment as(
 select  FundId , ScenarioId , InvestmentId , min(CreatedOn) as CreatedOn from [OPGC].[OpgcInvestmentCashFlow]  where FundId = @FundId and ScenarioId = @BaseLineScenarioID and Isdeleted=0
group by FundId , ScenarioId , InvestmentId 
 order by InvestmentId 
 offset 0 rows
 )
 --select * from ActiveResultInsvesment

 , ActiveGIRR as (
 select A.FundId , A.ScenarioId , A.InvestmentId , B.InvestmentName ,R.GIRR
 from ActiveResultInsvesment A
 inner join [OPGC].[OpgcInvestment] B
 on  A.InvestmentId = B.InvestmentId
 INNER JOIN OPGC.OPGCResultGIRR R ON R.FundId = A.FundId AND R.ScenarioId = A.ScenarioId and R.InvestmentID = A.InvestmentId AND R.SnapshotDate = @SnapshotDate
 )

 --select * from ActiveGIRR

--------------------------------COMPARE----------------------------------------------------------------------------------------------

--, CompareInvestment as ( select FundId , ScenarioId , InvestmentId ,   sum(Equity) as Equity,0 as ExitValue   
--  from [OPGC].[OpgcInvestmentCashFlow] 
--  where InvestmentCashflowTypeId in (1,2) and FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0
--  group by FundId , ScenarioId , InvestmentId 
--  union all 
--  select FundId , ScenarioId , InvestmentId  ,  0 as Equity, sum(Equity) as ExitValue 
--  from [OPGC].[OpgcInvestmentCashFlow] 
--  where InvestmentCashflowTypeId in (3) and FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0
--  group by FundId , ScenarioId , InvestmentId
--  )
--, CompareResultInsvesment as ( select FundId , ScenarioId , InvestmentId , sum(Equity) as Equity , sum(ExitValue) as ExitValue 
-- from CompareInvestment
-- group by FundId , ScenarioId , InvestmentId
-- )

, CompareResultInsvesment as(
 select  FundId , ScenarioId , InvestmentId , min(CreatedOn) as CreatedOn from [OPGC].[OpgcInvestmentCashFlow]  where FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0
group by FundId , ScenarioId , InvestmentId 
 order by InvestmentId 
 offset 0 rows
 )

 --select * from CompareResultInsvesment

 , CompareGIRR as (
 select A.FundId , A.ScenarioId , A.InvestmentId , B.InvestmentName , R.GIRR 
 from CompareResultInsvesment A
 inner join [OPGC].[OpgcInvestment] B
 on  A.InvestmentId = B.InvestmentId
 INNER JOIN OPGC.OPGCResultGIRR R 
 ON R.FundId = A.FundId AND R.ScenarioId = A.ScenarioId and R.InvestmentID = A.InvestmentId AND R.SnapshotDate = @SnapshotDate
 )

--select * from CompareGIRR

 --select distinct A.FundId , A.InvestmentName  , A.ScenarioId as BaselineScenarioId  , isnull(B.ScenarioId,@ScenarioId) as CompareScenarioId ,A.GIRR as BaselineIRR ,isnull(B.GIRR,0.00) AS CompareIRR
 --from ActiveGIRR A
 --Left join CompareGIRR B
 --on A.FundId = B.FundId and A.InvestmentId = B.InvestmentId
 

 , FinalIRR as (
 select distinct A.FundId , A.InvestmentId , A.InvestmentName  , A.ScenarioId as BaselineScenarioId  , isnull(B.ScenarioId,@ScenarioId) as CompareScenarioId ,A.GIRR as BaselineIRR ,isnull(B.GIRR,0.00) AS CompareIRR
 from ActiveGIRR A
 Left join CompareGIRR B
 on A.FundId = B.FundId and A.InvestmentId = B.InvestmentId
 order by A.InvestmentId asc
 offset 0 rows
 )

 select  FundId  , InvestmentName  ,  BaselineScenarioId  ,  CompareScenarioId , BaselineIRR , CompareIRR
 from FinalIRR A



--insert into [OPGC].[OPGCResultGIRR_History] ( FundId , ScenarioId , InvestmentID , GIRR, SnapshotDate , Modifiedon ,  ModifiedBy , InvestmentName)
--select  A.FundId , A.ScenarioId , A.InvestmentID , A.GIRR, A.SnapshotDate , GETDATE() , 'Fund Perfomance Graph' ,B.InvestmentName
--from OPGC.OPGCResultGIRR A
--Left Join [OPGC].[OpgcInvestment] B
--on A.InvestmentID = B.InvestmentId and B.Isdeleted = 0


 DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate

end
END 

