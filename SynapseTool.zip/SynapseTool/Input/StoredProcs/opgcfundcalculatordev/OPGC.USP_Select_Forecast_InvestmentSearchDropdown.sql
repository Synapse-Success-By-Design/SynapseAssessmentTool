SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
  
CREATE PROCEDURE [OPGC].[USP_Select_Forecast_InvestmentSearchDropdown] --'',1,'hdfc'
(  
   @userAlias NVARCHAR(50),  
   @FundId INT,
   @SearchName nvarchar(250)
 
)  
  


As  
BEGIN  
--=======================================================   
 --Author         :    <AEGIS Team>      
 --Create Date    :    18/03/2021   
 --Description    :   Select the Get Appointment Details  
--===========================================================   
 --History                    
 --Author         :         Date         Description   
  
--============================================================   
  
/*************************************************************************  
Purpose  
      Display the Appointment Details  
  
Uses     
      [USP_Select_Appointment_GetAppointmentDetails]     SP  
  
Populates  
   [WWMG].[ConfirmedScheduleDetails]   Table  
   [WWMG].[LocationDetails]     Table  
   [WWMG].[UserFamilyDetails]    Table  
   [WWMG].[FamilyDetails_Relations]   Table  
**************************************************************************/  
BEGIN TRY  

set @SearchName = '"*'+@SearchName+'*"'

SELECT A.InvestmentId , A.InvestmentName , [Address]  , B.[IndustryName​] AS IndustryName , A.CountryId , C.CountryName
from [OPGC].[opgcInvestment] A
inner join [OPGC].[OpgcIndustry] B
On A.IndustryId = B.[IndustryId​]
inner join [OPGC].[OpgcCountry] C
on A.CountryId = C.CountryId

WHERE Contains([InvestmentName] ,@SearchName) AND FundID = @FundId and A.Isdeleted = 0




  
END TRY  
BEGIN CATCH  
 DECLARE @ErrorNumber INT  
 DECLARE @Severity  INT  
 DECLARE @State   INT   
 DECLARE @Procedure  NVARCHAR(250)  
 DECLARE @LineNumber  INT  
 DECLARE @Message  NVARCHAR(MAX)  
 DECLARE @Originator NVARCHAR(250)
 DECLARE @ErrorText nvarchar(250)

 SELECT   
  @ErrorNumber = ERROR_NUMBER(),  
  @Severity = ERROR_SEVERITY(),  
  @State = ERROR_STATE(),   
  @Procedure = ERROR_PROCEDURE(),  
  @LineNumber = ERROR_LINE(),   
  @Message = ERROR_MESSAGE()     
 EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message,   
       'Database', null, null,null   IF @ErrorText <> ''  
BEGIN  
RAISERROR (@ErrorText, 16, 1)  
END  
ELSE  
BEGIN  
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages  
END        
END CATCH  
END  
  
