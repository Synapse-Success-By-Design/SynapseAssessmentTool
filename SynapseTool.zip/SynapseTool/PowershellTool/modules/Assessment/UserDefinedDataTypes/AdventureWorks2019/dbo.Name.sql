CREATE TYPE [dbo].[Name] FROM [nvarchar](50) NULL
