SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_InvestmentDetails_EditDetailedView] --'',3,8,'2021-12-20'
(
	 @userAlias NVARCHAR(250)
	,@fundId INT
	,@scenarioId INT
	,@EventDate DATE
	
)

As

BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    10/11/2021 
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

BEGIN TRY

select 
 a.InvestmenCashflowId AS InvestmentCashflowId
 ,a.EventDate AS [Date]
 ,a.InvestmentCashflowTypeId AS InvestmentCashFlowTypeId
,C.InvestmentId as InvestmentId
,c.InvestmentName AS Investment
,b.InvestmentCashFlowType AS [Type],
SUM (A.Equity) AS Amount
,CASE WHEN A.IsActual = 1 THEN 'Actual' ELSE 'Hypothetical' END AS [Status]
,a.Tag AS Tag
,A.RecallableUntil as RecallableUntil
,a.IsRecallable AS recallBool
,A.LimitedPartnerPercent
from [OPGC].[OpgcInvestmentCashFlow] A
JOIN [OPGC].[OpgcInvestmentCashFlowType] B
ON A.InvestmentCashflowTypeId = B.InvestmentCashFlowTypeId
JOIN [OPGC].[OpgcInvestment] c
on a.InvestmentId=c.InvestmentId
where A.FundId = @fundId AND A.ScenarioId = @scenarioId AND a.EventDate=@EventDate and A.Isdeleted=0
group by a.EventDate,c.InvestmentName,b.InvestmentCashFlowType,a.Tag , A.IsActual,c.InvestmentId,a.InvestmentCashFlowTypeId,a.InvestmenCashflowId,A.RecallableUntil,A.IsRecallable,A.LimitedPartnerPercent


END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END



