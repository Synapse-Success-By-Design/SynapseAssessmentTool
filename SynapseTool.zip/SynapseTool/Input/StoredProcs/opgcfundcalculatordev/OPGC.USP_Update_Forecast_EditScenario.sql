SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE PROCEDURE [OPGC].[USP_Update_Forecast_EditScenario] --'admin',44,155,'test ss','s5555s',1,1234500,1234567800,1234567800,'2026-04-20','2025-04-26',12,52,33,44
(
	  @userAlias NVARCHAR(50)
	 ,@Fundid INT
	 ,@ScenarioId INT
	 ,@ScenarioName NVARCHAR(20)
	 ,@ScenarioDescription NVARCHAR(500)
	 ,@BaseLineStatus BIT
	 ,@CommittedCapital               DECIMAL(30,2)
	 ,@OffsetsByQuarter               DECIMAL(30,2)
	 ,@OtherPartnershipFeesByQuarter  DECIMAL(30,2)
	 ,@FundInceptionDate              DATETIME
	 ,@ManualStepdownDate​             DATETIME
	 ,@LPPreferredReturnPercent       DECIMAL(5,2)
	 ,@LPFinalSharePercent            DECIMAL(5,2)
	 ,@GPPreferredReturnPercent       DECIMAL(5,2)
	 ,@ManagementFeePercent​           DECIMAL(5,2)
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 


BEGIN TRY


DECLARE @ErrorText NVARCHAR(200) = ''

DECLARE @CurrentBaseLineValue INT = (SELECT IsBaseline FROM [OPGC].[OpgcScenario] WHERE FundID=@Fundid AND ScenarioId=@ScenarioId and Isdeleted = 0)

DECLARE @SumofOtherScenarios INT = (SELECT ISNULL(SUM(CAST (IsBaseline AS INT)),0) FROM [OPGC].[OpgcScenario] WHERE FundID=@Fundid AND ScenarioId!=@ScenarioId and Isdeleted = 0)

DECLARE @CurrentScenarioName  NVARCHAR(200) = (SELECT ScenarioName FROM [OPGC].[OpgcScenario] WHERE FundID=@Fundid AND ScenarioId=@ScenarioId and Isdeleted = 0)

DECLARE @CurrentScenarioDesc  NVARCHAR(200) = (SELECT ScenarioDescription FROM [OPGC].[OpgcScenario] WHERE FundID=@Fundid AND ScenarioId=@ScenarioId and Isdeleted = 0 )


DECLARE @ScenarioNameValues as TABLE
(
ScenarioName NVARCHAR(200)
)

insert into @ScenarioNameValues
select ScenarioName from [OPGC].[OpgcScenario] where  Isdeleted = 0-- where FundID=@Fundid

DECLARE @IfScenarioNameExist INT = (SELECT COUNT(*) FROM @ScenarioNameValues WHERE ScenarioName = @ScenarioName)


declare @GlobalFundMindate date = ( select FundInceptionDate from [OPGC].[OpgcFund]  where FundId =@FundId  )



--select @IfScenarioNameExist



--DECLARE @IfScenarioNameExistNew INT = (Select count(ScenarioId)from [OPGC].[OpgcScenario] where FundID=@Fundid  and ScenarioName =@ScenarioName )--Isdeleted=0)

--If @IfScenarioNameExistNew > 0
--Begin

--SET @ErrorText = 'Scenario Name Already Exists'
--RAISERROR (@ErrorText, 16, 1)

--END




if @IfScenarioNameExist = 1 AND @CurrentScenarioName != @ScenarioName
BEGIN
SET @ErrorText = 'Scenario Name Already Exists'
RAISERROR (@ErrorText, 16, 1)
END



IF @IfScenarioNameExist =0 --or @IfScenarioNameExist = 1
BEGIN

IF (@CurrentBaseLineValue = @BaseLineStatus)

BEGIN

UPDATE [OPGC].[OpgcScenario]
SET  ScenarioName = @ScenarioName
	,ScenarioDescription = @ScenarioDescription
	,IsBaseline = @BaseLineStatus
	,ModifiedBy = @userAlias
	,modifiedOn = Getdate()
     ,CommittedCapital                      =    @CommittedCapital           
	,OffsetsByQuarter                       =    @OffsetsByQuarter               
	,OtherPartnershipFeesByQuarter          =    @OtherPartnershipFeesByQuarter  
	,FundInceptionDate                      =    @FundInceptionDate              
	,ManualStepdownDate                     =    @ManualStepdownDate​             
	,LPPreferredReturnPercent               =    @LPPreferredReturnPercent       
	,LPFinalSharePercent                    =    @LPFinalSharePercent            
	,GPPreferredReturnPercent               =    @GPPreferredReturnPercent       
	,ManagementFeePercent                   =    @ManagementFeePercent​ 
	
	where fundid = @Fundid and ScenarioId= @ScenarioId and Isdeleted = 0

END

END

IF (@CurrentBaseLineValue=1 AND @SumofOtherScenarios=0 and @baselinestatus =0)

BEGIN

SET @ErrorText = 'Alteast One Scenario Needs To Be Active'
RAISERROR (@ErrorText, 16, 1)

END


if @GlobalFundMindate > @FundInceptionDate
begin

SET @ErrorText = 'Date is less than Global Fund Inception Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)

end


--IF (@CurrentBaseLineValue!=@BaseLineStatus AND @SumofOtherScenarios!=0)
If (@IfScenarioNameExist = 1 or @IfScenarioNameExist = 0) and (@CurrentScenarioName = @ScenarioName)
begin
UPDATE [OPGC].[OpgcScenario]
SET  ScenarioName                           =    @ScenarioName
	,ScenarioDescription                    =    @ScenarioDescription
	,IsBaseline                             =    @BaseLineStatus
	,ModifiedBy                             =    @userAlias
	,modifiedOn                             =    Getdate()
	,CommittedCapital                       =    @CommittedCapital           
	,OffsetsByQuarter                       =    @OffsetsByQuarter               
	,OtherPartnershipFeesByQuarter          =    @OtherPartnershipFeesByQuarter  
	,FundInceptionDate                      =    @FundInceptionDate              
	,ManualStepdownDate                     =    @ManualStepdownDate​             
	,LPPreferredReturnPercent               =    @LPPreferredReturnPercent       
	,LPFinalSharePercent                    =    @LPFinalSharePercent            
	,GPPreferredReturnPercent               =    @GPPreferredReturnPercent       
	,ManagementFeePercent                   =    @ManagementFeePercent​           
	
	where fundid = @Fundid and ScenarioId = @ScenarioId and Isdeleted = 0



end

IF @BaseLineStatus = 1
BEGIN
UPDATE [OPGC].[OpgcScenario]
SET IsBaseline = 0
WHERE ScenarioId != @ScenarioId AND fundid = @Fundid and Isdeleted = 0
END



END TRY
BEGIN CATCH
DECLARE @ErrorNumber INT
DECLARE @Severity INT
DECLARE @State INT
DECLARE @Procedure NVARCHAR(250)
DECLARE @LineNumber INT
DECLARE @Message NVARCHAR(MAX)
DECLARE @Originator NVARCHAR(250)
SELECT
@ErrorNumber = ERROR_NUMBER(),
@Severity = ERROR_SEVERITY(),
@State = ERROR_STATE(),
@Procedure = ERROR_PROCEDURE(),
@LineNumber = ERROR_LINE(),
@Message = ERROR_MESSAGE()
EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message,
'Database', null, null,null
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END
END CATCH
END


