SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Delete_Forecast_EditScenario] --'',5,22
(
	  @userAlias NVARCHAR(50)
	 ,@FundId INT
	 ,@ScenarioId INT

)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    
 --Description    :   
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 


BEGIN TRY

DECLARE @ErrorText NVARCHAR(MAX) =''

declare @BaselineScenario int = ( select COUNT(1) from [OPGC].[OpgcScenario] where   FundId = @FundId AND ScenarioId = @ScenarioId and IsBaseline = 1 and Isdeleted = 0 )

declare @InvestmentId as table ( id int)

insert into @InvestmentId

select distinct InvestmentId from [OPGC].[OpgcInvestmentCashFlow] where FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted = 0
except
select distinct InvestmentId from [OPGC].[OpgcInvestmentCashFlow] where FundId = @FundId and ScenarioId != @ScenarioId and Isdeleted = 0


If @BaselineScenario = 0

begin



-----------[OPGC].[OpgcInvestmentCashFlow]------------------------------------------------------------

UPDATE [OPGC].[OpgcInvestmentCashFlow]
SET  Isdeleted=1,
     ModifiedBy=@userAlias
	,ModifiedOn=GETDATE()
WHERE FundId = @FundId AND ScenarioId = @ScenarioId and Isdeleted = 0

--delete from [OPGC].[OpgcInvestmentCashFlow] where  FundId = @FundId AND ScenarioId = @ScenarioId and Isdeleted = 0

----------------------------[OpgcFundCashFlow]---------------------------------------------------------------------------------------------------

UPDATE [OPGC].[OpgcFundCashFlow]
SET  Isdeleted=1,
     ModifiedBy=@userAlias
	,ModifiedOn=GETDATE()
WHERE FundId = @FundId AND ScenarioId = @ScenarioId and Isdeleted = 0

--delete from [OPGC].[OpgcFundCashFlow] where  FundId = @FundId AND ScenarioId = @ScenarioId and Isdeleted = 0


------------OpgcInvestment--------------------------------------------------------------------------------------------------------------------------

UPDATE [OPGC].[OpgcInvestment]
SET  Isdeleted=1,
     ModifiedBy=@userAlias
	,ModifiedOn=GETDATE()
WHERE FundId = @FundId  and InvestmentId in ( select id from @InvestmentId) and Isdeleted = 0

--select * from [OPGC].[OpgcInvestment] where FundId = @FundId and InvestmentId in ( select id from @InvestmentId)


--delete from [OPGC].[OpgcInvestment] where  FundId = @FundId  and InvestmentId in ( select id from @InvestmentId)  and Isdeleted = 0


-------[OPGC].[OpgcScenario]--------------------------------------------------------------------------------------


UPDATE [OPGC].[OpgcScenario]
SET  Isdeleted=1,
     ModifiedBy=@userAlias
	,ModifiedOn=GETDATE()
WHERE FundId = @FundId AND ScenarioId = @ScenarioId and Isdeleted = 0


--delete from [OPGC].[OpgcScenario] where  FundId = @FundId AND ScenarioId = @ScenarioId and Isdeleted = 0



---------------------------------------------------------------------------------------------------------------





End

Else
Begin 

SET @ErrorText = 'Scenario cannot be deleted as It is the Baseline Scenario'
RAISERROR (@ErrorText, 16, 1)

End



END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END         
END CATCH
END


