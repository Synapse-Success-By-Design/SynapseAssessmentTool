SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[ErrorLog](
	[ErrorId] [bigint] IDENTITY(1,1) NOT NULL,
	[ErrorDate] [datetime] NOT NULL,
	[ErrorNumber] [int] NULL,
	[ErrorSeverity] [int] NULL,
	[ErrorState] [int] NULL,
	[ErrorProcedure] [nvarchar](250) NULL,
	[ErrorLineNo] [int] NULL,
	[ErrorDescription] [nvarchar](max) NULL,
	[Originator] [nvarchar](50) NULL,
	[ControllerName] [nvarchar](250) NULL,
	[ActionName] [nvarchar](250) NULL,
	[UserDetailId] [int] NULL,
 CONSTRAINT [PK_OPGCErrorLog] PRIMARY KEY CLUSTERED 
(
	[ErrorId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

