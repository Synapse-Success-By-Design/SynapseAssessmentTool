SELECT DB_NAME() AS DB_Name,
    SCHEMA_NAME(sysobject.schema_id) SchemaName,
    OBJECT_NAME(stats.object_id) SPName, 
    last_execution_time AS LastExecuted, 
    execution_count,
    total_elapsed_time/execution_count 
            AS avg_elapsed_time
FROM  
    sys.dm_exec_procedure_stats stats WITH(NOLOCK)
    INNER JOIN sys.objects sysobject WITH(NOLOCK)
        ON sysobject.object_id = stats.object_id 
WHERE 
    sysobject.type = 'P' and stats.database_id=DB_ID()
ORDER BY
    last_execution_time DESC