SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcUser](
	[OpgcUserId] [int] IDENTITY(1,1) NOT NULL,
	[EmailId] [nvarchar](250) NOT NULL,
	[DisplayName] [nvarchar](250) NOT NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
 CONSTRAINT [PK__OpgcUser__91C4E32AFE1F6768] PRIMARY KEY CLUSTERED 
(
	[OpgcUserId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcUser] ADD  CONSTRAINT [DF__OpgcUser__IsDele__0E391C95]  DEFAULT ((0)) FOR [IsDeleted]
ALTER TABLE [OPGC].[OpgcUser] ADD  CONSTRAINT [df_OpgcUser_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
