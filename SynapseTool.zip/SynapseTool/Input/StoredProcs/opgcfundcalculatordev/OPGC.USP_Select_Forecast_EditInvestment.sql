SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_EditInvestment] --'ram',1
(
	  @userAlias NVARCHAR(50)
	 ,@InvestmentId INT

)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Appointment Details

Uses   
      [USP_Select_Appointment_GetAppointmentDetails]	    SP

Populates
      [WWMG].[ConfirmedScheduleDetails]			Table
	  [WWMG].[LocationDetails]					Table
	  [WWMG].[UserFamilyDetails]				Table
	  [WWMG].[FamilyDetails_Relations]			Table
**************************************************************************/
BEGIN TRY

select 
 I.InvestmentName
,I.IndustryId
,Ind.[IndustryName​] as IndustryName​
,I.CountryId
,L.CountryName
,i.[Address]
,I.InvestmentId

FROM [OPGC].[opgcInvestment] I
JOIN [OPGC].[opgcIndustry] Ind
ON I.IndustryId=ind.[IndustryId​]
JOIN [OPGC].[OpgcCountry] L
ON I.CountryId=L.CountryId
WHERE I.InvestmentId=@InvestmentId  and I.Isdeleted = 0 and Ind.Isdeleted = 0 and L.Isdeleted = 0

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


