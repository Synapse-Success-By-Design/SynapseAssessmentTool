SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcGoalSeekInvestmentcashflowType](
	[GsInvestmentId] [int] IDENTITY(1,1) NOT NULL,
	[FundId] [int] NOT NULL,
	[ScenarioId] [int] NOT NULL,
	[InvestmentId] [int] NOT NULL,
	[InvestmentcashflowtypeId] [int] NOT NULL,
	[MOIC] [decimal](30, 2) NULL,
	[IRR] [decimal](18, 2) NULL,
	[ExitDate] [date] NULL,
	[Exitvalue] [decimal](30, 2) NULL,
	[IsApplied] [bit] NOT NULL,
	[Isdeleted] [bit] NOT NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
	[CalcIRR] [decimal](18, 2) NULL,
	[CalcDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[GsInvestmentId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcGoalSeekInvestmentcashflowType] ADD  DEFAULT ((3)) FOR [InvestmentcashflowtypeId]
ALTER TABLE [OPGC].[OpgcGoalSeekInvestmentcashflowType] ADD  DEFAULT ((0)) FOR [IsApplied]
ALTER TABLE [OPGC].[OpgcGoalSeekInvestmentcashflowType] ADD  DEFAULT ((0)) FOR [Isdeleted]
