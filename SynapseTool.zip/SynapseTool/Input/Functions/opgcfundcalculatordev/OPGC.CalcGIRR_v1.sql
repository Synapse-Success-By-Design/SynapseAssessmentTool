SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE FUNCTION [OPGC].[CalcGIRR_v1]
(
    @Sample opgc.GIRRTablev1 READONLY,
    @Rate float = 0.1
)
RETURNS DECIMAL(18, 2)
AS 
BEGIN

declare @Counter as int = 1
declare @CounterMax as int = 1000
declare @DeltaEstimate as float = 1e-7
declare @DeltaRate as float = 1e-2
declare @Direction as smallint = 0
declare @Estimate as float = 0
declare @FirstDate as date 
declare @PrevEstimate as float
declare @PrevRate as float = 0
Set @Rate  = 0.1


select @FirstDate = MIN(PDate) from @Sample 


Loop:
select @Estimate = SUM(PAmount / power(1e0 + @Rate, DATEDIFF(d, @FirstDate, PDate) / 365e0) ) from @Sample

if abs(@Estimate) < @DeltaEstimate or @Counter > @CounterMax
	goto Final
if (@PrevEstimate is not null) 
	begin	
		if @PrevEstimate > 0 and @Estimate > 0
			set @Direction = 1
		if @PrevEstimate < 0 and @Estimate < 0
			set @Direction = -1 
		if (@PrevEstimate < 0 and @Estimate > 0) or (@PrevEstimate > 0 and @Estimate < 0) 
			set @DeltaRate = @DeltaRate / 2e0
	end
set @PrevEstimate = @Estimate 
set @Rate = @Rate + @DeltaRate * @Direction
select @Estimate = SUM(PAmount / power(1e0 + @Rate, DATEDIFF(d, @FirstDate, PDate) / 365e0)) from @Sample
set @Counter = @Counter + 1
goto Loop
Final:
if @Counter < @CounterMax 
Return @Rate

Return NULL
END
