SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
create PROCEDURE [OPGC].[USP_Insert_GoalSeek_Investment_CalculateIRRDate_V8] --'DB Team' , 42 , 123, 165,5,'02-24-2026',null
(  

@UserAlias      nvarchar(250),
@FundId         int,
@ScenarioId     int ,
@InvestmentId   int ,
@TargetIRR      decimal (18,2),
@TargetExitValue     decimal(18,2) ,
@GSInvestmentId int out
 
   
)  
  
As  
  
BEGIN  

BEGIN TRY

DECLARE @ErrorText NVARCHAR(MAX) =''

If  @TargetIRR = 0 or @TargetIRR is null
begin
SET @ErrorText = 'Please enter valid Target IRR'
RAISERROR (@ErrorText, 16, 1)

end

If  @TargetExitValue is null or @TargetExitValue = 0
begin
SET @ErrorText = 'Please enter valid Target ExitValue'
RAISERROR (@ErrorText, 16, 1)
end
--declare @UserAlias      nvarchar(250)  ='admin'
--declare @FundId         int =  44
--declare @ScenarioId     int =  143
--declare @InvestmentId   int  = 203
--declare @TargetIRR      decimal (18,2) = 20
--declare @TargetExitValue     decimal(18,2)  = 3500100
--declare @GSInvestmentId int
--declare @GSInvestmentId int out
--target date '2029-01-07' 
   
DECLARE @cashflowdetails as table (
 FundID INT
,ScenarioId INT
,InvestmentId INT
, InvestmentCashFlowTypeId int
,EventDate DateTime
,Equity Decimal (18,2)

)
declare @MindateAdd date = ( select min(EventDate)  from [OPGC].[OpgcInvestmentCashFlow]   where InvestmentCashflowTypeId  = 1 and 
  FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentId and Isdeleted=0  )
declare @Invesmentname nvarchar(250) = (select InvestmentName from [OPGC].[OpgcInvestment] where FundID = @FundId and InvestmentId =@InvestmentId and Isdeleted = 0)

declare  @TargetIRR1 decimal(18,2) = ( select 1 + (@TargetIRR/100))


declare @InvesmentIdBase as table ( Id int)

declare @ExitValueCheck  int 


;with investmentBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdBase
select A.InvestmentId from investmentBaseInitial A
join investmentBaseExit B
on A.InvestmentId =B.InvestmentId

--set @ExitValueCheck = (Select COUNT (1) from @InvesmentIdBase)

--------insert target investment id --------------------------
insert into @InvesmentIdBase
select @InvestmentId

--select * from @InvesmentIdBase


Declare @MinDate table 
( FundId int , 
  ScenarioId int , 
  InvestmentId int,
  MinEvenDate date
)




;with mindate as
(
select FundId ,ScenarioId ,InvestmentId ,EventDate
from [OPGC].[OpgcInvestmentCashFlow]
where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentCashflowTypeId in (1,2,4,6) and InvestmentId in ( select Id from @InvesmentIdBase ) and Isdeleted = 0
)

insert into @MinDate
select FundId ,ScenarioId ,InvestmentId ,Min(EventDate)
from mindate
group by FundId ,ScenarioId ,InvestmentId

--select * from @MinDate


Declare @EventCashFlow table
(
 FundId	   int
,ScenarioId	int
,InvestmentId	Int
,InvesmentName nvarchar(250)
,InvestmentCashflowTypeId int
,EventDate	Date
,Equity	Decimal
,IsSelectedInvestment	bit
,MinDate	Date
)

insert into @EventCashFlow

select A.FundId , A.ScenarioId , A.InvestmentId, B.InvestmentName ,A.InvestmentCashflowTypeId
, A.EventDate ,
 case when A.InvestmentCashflowTypeId IN ( 1,2,4,6) then - A.Equity else A.Equity end as Equity ,
case when A.InvestmentId = @InvestmentId then 1 else 0 end as IsSelectedInvestment
,C.MinEvenDate
from [OPGC].[OpgcInvestmentCashFlow] A
join [OPGC].[OpgcInvestment] B
on A.FundId = B.FundID and A.InvestmentId = B.InvestmentId
join @MinDate C
on A.InvestmentId = C.InvestmentId
where A.FundId = @FundId and A.ScenarioId = @ScenarioId and A.InvestmentId in ( select Id from @InvesmentIdBase ) and A.Isdeleted = 0

--select * from @EventCashFlow
insert into @EventCashFlow

select @FundId , @ScenarioId , @InvestmentId , @Invesmentname , 3 , Null , @TargetExitValue ,1,null


--select * from @EventCashFlow

----------------------------------inserting GIRR---------------------------------------------------------
insert into @cashflowdetails
(
 FundID 
,ScenarioId 
,InvestmentId 
, InvestmentCashFlowTypeId 
,EventDate 
,Equity 

)

select 
 FundId	   
,ScenarioId	
,InvestmentId	
,InvestmentCashflowTypeId 
,EventDate
,Equity
from @EventCashFlow where EventDate is not null
----------------------------------------------------------------------------------------------------------------------------------


; with YearDiff as 
(
select 
 FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
--, case when IsSelectedInvestment =0  then datediff(day,MinDate ,EventDate) / 365.2425 
--       else datediff(day,MinDate , @TargetDate)/ 365.2425 end  as  YearDiffernce 
,cast ( datediff(day,MinDate ,EventDate) / 365.2425 as decimal(18,2))  as YearDiffernce 
,   @TargetIRR1 as  TargetIRR 
--,cast (POWER(@TargetIRR,YearDiffernce) as float)
from @EventCashFlow
)
, DcValue as 
(
select 
 FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
, YearDiffernce 
,  TargetIRR 
,cast (POWER(TargetIRR,YearDiffernce) as decimal(18,2)) as DcValue
from YearDiff
)


--select * from DcValue

, calcExitvalue as
(
select 
 FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,   YearDiffernce 
,    TargetIRR 
, DCvalue
, cast (case when InvestmentCashflowTypeId in (3,5,7) then Equity / DCValue else 0 end as decimal(18,2)) as CalExitValue
--, case when InvestmentCashflowTypeId in (1,2,4,6) then SUM(Equity) else 0 end as SumofInvesment 
from DCValue
)

--select * from calcExitvalue

,TotalCalExitValue as
(
select 
 FundId	   
,ScenarioId	
,SUM(CalExitValue) as SumofTotalCalcExitValue
from calcExitvalue
group by  FundId,ScenarioId	
)



--select * from calcExitvalue
,sumofInvestment as
( 
select  
FundId	   
,ScenarioId	
, case when InvestmentCashflowTypeId  IN (1,2,4,6) then SUM (Equity )* -1 else 0 end as sumofinvestment
, case when InvestmentCashflowTypeId  IN (3,5,7) then SUM (Equity ) else 0 end as sumofExit
from @EventCashFlow
group by FundId	,ScenarioId	,InvestmentCashflowTypeId
)

--select * from sumofInvestment
, TotalValue as
(
select  
FundId	   
,ScenarioId	
, sum (sumofinvestment) as sumofinvestment
--, SUM( sumofExit) as sumofExit
from sumofInvestment
group by FundId	,ScenarioId	
)

--select * from TotalValue

,joinValue as
(
select 
 A.FundId	   
,A.ScenarioId	
,A.InvestmentId	
,A.InvesmentName 
,A.InvestmentCashflowTypeId 
,A.EventDate
,A.Equity
,A.IsSelectedInvestment
,A.MinDate	
,A.YearDiffernce 
,A.TargetIRR 
,A.DCvalue
,A.CalExitValue
,B.sumofinvestment
,C.SumofTotalCalcExitValue
from calcExitvalue A
left join TotalValue B
on A.FundId = B.FundId and A.ScenarioId = B.ScenarioId
left join TotalCalExitValue C 
on A.FundId = C.FundId and A.ScenarioId = C.ScenarioId
)

--select * from joinValue

,differenceValue as
(
select 
 FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,YearDiffernce 
,TargetIRR 
,DCvalue
,CalExitValue
,sumofinvestment
,SumofTotalCalcExitValue
,cast (case when IsSelectedInvestment = 1  and EventDate is null then (sumofinvestment - SumofTotalCalcExitValue ) else 0 end as decimal(18,2))  as DiffSum
from joinValue where EventDate is null
)

--select * from differenceValue

,divideExitValue as
(
select 
 FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment
,MinDate	
,YearDiffernce 
,TargetIRR 
,DCvalue
,CalExitValue
,sumofinvestment
,SumofTotalCalcExitValue
,DiffSum
, cast( Equity / DiffSum  as decimal (18,2) ) as DivedeExitValue
, cast ( log ( cast( Equity / DiffSum  as decimal (18,2) ) , TargetIRR ) * 365 as decimal (18,2) ) as NoOfDays
,@MindateAdd as MinDateADD
from differenceValue
)

--select * from divideExitValue
,TargetDate as
(
select 
 FundId	   
,ScenarioId	
,InvestmentId	
,InvesmentName 
,InvestmentCashflowTypeId 
,EventDate
,Equity
,IsSelectedInvestment	
,TargetIRR 
,sumofinvestment
,SumofTotalCalcExitValue
,DiffSum
,  DivedeExitValue
,  NoOfDays 
, cast (dateadd (day ,NoOfDays ,MinDateADD) as date) as TargetDate
from divideExitValue
)

--select * from TargetDate

---------------------Girr---------------------------------------------------------------

insert into @cashflowdetails
(
 FundID 
,ScenarioId 
,InvestmentId 
, InvestmentCashFlowTypeId 
,EventDate 
,Equity 

)
select 
 FundId	   
,ScenarioId	
,InvestmentId	
,3 
,TargetDate
,@TargetExitValue
from TargetDate

--select * from @cashflowdetails
DECLARE @SnapshotDate Datetime = GETDATE()  

DECLARE @resultcount INT
DECLARE @Test [OPGC].[GIRRTableTEST] -- [OPGC].[GIRRTable]

INSERT  @Test
SELECT  Equity , EventDate FROM @cashflowdetails

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @fundid ,@ScenarioId, 0, 
        case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 
		     Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
        @SnapshotDate  




 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;



SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @ScenarioId  and SnapshotDate = @SnapshotDate and InvestmentID =0)

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@ScenarioId, 0,0.0 AS GIRR, @SnapshotDate
END

DELETE FROM @Test

declare @TotalGIRR decimal(18,2) = ( select GIRR  FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate  )
--select @TotalGIRR as TotalGirr
--select @TargetIRR

declare  @TotalGIRRNull decimal(18,2) = ( select Isnull( @TotalGIRR , 0.00) )


--select @TotalGIRRNull

--SELECT * FROM OPGC.OPGCResultGIRR



declare @DiffernceIRR decimal(6,2) = (select @TargetIRR - @TotalGIRR)

declare @FinalExitDate date = (select EventDate from @cashflowdetails where InvestmentId = @InvestmentId and InvestmentCashFlowTypeId = 3)


if @DiffernceIRR between -1.00 and 1.00
begin
insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
(  
FundId
,ScenarioId
,InvestmentId
,IRR
,ExitDate
,Exitvalue 
,CreatedBy
,CreatedOn
)

select     
 @FundId         
,@ScenarioId     
,@InvestmentId
,@TargetIRR
,@FinalExitDate   
,@TargetExitValue 
,@UserAlias  
,getdate()
end

else
begin 
insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
(  
FundId
,ScenarioId
,InvestmentId
,IRR
,ExitDate
,Exitvalue 
,CreatedBy
,CreatedOn
,CalcIRR
)

select     
 @FundId         
,@ScenarioId     
,@InvestmentId
,@TargetIRR
,@FinalExitDate   
,@TargetExitValue 
,@UserAlias  
,getdate()
,@TotalGIRRNull
end


set @GSInvestmentId = ( select top 1 GsInvestmentId from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentID order by 1 desc )

delete from OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate



END TRY  
BEGIN CATCH  
 DECLARE @ErrorNumber INT  
 DECLARE @Severity  INT  
 DECLARE @State   INT   
 DECLARE @Procedure  NVARCHAR(250)  
 DECLARE @LineNumber  INT  
 DECLARE @Message  NVARCHAR(MAX)  
 DECLARE @Originator NVARCHAR(250)   
 SELECT   
  @ErrorNumber = ERROR_NUMBER(),  
  @Severity = ERROR_SEVERITY(),  
  @State = ERROR_STATE(),   
  @Procedure = ERROR_PROCEDURE(),  
  @LineNumber = ERROR_LINE(),   
  @Message = ERROR_MESSAGE()     
 EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message,   
       'Database', null, null,null                
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END         
END CATCH
END

