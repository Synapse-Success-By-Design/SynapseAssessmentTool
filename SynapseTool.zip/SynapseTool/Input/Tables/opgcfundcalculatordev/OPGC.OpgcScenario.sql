SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcScenario](
	[ScenarioId] [int] IDENTITY(1,1) NOT NULL,
	[ScenarioName] [nvarchar](150) NULL,
	[FundID] [int] NULL,
	[ScenarioDescription] [nvarchar](50) NULL,
	[IsBaseline] [bit] NULL,
	[CreatedBy] [nvarchar](50) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NULL,
	[Isdeleted] [bit] NULL,
	[SysStartTime] [datetime2](7) GENERATED ALWAYS AS ROW START NOT NULL,
	[SysEndTime] [datetime2](7) GENERATED ALWAYS AS ROW END NOT NULL,
	[CopiedFrom] [int] NULL,
	[CommittedCapital] [decimal](30, 2) NULL,
	[OffsetsByQuarter] [decimal](30, 2) NULL,
	[OtherPartnershipFeesByQuarter] [decimal](30, 2) NULL,
	[FundInceptionDate] [datetime] NULL,
	[ManualStepdownDate] [datetime] NULL,
	[LPPreferredReturnPercent] [decimal](5, 2) NULL,
	[LPFinalSharePercent] [decimal](5, 2) NULL,
	[GPPreferredReturnPercent] [decimal](5, 2) NULL,
	[ManagementFeePercent] [decimal](5, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[ScenarioId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([SysStartTime], [SysEndTime])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [OPGC].[OpgcScenario_History] )
)

ALTER TABLE [OPGC].[OpgcScenario] ADD  CONSTRAINT [df_BaseLine]  DEFAULT ((0)) FOR [IsBaseline]
ALTER TABLE [OPGC].[OpgcScenario] ADD  CONSTRAINT [df_OpgcScenario_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
ALTER TABLE [OPGC].[OpgcScenario] ADD  DEFAULT ((0)) FOR [Isdeleted]
ALTER TABLE [OPGC].[OpgcScenario] ADD  DEFAULT (getutcdate()) FOR [SysStartTime]
ALTER TABLE [OPGC].[OpgcScenario] ADD  DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) FOR [SysEndTime]
ALTER TABLE [OPGC].[OpgcScenario]  WITH CHECK ADD FOREIGN KEY([FundID])
REFERENCES [OPGC].[OpgcFund] ([FundId])
