SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[MSSQL_TemporalHistoryFor_942626401](
	[InvestmentId] [int] NOT NULL,
	[InvestmentName] [nvarchar](250) NOT NULL,
	[Address] [nvarchar](500) NULL,
	[IndustryId] [int] NOT NULL,
	[CountryId] [int] NOT NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
	[ValidFrom] [datetime2](0) NOT NULL,
	[ValidTo] [datetime2](0) NOT NULL,
	[Isdeleted] [bit] NULL,
	[FundID] [int] NOT NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)

