SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcFund](
	[FundId] [int] IDENTITY(1,1) NOT NULL,
	[FundName​] [nvarchar](100) NOT NULL,
	[TotalInvestment​] [decimal](30, 2) NULL,
	[TotalRealized​] [decimal](30, 2) NULL,
	[TotalUnrealized​] [decimal](30, 2) NULL,
	[Description​] [nvarchar](500) NULL,
	[ExpenseCap​] [decimal](30, 2) NULL,
	[ManualStepdownDate​] [datetime] NULL,
	[LimitedPartnerPercent​] [decimal](30, 2) NULL,
	[ManagementFeePercent​] [decimal](30, 2) NULL,
	[CreatedBy​] [nvarchar](50) NOT NULL,
	[CreatedOn​] [datetime] NOT NULL,
	[ModifiedBy​] [nvarchar](50) NULL,
	[ModifiedOn​] [datetime] NULL,
	[ValidFrom] [datetime2](0) GENERATED ALWAYS AS ROW START NOT NULL,
	[ValidTo] [datetime2](0) GENERATED ALWAYS AS ROW END NOT NULL,
	[CommittedCapital] [decimal](30, 2) NULL,
	[OffsetsByQuarter] [decimal](30, 2) NULL,
	[OtherPartnershipFeesByQuarter] [decimal](30, 2) NULL,
	[FundInceptionDate] [datetime] NULL,
	[LPPreferredReturnPercent] [decimal](5, 2) NULL,
	[LPFinalSharePercent] [decimal](5, 2) NULL,
	[GPPreferredReturnPercent] [decimal](5, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[FundId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UC_Fund] UNIQUE NONCLUSTERED 
(
	[FundName​] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [OPGC].[OPGC.OpgcFundHistory] )
)

ALTER TABLE [OPGC].[OpgcFund] ADD  CONSTRAINT [df_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn​]
ALTER TABLE [OPGC].[OpgcFund] ADD  CONSTRAINT [DF_ValidFrom1]  DEFAULT (dateadd(second,(-1),sysutcdatetime())) FOR [ValidFrom]
ALTER TABLE [OPGC].[OpgcFund] ADD  CONSTRAINT [DF_ValidTo1]  DEFAULT ('9999.12.31 23:59:59.99') FOR [ValidTo]
