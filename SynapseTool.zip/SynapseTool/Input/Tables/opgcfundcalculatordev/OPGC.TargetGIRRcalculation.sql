SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[TargetGIRRcalculation](
	[Exitvalue] [decimal](18, 2) NULL,
	[Snapshotdate] [datetime] NULL,
	[CalulatedGIRR] [decimal](18, 2) NULL,
	[TagetGIRR] [decimal](18, 2) NULL,
	[TargetDate] [datetime] NULL
) ON [PRIMARY]

