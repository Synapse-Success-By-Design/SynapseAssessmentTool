CREATE TYPE [dbo].[OrderNumber] FROM [nvarchar](25) NULL
