SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
Create PROCEDURE [OPGC].[USP_Insert_GoalSeek_Investment_CalculateIRR_BK] --'DB Team' , 42 , 123 , 165,5,'02-24-2026',null
(  

@UserAlias      nvarchar(250),
@FundId         int,
@ScenarioId     int ,
@InvestmentId   int ,
@TargetIRR      decimal (18,2),
@TargetDate     date ,
@GSInvestmentId int out
 
   
)  
  
As  
  
BEGIN  

BEGIN TRY

DECLARE @ErrorText NVARCHAR(MAX) =''

declare @InvesmentIDCheckfor1 int

If  @TargetIRR = 0 or @TargetIRR is null
begin
SET @ErrorText = 'Please enter valid Target IRR'
RAISERROR (@ErrorText, 16, 1)

end

If  @TargetDate is null 
begin
SET @ErrorText = 'Please enter valid Target Date'
RAISERROR (@ErrorText, 16, 1)
end


declare  @TargetIRR1 decimal(18,2) = ( select 1 + (@TargetIRR/100))




insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
(  
FundId
,ScenarioId
,InvestmentId
--,MOIC
,IRR
,ExitDate
--,Exitvalue 
,CreatedBy
,CreatedOn
)

select     
 @FundId         
,@ScenarioId     
,@InvestmentId   
--,0.00
,@TargetIRR
,@TargetDate   
--, @TargetExitValue 
,@UserAlias  
,getdate()


------------------------------------------------------------------------------------------------------------

--declare @FundId        int = 25
--Declare @ScenarioId    int = 120
--Declare @InvestmentId  int = 100
--declare @GSInvestmentId int

declare @InvesmentIdBase as table ( Id int)

declare @ExitValueCheck  int 


;with investmentBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdBase
select A.InvestmentId from investmentBaseInitial A
join investmentBaseExit B
on A.InvestmentId =B.InvestmentId

--set @ExitValueCheck = (Select COUNT (1) from @InvesmentIdBase)

--------insert target investment id --------------------------
insert into @InvesmentIdBase
select @InvestmentId

--select * from @InvesmentIdBase


Declare @MinDate table 
( FundId int , 
  ScenarioId int , 
  InvestmentId int,
  MinEvenDate date
)




;with mindate as
(
select FundId ,ScenarioId ,InvestmentId ,EventDate
from [OPGC].[OpgcInvestmentCashFlow]
where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentCashflowTypeId in (1,2,4,6) and InvestmentId in ( select Id from @InvesmentIdBase ) and Isdeleted = 0
)

insert into @MinDate
select FundId ,ScenarioId ,InvestmentId ,Min(EventDate)
from mindate
group by FundId ,ScenarioId ,InvestmentId

--select * from @MinDate


Declare @EventCashFlow table
(
 FundId	   int
,ScenarioId	int
,InvestmentId	Int
,InvesmentName nvarchar(250)
,InvestmentCashflowTypeId int
,EventDate	Date
,Equity	Decimal
,IsSelectedInvestment	bit
,MinDate	Date
)

insert into @EventCashFlow

select A.FundId , A.ScenarioId , A.InvestmentId, B.InvestmentName ,A.InvestmentCashflowTypeId
, A.EventDate ,
 case when A.InvestmentCashflowTypeId IN ( 1,2,4,6) then - A.Equity else A.Equity end as Equity ,
case when A.InvestmentId = @InvestmentId then 1 else 0 end as IsSelectedInvestment
,C.MinEvenDate
from [OPGC].[OpgcInvestmentCashFlow] A
join [OPGC].[OpgcInvestment] B
on A.FundId = B.FundID and A.InvestmentId = B.InvestmentId
join @MinDate C
on A.InvestmentId = C.InvestmentId
where A.FundId = @FundId and A.ScenarioId = @ScenarioId and A.InvestmentId in ( select Id from @InvesmentIdBase ) and A.Isdeleted = 0

set @InvesmentIDCheckfor1 = (Select COUNT (1) from @InvesmentIdBase)

if @InvesmentIDCheckfor1 = 1

begin
;with YearDiff as
(
select FundId , ScenarioId ,InvestmentId ,InvesmentName , InvestmentCashflowTypeId ,EventDate ,Equity ,IsSelectedInvestment ,MinDate 
,case when InvestmentCashflowTypeId IN (3,5,7) then  DATEDIFF ( year ,MinDate  , EventDate ) else 0 End as YearDifference
from @EventCashFlow
--order by InvesmentName,InvestmentCashflowTypeId asc
)

--select * from YearDiff

, fundsummary AS (

select FundId , ScenarioId ,InvestmentId ,InvesmentName , InvestmentCashflowTypeId ,EventDate ,Equity ,
       IsSelectedInvestment ,MinDate , YearDifference
from YearDiff
)

--select * from fundsummary

, IRRCalc AS (
select GsInvestmentId , FundId,ScenarioId, IRR ,[ExitDate]
,row_number() OVER( Partition by FundId,ScenarioId order by [GsInvestmentId] desc ) Lastest
from [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
where  FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentId and IRR > 0 
 
)

--select * from IRRCalc

, FundIRR AS (


select rc.GsInvestmentId
    , f.FundId,f.InvestmentId,f.InvesmentName,f.ScenarioId
	, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6), f.EventDate, NULL) ) InvestmentDate
	, MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))  ExitDate
	, SUM(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) ,f. Equity, NULL) )*-1 InvestmentSUM
	, SUM(IIF(f.InvestmentCashflowTypeId  IN( 3,5,7) , f.Equity, NULL) )  ExitSUM
	, MAX(ROUND(IIF(ISNULL(rc.IRR,0)>0 ,((rc.IRR/100)+1),0),2)) IRR   --1+IRR
	, CAST(datediff(dd, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) , f.EventDate, NULL) ),MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))) as float)/365 [N]   ---no of years and days [InvestmentDate - ExitDate]
    , CAST(POWER(MAX(ROUND(IIF(ISNULL(rc.IRR,0)>0 ,((rc.IRR/100)+1),0),2)),CAST(datediff(dd, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) , f.EventDate, NULL) ) ,MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))) as float)/365) AS float) DCValue --- [ power ( (1+IRR) , N) ] 
	,IIF(SUM(IIF(f.InvestmentCashflowTypeId  IN( 3,5,7), f.Equity, NULL) ) IS NOT NULL, (SUM(IIF(f.InvestmentCashflowTypeId  IN( 3,5,7), f.Equity, NULL) ) / CAST(POWER(MAX(ROUND(IIF(ISNULL(rc.IRR,0)>0 ,((rc.IRR/100)+1),0),2)),CAST(datediff(dd, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) , f.EventDate, NULL) ) ,MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))) as float)/365) AS float)),0) 	[CALExitIRRValue] --- [ ExitSum + ( ExitSum /  DCValue ) ] 

FROM fundsummary f
Left Join IRRCalc rc ON rc.FundId = f.FundId and rc.ScenarioId = f.ScenarioId  and rc.lastest = 1
group by rc.GsInvestmentId , f.FundId,f.InvestmentId,f.InvesmentName,f.ScenarioId
)


--select * from FundIRR



, FundDetail as (
SELECT f.GsInvestmentId
,f.FundId
,f.ScenarioId
, SUM(InvestmentSUM) FUNDInvestment
,SUM([CALExitIRRValue]) [FUNDCALExitIRRValue]
,SUM(IIF(ExitSUM is null , 0 , 0 )) InvestmentExitSUM
,SUM(IIF(ExitSUM IS NULL,0, [N])) InvestmentN
,SUM(IIF(ExitSUM IS NULL,0, DCValue)) InvestmentDCValue
FROM FundIRR f
group by f.GsInvestmentId,  f.FundId,f.ScenarioId

)

--select * from FundDetail

, FinalIRR as
(

select fd.GsInvestmentId 
    ,f.FundId
	,f.InvestmentId
	,f.InvesmentName
	,f.ScenarioId
	,f.InvestmentDate
	,f.ExitDate
	,f.IRR
	,f.[N]
	,f.DCValue
	--,fd.InvestmentExitSUM/fd.InvestmentDCValue [2]  -- [FUNDCALExitIRRValue]
	--, fd.FUNDInvestment - fd.[FUNDCALExitIRRValue] [3]
	--, (fd.FUNDInvestment - fd.[FUNDCALExitIRRValue])*f.dcvalue [3]
	,IIF(f.[CALExitIRRValue] = 0 or f.[CALExitIRRValue] is null ,((fd.FUNDInvestment)*f.dcvalue/**f.IRR*/ - FD.InvestmentExitSUM *f.dcvalue),f.[CALExitIRRValue])  [CALExitIRRValue]
	
	,fd.FUNDInvestment
	,fd.[FUNDCALExitIRRValue]
	,fd.InvestmentN
	,fd.InvestmentDCValue
	,fd.InvestmentExitSUM
	--,fd.InvestmentExitSUM - fd.InvestmentN  AS exitv
from FundIRR f
LEFT JOIN FundDetail fd on fd.FundId = f.FundId and fd.ScenarioId = f.ScenarioId
where f.InvestmentId = @InvestmentId
)

--select * from FinalIRR 

update A
set A.ExitValue = B.CALExitIRRValue
from [OPGC].[OpgcGoalSeekInvestmentcashflowType] A
join  FinalIRR B
on A.GsInvestmentId = B.GsInvestmentId and A.FundId = B.FundId and A.ScenarioId = B.ScenarioId and A.InvestmentId = B.InvestmentId 
where A.InvestmentId = @InvestmentId

set @GSInvestmentId = ( select top 1 GsInvestmentId from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentID order by 1 desc )
----select @GSInvestmentId

end
else 
begin

;with YearDiff as
(
select FundId , ScenarioId ,InvestmentId ,InvesmentName , InvestmentCashflowTypeId ,EventDate ,Equity ,IsSelectedInvestment ,MinDate 
,case when InvestmentCashflowTypeId IN (3,5,7) then  DATEDIFF ( year ,MinDate  , EventDate ) else 0 End as YearDifference
from @EventCashFlow
--order by InvesmentName,InvestmentCashflowTypeId asc
)

--select * from YearDiff

, fundsummary AS (

select FundId , ScenarioId ,InvestmentId ,InvesmentName , InvestmentCashflowTypeId ,EventDate ,Equity ,
       IsSelectedInvestment ,MinDate , YearDifference
from YearDiff
)

--select * from fundsummary

, IRRCalc AS (
select GsInvestmentId , FundId,ScenarioId,InvestmentId, IRR ,[ExitDate]
,row_number() OVER( Partition by FundId,ScenarioId order by [GsInvestmentId] desc ) Lastest
from [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
where IRR > 0 
 
)

--select * from IRRCalc

, FundIRR AS (


select rc.GsInvestmentId
    , f.FundId,f.InvestmentId,f.InvesmentName,f.ScenarioId
	, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6), f.EventDate, NULL) ) InvestmentDate
	, MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))  ExitDate
	, SUM(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) ,f. Equity, NULL) )*-1 InvestmentSUM
	, SUM(IIF(f.InvestmentCashflowTypeId  IN( 3,5,7) , f.Equity, NULL) )  ExitSUM
	--, MAX(ROUND(IIF(ISNULL(rc.IRR,0)>0 ,((rc.IRR/100)+1),0),2)) IRR   --1+IRR
	, @TargetIRR1 as IRR
	, CAST(datediff(dd, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) , f.EventDate, NULL) ),MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))) as float)/365 [N]   ---no of years and days [InvestmentDate - ExitDate]
    --, CAST(POWER(MAX(ROUND(IIF(ISNULL(rc.IRR,0)>0 ,((rc.IRR/100)+1),0),2)),CAST(datediff(dd, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) , f.EventDate, NULL) ) ,MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))) as float)/365) AS float) DCValue --- [ power ( (1+IRR) , N) ] 
    , CAST(POWER(@TargetIRR1,CAST(datediff(dd, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) , f.EventDate, NULL) ) ,MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))) as float)/365) AS float) DCValue --- [ power ( (1+IRR) , N) ] 	
	--,IIF(SUM(IIF(f.InvestmentCashflowTypeId  IN( 3,5,7), f.Equity, NULL) ) IS NOT NULL, (SUM(IIF(f.InvestmentCashflowTypeId  IN( 3,5,7), f.Equity, NULL) ) / CAST(POWER(MAX(ROUND(IIF(ISNULL(rc.IRR,0)>0 ,((rc.IRR/100)+1),0),2)),CAST(datediff(dd, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) , f.EventDate, NULL) ) ,MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))) as float)/365) AS float)),0) 	[CALExitIRRValue] --- [ ExitSum + ( ExitSum /  DCValue ) ] 
	,IIF(SUM(IIF(f.InvestmentCashflowTypeId  IN( 3,5,7), f.Equity, NULL) ) IS NOT NULL, (SUM(IIF(f.InvestmentCashflowTypeId  IN( 3,5,7), f.Equity, NULL) ) / CAST(POWER(@TargetIRR1,CAST(datediff(dd, MIN(IIF(f.InvestmentCashflowTypeId  IN ( 1,2,4,6) , f.EventDate, NULL) ) ,MAX(IIF(f.InvestmentCashflowTypeId IN( 3,5,7), f.EventDate,rc.[ExitDate] ))) as float)/365) AS float)),0) 	[CALExitIRRValue] --- [ ExitSum + ( ExitSum /  DCValue ) ] 

FROM fundsummary f
Left Join IRRCalc rc ON rc.FundId = f.FundId and rc.ScenarioId = f.ScenarioId and f.InvestmentId = rc.InvestmentId and rc.lastest = 1
group by rc.GsInvestmentId , f.FundId,f.InvestmentId,f.InvesmentName,f.ScenarioId
)


--select * from FundIRR



, FundDetail as (
SELECT 
 f.FundId
,f.ScenarioId
, SUM(InvestmentSUM) FUNDInvestment
,SUM([CALExitIRRValue]) [FUNDCALExitIRRValue]
,SUM(ExitSUM) InvestmentExitSUM
,SUM(IIF(ExitSUM IS NULL,0, [N])) InvestmentN
,SUM(IIF(ExitSUM IS NULL,0, DCValue)) InvestmentDCValue
FROM FundIRR f
group by   f.FundId,f.ScenarioId

)

--select * from FundDetail

, FinalIRR as
(

select f.GsInvestmentId 
    ,f.FundId
	,f.InvestmentId
	,f.InvesmentName
	,f.ScenarioId
	,f.InvestmentDate
	,f.ExitDate
	,f.IRR
	,f.[N]
	,f.DCValue
	--,fd.InvestmentExitSUM/fd.InvestmentDCValue [2]  -- [FUNDCALExitIRRValue]
	--, fd.FUNDInvestment - fd.[FUNDCALExitIRRValue] [3]
	--, (fd.FUNDInvestment - fd.[FUNDCALExitIRRValue])*f.dcvalue [3]
	--,IIF(f.[CALExitIRRValue] = 0 ,((fd.FUNDInvestment)*f.IRR*f.dcvalue) - FD.InvestmentExitSUM,f.[CALExitIRRValue])  [CALExitIRRValue]
	,IIF(f.[CALExitIRRValue] = 0 or f.[CALExitIRRValue] is null ,((fd.FUNDInvestment/**f.IRR*/ - fd.[FUNDCALExitIRRValue]) *f.dcvalue),f.[CALExitIRRValue])  [CALExitIRRValue]
	,fd.FUNDInvestment
	,fd.[FUNDCALExitIRRValue]
	,fd.InvestmentN
	,fd.InvestmentDCValue
	,fd.InvestmentExitSUM
	--,fd.InvestmentExitSUM - fd.InvestmentN  AS exitv
from FundIRR f
LEFT JOIN FundDetail fd on fd.FundId = f.FundId and fd.ScenarioId = f.ScenarioId
where f.InvestmentId = @InvestmentId
)

--select * from FinalIRR 


update A
set A.ExitValue = B.CALExitIRRValue
from [OPGC].[OpgcGoalSeekInvestmentcashflowType] A
join  FinalIRR B
on A.GsInvestmentId = B.GsInvestmentId and A.FundId = B.FundId and A.ScenarioId = B.ScenarioId and A.InvestmentId = B.InvestmentId 
where A.InvestmentId = @InvestmentId

set @GSInvestmentId = ( select top 1 GsInvestmentId from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId = @InvestmentID order by 1 desc )

--select @GSInvestmentId



End

  
  
  
END TRY  
BEGIN CATCH  
 DECLARE @ErrorNumber INT  
 DECLARE @Severity  INT  
 DECLARE @State   INT   
 DECLARE @Procedure  NVARCHAR(250)  
 DECLARE @LineNumber  INT  
 DECLARE @Message  NVARCHAR(MAX)  
 DECLARE @Originator NVARCHAR(250)   
 SELECT   
  @ErrorNumber = ERROR_NUMBER(),  
  @Severity = ERROR_SEVERITY(),  
  @State = ERROR_STATE(),   
  @Procedure = ERROR_PROCEDURE(),  
  @LineNumber = ERROR_LINE(),   
  @Message = ERROR_MESSAGE()     
 EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message,   
       'Database', null, null,null                
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END         
END CATCH
END
  
