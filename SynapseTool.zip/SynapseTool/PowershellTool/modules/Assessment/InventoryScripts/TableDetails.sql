-- Table Analysis Report
;WITH SPUpdatingTables as (
select Object_name(referenced_major_id) as TableName, stuff((
            select DISTINCT ', ' + OBJECT_NAME(t2.object_id) 
            from sys.sql_dependencies t2 WITH(NOLOCK)
            where t.referenced_major_id = t2.referenced_major_id and is_updated=1
            for xml path(''), type
            ).value('(./text())[1]', 'varchar(max)')
            , 1, 2, '') AS UpdatedBySPs
from sys.sql_dependencies t WITH(NOLOCK)
where is_updated=1
group by referenced_major_id),
ConstraintsAndIndexes as (
SELECT table_view as TableName, 
SUM(CASE WHEN constraint_type='Default constraint' THEN 1 ELSE 0 END) AS CountDefaultConstraints,
SUM(CASE WHEN constraint_type='Foreign key' THEN 1 ELSE 0 END) AS CountFKConstraints,
SUM(CASE WHEN constraint_type='Unique constraint' THEN 1 ELSE 0 END) AS CountUniqueConstraints,
SUM(CASE WHEN constraint_type='Check constraint' THEN 1 ELSE 0 END) AS CountCheckConstraints,
SUM(CASE WHEN constraint_type in ('Unique clustered index','Unique index') THEN 1 ELSE 0 END) AS CountIndexes,
MAX(CASE WHEN constraint_type='Primary key' THEN details ELSE '' END) AS PrimaryKeyDetails
FROM (
    SELECT t.[name] as table_view, 
        case when c.[type] = 'PK' then 'Primary key'
            when c.[type] = 'UQ' then 'Unique constraint'
            when i.[type] = 1 then 'Unique clustered index'
            when i.type = 2 then 'Unique index'
            end as constraint_type, 
        isnull(c.[name], i.[name]) as constraint_name,
        substring(column_names, 1, len(column_names)-1) as [details]
    FROM sys.objects t WITH(NOLOCK)
        left outer join sys.indexes i WITH(NOLOCK)
            on t.object_id = i.object_id
        left outer join sys.key_constraints c WITH(NOLOCK)
            on i.object_id = c.parent_object_id 
            AND i.index_id = c.unique_index_id
       cross apply (select col.[name] + ', '
                        from sys.index_columns ic
                            inner join sys.columns col
                                on ic.object_id = col.object_id
                                and ic.column_id = col.column_id
                        where ic.object_id = t.object_id
                            AND ic.index_id = i.index_id
                                order by col.column_id
                                for xml path ('') ) D (column_names)
    WHERE is_unique = 1
        AND t.is_ms_shipped <> 1 and t.type='U'
    UNION ALL
    SELECT fk_tab.name as foreign_table,
        'Foreign key',
        fk.name as fk_constraint_name,
        schema_name(pk_tab.schema_id) + '.' + pk_tab.name
    FROM sys.foreign_keys fk WITH(NOLOCK)
        inner join sys.tables fk_tab WITH(NOLOCK)
            on fk_tab.object_id = fk.parent_object_id
        inner join sys.tables pk_tab WITH(NOLOCK)
            on pk_tab.object_id = fk.referenced_object_id
        inner join sys.foreign_key_columns fk_cols WITH(NOLOCK)
            on fk_cols.constraint_object_id = fk.object_id
    UNION ALL
    SELECT t.[name],
        'Check constraint',
        con.[name] as constraint_name,
        con.[definition]
    FROM sys.check_constraints con WITH(NOLOCK)
        left outer join sys.objects t WITH(NOLOCK)
            on con.parent_object_id = t.object_id
        left outer join sys.all_columns col WITH(NOLOCK)
            on con.parent_column_id = col.column_id
            AND con.parent_object_id = col.object_id
       WHERE t.type='U'
    UNION ALL
    SELECT t.[name],
        'Default constraint',
        con.[name],
        col.[name] + ' = ' + con.[definition]
    FROM sys.default_constraints con WITH(NOLOCK)
        left outer join sys.objects t WITH(NOLOCK)
            on con.parent_object_id = t.object_id
        left outer join sys.all_columns col WITH(NOLOCK)
            on con.parent_column_id = col.column_id
            and con.parent_object_id = col.object_id
                           WHERE t.type='U') a
                           Group By table_view)

SELECT DB_NAME() AS DBName,
SH.name AS [SchemaName],
ISNULL(SO.name,' ') AS [TableName],
'' AS [CUR/HIS TBL Availability],
'' AS [TableLayer],
COUNT(DISTINCT p.partition_number) as NumberOfPartitions,
IIF(max(ps.name) is null,'', CONCAT('Partition Scheme : ',max(ps.name),' , Partition Function : ', max(pf.name))) as PartitionDetails,
MAX(p.data_compression_desc) as DataCompression,
MAX(cai.PrimaryKeyDetails) as PrimaryKeyDetails,
MAX(IIF(cai.CountIndexes is null , 0 , cai.CountIndexes)) as CntIndexes,
MAX(IIF(cai.CountFKConstraints is null , 0 , cai.CountFKConstraints)) as CntOfFKConstraints,
MAX(IIF(cai.CountCheckConstraints is null , 0 , cai.CountCheckConstraints)) as CntOfCkConstraints,
MAX(IIF(cai.CountUniqueConstraints is null , 0 , cai.CountUniqueConstraints)) as CntOfUniqConstraints,
MAX(IIF(cai.CountDefaultConstraints is null , 0 , cai.CountDefaultConstraints)) as CntOfDftConstraints,
ISNULL(sum(p.rows),0) AS [RowCount],
((SUM(a.in_row_data_page_count + a.lob_used_page_count + a.row_overflow_used_page_count)*8)/1024) as SizeInMB,
'' as PercentGrowth,
'' as TableIncompabilitiesCount,
'' as [SourceAutomicJob / PlanName],
'' as SSISPackageName,
MAX(sp.UpdatedBySPs) as SourceStoredProcNames,
'' as SourceStoredProcIncompatibilitiesCount,
'' as SourceTriggerIncompatibilityCount,
'' as DependentPowerBIReports,
'' as DependentSSRSReports,
'' as DependentSSASCubes,
'' as [DependentAutomicJob/ PlanNames],
CONCAT(DB_NAME(),'_',SH.Name,'.',SO.name) as PostMigrationTableName,
'' as StructureChangePostMigration,
'' as SchemaMigrationStrategy,
'' as DataMigrationStrategy
FROM  sys.objects SO WITH(NOLOCK)
LEFT join sys.tables s WITH(NOLOCK)
ON SO.object_id = s.object_id
left join sys.partitions p WITH(NOLOCK)
ON p.object_id = s.object_id
LEFT JOIN sys.dm_db_partition_stats a WITH(NOLOCK) 
ON p.partition_id = a.partition_id
LEFT JOIN sys.schemas SH WITH(NOLOCK)
ON s.schema_id = SH.schema_id
LEFT JOIN sys.indexes i WITH(NOLOCK)
ON p.object_id = i.object_id and p.index_id = i.index_id
LEFT JOIN sys.data_spaces ds WITH(NOLOCK) 
ON i.data_space_id = ds.data_space_id
LEFT JOIN sys.partition_schemes ps WITH(NOLOCK) 
ON ds.data_space_id = ps.data_space_id
LEFT JOIN sys.partition_functions pf WITH(NOLOCK) 
ON ps.function_id = pf.function_id
LEFT JOIN ConstraintsAndIndexes cai 
ON cai.TableName=SO.name
LEFT JOIN SPUpdatingTables sp
ON sp.TableName=SO.name
where SO.type_desc in ('USER_TABLE')   
and (a.index_id is null or a.index_id < 2)
GROUP BY SO.name,SO.type_desc,SH.name
order by  [RowCount] desc