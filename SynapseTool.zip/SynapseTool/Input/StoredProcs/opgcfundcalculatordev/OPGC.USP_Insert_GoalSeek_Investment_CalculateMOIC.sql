SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

--2	28	26	3	50.00	0.00	2070-10-15
CREATE PROCEDURE [OPGC].[USP_Insert_GoalSeek_Investment_CalculateMOIC] --'DB Team' , 2 , 28 , 26,50,'2070-10-15',null
(  

@UserAlias      nvarchar(250),
@FundId         int,
@ScenarioId     int ,
@InvestmentId   int ,
@TargetMOIC     decimal (18,2),
@TargetDate     date ,
@GSInvestmentId int out
 
   
)  
  
As  
  
BEGIN  


BEGIN TRY


DECLARE @ErrorText NVARCHAR(MAX) =''

if (@TargetMOIC =0.00)
begin

SET @ErrorText = 'Please enter valid Target MOIC'
RAISERROR (@ErrorText, 16, 1)

end

declare @InvesmentIdBase as table ( Id int)

declare @ExitValueCheck  int 


declare @sumInitial decimal(18,2)
declare @sumexit decimal (18,2)
declare @MOICMultiple decimal (18,2)
declare @TargetExitValue decimal (18,2)

;with investmentBaseInitial as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investmentBaseExit as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and 
  FundId = @FundId and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentIdBase
select A.InvestmentId from investmentBaseInitial A
join investmentBaseExit B
on A.InvestmentId =B.InvestmentId

set @ExitValueCheck = (Select COUNT (1) from @InvesmentIdBase)

--------insert target investment id --------------------------
insert into @InvesmentIdBase
select @InvestmentId

-----------------------------------------------------------

If @ExitValueCheck = 0
begin

set @sumInitial  = ( select  SUM (Equity) as InitialValue  from [OPGC].[OpgcInvestmentCashFlow] 
                                      where InvestmentCashflowTypeId in (1,2,4,6) and 
                                      FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId in ( select Id from @InvesmentIdBase ) and Isdeleted=0  
                                      group by FundId , ScenarioId 
                   )

--select @sumInitial

set @sumexit   = ( select  SUM (Equity) as ExitValue   from [OPGC].[OpgcInvestmentCashFlow] 
                                    where InvestmentCashflowTypeId in (3,5,7,8) and 
                                    FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId in ( select Id from @InvesmentIdBase where Id != @InvestmentId ) and Isdeleted=0  
                                    group by FundId , ScenarioId 
                  )

--select @sumexit


set @TargetExitValue  =  cast ( round(( @sumInitial * @TargetMOIC ),0) as decimal(18,0)) 



end

else
begin

--select * from @InvesmentIdBase
--select * from @InvesmentIdBase where Id != 101

set @sumInitial  = ( select  SUM (Equity) as InitialValue  from [OPGC].[OpgcInvestmentCashFlow] 
                                      where InvestmentCashflowTypeId in (1,2,4,6) and 
                                      FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId in ( select Id from @InvesmentIdBase ) and Isdeleted=0  
                                      group by FundId , ScenarioId 
                    )

--select @sumInitial

set @sumexit   = ( select  SUM (Equity) as ExitValue   from [OPGC].[OpgcInvestmentCashFlow] 
                                    where InvestmentCashflowTypeId in (3,5,7,8) and 
                                    FundId = @FundId and ScenarioId = @ScenarioId and InvestmentId in ( select distinct Id from @InvesmentIdBase  ) and Isdeleted=0  
                                    group by FundId , ScenarioId 
                 )

--select @sumexit


set @MOICMultiple  = ( @sumInitial * @TargetMOIC )

--select @MOICMultiple

set @TargetExitValue   =  cast ( round(( @MOICMultiple - @sumexit),0) as decimal(18,0)) 

end
--select @TargetExitValue


--If @TargetExitValue <= 0 or @TargetExitValue =null
--begin
--SET @ErrorText = 'Negative exit value. Please change Target Fund Gross IRR or Exit Date'
--RAISERROR (@ErrorText, 16, 1)
--end
--else
--begin

insert into [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
( FundId
,ScenarioId
,InvestmentId
,MOIC
,IRR
,ExitDate
,Exitvalue 
,CreatedBy
,CreatedOn
)

select     
 @FundId         
,@ScenarioId     
,@InvestmentId   
,@TargetMOIC
,0.00
,@TargetDate   
, @TargetExitValue 
,@UserAlias  
,getdate()
--end

set @GSInvestmentId = ( select top 1 GsInvestmentId from [OPGC].[OpgcGoalSeekInvestmentcashflowType] order by 1 desc )



END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
							IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END     
END CATCH
END
