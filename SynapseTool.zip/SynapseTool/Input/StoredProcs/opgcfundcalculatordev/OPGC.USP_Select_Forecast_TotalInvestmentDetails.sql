SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
  
CREATE PROCEDURE [OPGC].[USP_Select_Forecast_TotalInvestmentDetails] --'',3,18
(  
  @userAlias NVARCHAR(250)  
 ,@fundId INT  
 ,@scenarioId INT  
   
)  
  
As  
  
BEGIN  
  
--=======================================================   
 --Author         :    <AEGIS Team>      
 --Create Date    :    10/11/2021   
 --Description    :     
--===========================================================   
 --History                    
 --Author         :         Date         Description   
  
--============================================================   

------------------------------------------------New CR for GIRR---------------------------------------------------------------------------------------------------------------

DECLARE @SnapshotDate Datetime = GETDATE()  

DECLARE @resultcount INT
declare @InvesmentId as table ( Id int)



;with investment as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and 
  FundId = @fundid and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, investment1 as
(
select FundId , ScenarioId , InvestmentId   from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and 
  FundId = @fundid and ScenarioId = @ScenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)

insert into @InvesmentId
select A.InvestmentId from investment A
join investment1 B
on A.InvestmentId =B.InvestmentId

--select * from @InvesmentId

DECLARE @cashflowdetails as table (
 FundID INT
,ScenarioId INT
,InvestmentId INT
, InvestmentCashFlowTypeId int
,EventDate DateTime
,Equity Decimal (30,2)

)


insert into @cashflowdetails

select FundId , ScenarioId , 1001  ,  InvestmentCashflowTypeId , EventDate , Equity  --, 0 as ExitValue        
  from [OPGC].[OpgcInvestmentCashFlow] 
  where  FundId = @fundid and ScenarioId = @ScenarioId and Isdeleted=0  and InvestmentId in ( select Id from @InvesmentId )
  
--select * from @cashflowdetails order by EventDate


DECLARE @Test   [OPGC].[GIRRTable] --[OPGC].[GIRRTableTEST]

;with Currentscenariodata as
(
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, -SUM(Equity) Equity FROM @cashflowdetails
WHERE InvestmentCashFlowtypeID in (1,2,4,6) 
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
UNION ALL
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @cashflowdetails
WHERE  InvestmentCashFlowtypeID in (3,5,7,8) 
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
)

--select * from Currentscenariodata


INSERT  @Test
SELECT  Equity , EventDate FROM Currentscenariodata

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @fundid ,@ScenarioId, 0, 
       -- case when CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 
		     --Else CAST(ROUND(/*[OPGC].[CalcGIRR]*/[OPGC].[CalcGIRRTEST](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,  
			 cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
        @SnapshotDate  




 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;



SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @ScenarioId  and SnapshotDate = @SnapshotDate and InvestmentID =0)

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @fundid,@ScenarioId, 0,0.0 AS GIRR, @SnapshotDate
END

DELETE FROM @Test

--------------------------------------------OLd GIRR--------------------------------------------------------------------------------------------------------------------------------------



  
  
--DECLARE @SnapshotDate Datetime = GETDATE()  
  
--------------------------------------------------------------------------
--  DECLARE 
--  @Randomtable AS Table (
--  Eventdate Datetime
-- ,RealizedUnRealizedInvestment DEcimal (18,2)
-- ,Realized DEcimal (18,2)
-- ,Unrealized DEcimal (18,2)
-- )
-- --DECLARE @Fundid INT = 1
--	--	,@ScenarioID INT = 1
--	--	,@SnapshotDate DateTime = Getdate ()

--Insert @Randomtable
--EXEC [OPGC].[USP_Select_Forecast_TotalInvestmentDetails_DetailedView] '',@Fundid ,@ScenarioID 

--DECLARE @cashflowdetails as table (
-- FundID INT
--,ScenarioId INT
--,InvestmentId INT
--,Equity Decimal (18,2)
--,EventDate DateTime
--,InvestmentName Nvarchar (500)
--)

--INSERT INTO @cashflowdetails
--SELECT  @Fundid ,@ScenarioID ,1000,[RealizedUnRealizedInvestment],Eventdate, 'RealizedUnRealizedInvestment' AS InvestmentName FROM @Randomtable
--UNION ALL 
--SELECT  @Fundid ,@ScenarioID ,1001,[Realized],Eventdate, 'Realized' AS InvestmentName FROM @Randomtable
--UNION ALL 
--SELECT  @Fundid ,@ScenarioID ,1002,[UnRealized],Eventdate, 'UnRealized' AS InvestmentName FROM @Randomtable
--ORDER BY Eventdate


--DECLARE @validate as table (
-- Id INT Identity (1,1)
--,InvestmentId INT
--)
--INSERT INTO @validate (InvestmentId)
--SELECT InvestmentId FROM @cashflowdetails GROUP BY InvestmentId
--DECLARE @investmentID int
--DECLARE @min int
--DECLARE @max int
--DECLARE @resultcount INT

--SET @min = (SELECT Min(ID) FROM @validate)
--SET @max = (SELECT Max(ID) FROM @validate)
--SET @investmentID = (Select InvestmentId FROM @validate Where Id = @min)

--DECLARE @Test [OPGC].[GIRRTable]
--WHILE @min <= @max
--BEGIN 

--INSERT  @Test
--SELECT  Equity , EventDate FROM @cashflowdetails
--WHERE FundID = @fundid and ScenarioId = @ScenarioId and InvestmentId = @investmentID

--  SET XACT_ABORT ON; 
--        BEGIN TRY
--        BEGIN TRANSACTION;
--INSERT INTO OPGC.OPGCResultGIRR
-- SELECT @fundid ,@ScenarioId, @investmentID, 
--        Case When CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else isnull(CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT),0.00) End  AS GIRR,
--		@SnapshotDate


-- COMMIT TRANSACTION ;  
--END TRY

--BEGIN CATCH 


--IF @@trancount > 0 ROLLBACK TRANSACTION



--END CATCH ;

--SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @ScenarioId and InvestmentID = @investmentID and SnapshotDate = @SnapshotDate)

--IF @resultcount = 0
--BEGIN 
--INSERT INTO OPGC.OPGCResultGIRR
--SELECT @fundid,@ScenarioId, @investmentID,0.00 AS GIRR, @SnapshotDate
--END

--DELETE FROM @Test
--SET @min = @min + 1
--SET @max = (SELECT Max(ID) FROM @validate)
--SET @investmentID = (Select InvestmentId FROM @validate Where Id = @min)


--END

-------------------------------------------------------------------
--EXEC OPGC.Proc_CalculateGIRR @fundId,@scenarioId,@SnapshotDate  
  
----------------------------------------------------------------------------------------------------------------------------
declare @Invesment  table  
(  FundId int , ScenarioId int, InvestmentId Int , Initial decimal (30,2) , ExitValue decimal(30,2) )

;with InvestmentIdCheck as  
(  
select FundId , ScenarioId , InvestmentId  , sum(Equity) as InitialInvestment --, 0 as ExitValue    
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, ExitIdCheck AS
(
  
  select FundId , ScenarioId  ,InvestmentId,-- 0 as IntialInvestment ,
  sum(Equity) as ExitValue     
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0  
  group by FundId , ScenarioId   , InvestmentId
  )  

insert into @Invesment ( FundId , ScenarioId ,InvestmentId,   Initial , ExitValue )

  select A.FundId , A.ScenarioId  ,A.InvestmentId , A.InitialInvestment , B.ExitValue
     from InvestmentIdCheck A
	 join ExitIdCheck B
	 On A.FundId = B.FundId and A.InvestmentId = B.InvestmentId

declare @InvesmentCheck int = (select COUNT(1) from @Invesment )

-------------------------------------------------------------------------------------------------------------------------------
  
;with Investment as  
(  
select FundId , ScenarioId   , sum(Equity) as InitialInvestment , 0 as ExitValue    
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6,100) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0  
  group by FundId , ScenarioId    
  union all   
  select FundId , ScenarioId  , 0 as IntialInvestment , sum(Equity) as ExitValue     
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8,100) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0  
  group by FundId , ScenarioId   
  )  
, TotalIvestment as  
(  
  select FundId , ScenarioId   , sum( InitialInvestment) as Investment , sum (ExitValue)  as ExitVAlue  
  from Investment A  
   group by FundId , ScenarioId   
)  
  
--select * from TotalIvestment  

 -----------------------------------------------------------------------------------------------------------------   
---------Total Invested   
, Invested as  
(  
select  FundId , ScenarioId ,  
        case when (ExitVAlue >= Investment ) then -Investment else 0.00 end as Realized,  
        case when (ExitVAlue < Investment ) then -Investment else 0.00 end as UnRealized  
  from TotalIvestment  
)  
  
, TotalInvested as  
(  
select   FundId , ScenarioId   ,  
         'Total Invested' as Attribute,  
         cast ( (Realized +  UnRealized) as decimal (30,2) ) as [RealizedandUnRealizedInvestment],   
         Realized,  
      UnRealized  
  from Invested  
)  
  
--select * from TotalInvested  

----------------------------------------------------------------------------------------------------
--UnRealized

, UnRealized as
 
(  
select  FundId , ScenarioId ,  
        case when (ExitVAlue >= Investment ) then 0.00 Else 0.00  end as Realized,  
        case when (ExitVAlue < Investment ) then  ( ExitVAlue - Investment)  else 0.00 end as UnRealized  
  from TotalIvestment  
)  

, TotalUnrealized as  
(  
select   FundId , ScenarioId   ,  
         'Unrealized Value' as Attribute,  
         cast ( (Realized +  UnRealized) as decimal (30,2) ) as [RealizedandUnRealizedInvestment],   
         Realized,  
         UnRealized  
  from UnRealized  
)  
  
--select * from TotalUnrealized  
  
-----------------------------------------------------------------------------------------------------------  
---Realized Proceeds  
, RealizedProceeds as  
(  
select   FundId , ScenarioId   ,  
        case when (ExitVAlue >= Investment ) then ExitVAlue Else 0.00  end as Realized,  
        case when (ExitVAlue < Investment ) then ExitVAlue Else 0.00 end as UnRealized  
  from TotalIvestment A  
  --Inner join TotalIvestment B  
  --on A.FundId = B.FundId and A.ScenarioId =B.ScenarioId  
)  
  
, TotalRealizedProceeds as      
(  
select   FundId , ScenarioId   ,  
         'Realized Proceeds' as Attribute,  
         cast ( (Realized +  UnRealized) as decimal (30,2) ) as [RealizedandUnRealizedInvestment],   
         Realized,  
         UnRealized  
  from RealizedProceeds  
)  
  
--select * from TotalRealizedProceeds  
------------------------------------------------------------------------------------  
-----TotalValue  
, TotalValue as  
(  
    select  
     case when Investment > ExitValue Then (ExitVAlue - Investment) + (ExitVAlue) Else ExitValue End as Realized ,  
     0 as UnRealized  
  from TotalIvestment  
)  
  
, OverallTotalValue as      
(  
     select  
 'Total Value' as Attribute,  
  cast ( (Realized +  UnRealized) as decimal (30,2) ) as [RealizedandUnRealizedInvestment],  
  Realized,  
  UnRealized  
  from TotalValue  
)  
  
--select * from OverallTotalValue  
----------------------------------------------------------------------------------------------  
---Total Gain  
, Gain as   
( select   
     case when Investment < ExitValue Then ExitVAlue - Investment
		WHEN  ExitValue =0 THEN 0.00 
		WHEN ExitValue < Investment THEN - (Investment - ExitValue) End as Realized ,
   0 as UnRealized  
   from TotalIvestment  
)  
  
, TotalGain as        
(  
   select    
       'Total Gain' as Attribute,  
    cast ( (Realized +  UnRealized) as decimal (30,2) ) as [RealizedandUnRealizedInvestment],  
    Realized,  
    UnRealized  
  from Gain  
)  
  
--select * from TotalGain  
----------------------------------------------------------------------------------------------------------------  
--MOIC  
  
,InvestmentId as  
(  
select FundId , ScenarioId , InvestmentId  , sum(Equity) as InitialInvestment --, 0 as ExitValue    
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (1,2,4,6,100) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0  
  group by FundId , ScenarioId    ,InvestmentId
)
, ExitId AS
(
  
  select FundId , ScenarioId  ,InvestmentId,-- 0 as IntialInvestment ,
  sum(Equity) as ExitValue     
  from [OPGC].[OpgcInvestmentCashFlow] 
  where InvestmentCashflowTypeId in (3,5,7,8,100) and FundId = @fundId and ScenarioId = @scenarioId and Isdeleted=0  
  group by FundId , ScenarioId   , InvestmentId
  )  

, InvesmentExit as
(    select  A.FundId , 
             A.ScenarioId  ,
		     A.InvestmentId  , 
		  case when B.FundId is null then 0.00 else  A.InitialInvestment end as  InitialInvestment , 
		  case when B.FundId is null then 0.00 else B.ExitValue end as ExitValue

     from InvestmentId A
	 left join ExitId B
	 On A.FundId = B.FundId and A.InvestmentId = B.InvestmentId

)


--select * from InvesmentExit
, TotalInvestmentExit as 
(

select FundId , ScenarioId  , SUM( InitialInvestment ) as Initial , Sum(ExitValue) as ExitValue
     from InvesmentExit
	 group by FundId , ScenarioId
)

--select * from TotalInvestmentExit

, MOIC as 

(

select    FundId , 
          ScenarioId  , 
		 'MOIC' as Attribute, 
         case when Initial =0 or Initial = 0 then 0.00 else cast ( ( ExitValue / Initial ) as decimal (30,2)) end as [RealizedandUnRealizedInvestment]
     from TotalInvestmentExit
)

--select * from MOIC



---------------------------old moic concept ------------------------------------------------------------------------------------------

--, [MOICRealized&UnRealized] as  
--(  
--    select FundId ,ScenarioId ,
--	      case when Investment = 0 Then 0 
--              when ExitVAlue = 0 Then 0 
--	                else ( ExitVAlue / Investment) End as Realized ,
--		  0 as UnRealized      
-- from TotalIvestment  

--)  
  
----select * from [MOICRealized&UnRealized]  
  
--, TotalMoic as       
--(  
--   select FundId ,ScenarioId ,  
--    'MOIC' as Attribute,    
--    case when Realized < 0 Then - (Realized) Else Realized End as  Realized , 
--    UnRealized  
--   from  [MOICRealized&UnRealized]  
 
--)  
  
----select * from TotalMoic  
 
--, OverallMOIC as
--(
-- select FundId ,ScenarioId ,  
--     Attribute,    
--	 cast ( (Realized +  UnRealized) as decimal (18,2) ) as [RealizedandUnRealizedInvestment],
--     cast (Realized as decimal (18,2) ) as Realized , 
--    UnRealized  
--   from  TotalMoic  
 
--)  

--select * from TotalMoic
---------------------------------------------------------------------------------------------------------------------------------------------  
-- Gross IRR  
 
 -----------------------------------------------New CR for GIRR----------------------------------------------------------------------------------------------------

 ,  GirrCalc as(
		select B.FundId , B.ScenarioId ,    
              'GrossIRR' as Attribute,   
              A.GIRR   
		FROM OPGC.OPGCResultGIRR A
		inner join MOIC B
		on A.FundId = B.FundId and A.ScenarioId = B.ScenarioId
      WHERE SnapshotDate = @SnapshotDate   
)

,TotalGrossIRR as (
SELECT 
       FundId 
      ,ScenarioId 
      ,Attribute
      ,isnull (MAX(GIRR),0)   [RealizedandUnRealizedInvestment]
      , 0.00 as Realized 
      , 0.00 as UnRealized
FROM GirrCalc
GROUP BY FundId ,ScenarioId ,Attribute
)

-----------------------------------------------------------------------------------------------------------------------------------------------------

--, GirrCalc as(
--		select FundId , ScenarioId ,    
--        'GrossIRR' as Attribute,   
--        CASE WHEN InvestmentID = 1000 THEN GIRR END as [Realized&UnRealizedInvestment] ,   
--		CASE WHEN InvestmentID = 1001 THEN GIRR END as Realized ,  
--		CASE WHEN InvestmentID = 1002 THEN GIRR END as UnRealized  
--		FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate   
--),TotalGrossIRR as(
--SELECT 
-- FundId 
--,ScenarioId 
--,Attribute
--,isnull (MAX([Realized&UnRealizedInvestment]),0)   [RealizedandUnRealizedInvestment]
--,isnull (MAX(Realized),0) Realized
--,isnull (MAX(UnRealized),0)   UnRealized
--FROM GirrCalc
--GROUP BY 
-- FundId 
--,ScenarioId 
--,Attribute
--)
  
--select * from TotalGrossIRR  
-----------------------------------------------------------------------------------------------------------------------------------------------  
--To Union all the Attribute  
  


----------------------------------------------------------------------------------------------------------------
--   select   
--        Attribute , isnull([RealizedandUnRealizedInvestment],0.00) as RealizedandUnRealizedInvestment, isnull (Realized,0.00) as Realized , isnull (UnRealized ,0.00)  as UnRealized
--   from  TotalInvested  
  
--Union all  
  
-- select   
--          Attribute , isnull([RealizedandUnRealizedInvestment],0.00) as [RealizedandUnRealizedInvestment] , isnull (Realized,0.00) as Realized , isnull (UnRealized ,0.00)  as UnRealized
--    from TotalUnrealized
  
--Union all  
  
-- select   
--        Attribute , isnull([RealizedandUnRealizedInvestment],0.00) as RealizedandUnRealizedInvestment, isnull (Realized,0.00) as Realized , isnull (UnRealized ,0.00) as UnRealized
--   from   TotalRealizedProceeds   
  
--Union all  
  
-- select   
--        Attribute , isnull([RealizedandUnRealizedInvestment],0.00) as RealizedandUnRealizedInvestment ,isnull (Realized,0.00) as Realized , isnull (UnRealized ,0.00) as UnRealized
--   from   OverallTotalValue   
  
--Union all  
  
-- select   
--        Attribute , isnull([RealizedandUnRealizedInvestment],0.00)   as RealizedandUnRealizedInvestment , isnull (Realized,0.00) as Realized , isnull (UnRealized ,0.00)  as UnRealized
--   from   TotalGain   
  
--Union all  
  
-- select   
--        Attribute , isnull([RealizedandUnRealizedInvestment],0.00) as RealizedandUnRealizedInvestment , 0.00 as Realized , 0.00  as UnRealized
--   from   MOIC  
  
--Union all  
  
-- select   
--        Attribute , isnull([RealizedandUnRealizedInvestment],0.00) as RealizedandUnRealizedInvestment , isnull (Realized ,0.00)   as Realized , isnull (UnRealized ,0.00)   as UnRealized
--   from   TotalGrossIRR  
 ----------------------------------------------------------------------------------
 
   select   
        Attribute , cast ( cast (  isnull( [RealizedandUnRealizedInvestment],0.00 )  as decimal(30,2)) as nvarchar(max) ) as RealizedandUnRealizedInvestment, cast ( cast ( isnull( Realized,0.00)  as decimal(30,2)) as nvarchar(max) )  as Realized , cast ( cast ( isnull( UnRealized,0.00)  as decimal(30,2)) as nvarchar(max) )  as UnRealized
   from  TotalInvested  
  
Union all  
  
 select   
          Attribute , cast ( cast (  isnull( [RealizedandUnRealizedInvestment],0.00 )  as decimal(30,2)) as nvarchar(max) ) as [RealizedandUnRealizedInvestment] , cast ( cast ( isnull( Realized,0.00)  as decimal(30,2)) as nvarchar(max) )  as Realized , cast ( cast ( isnull( UnRealized,0.00)  as decimal(30,2)) as nvarchar(max) )   as UnRealized
    from TotalUnrealized
  
Union all  
  
 select   
        Attribute , cast ( cast (  isnull( [RealizedandUnRealizedInvestment],0.00 )  as decimal(30,2)) as nvarchar(max) ) as RealizedandUnRealizedInvestment, cast ( cast ( isnull( Realized,0.00)  as decimal(30,2)) as nvarchar(max) )  as Realized , cast ( cast ( isnull( UnRealized,0.00)  as decimal(30,2)) as nvarchar(max) ) as UnRealized
   from   TotalRealizedProceeds   
  
Union all  
  
 select   
        Attribute , cast ( cast (  isnull( [RealizedandUnRealizedInvestment],0.00 )  as decimal(30,2)) as nvarchar(max) ) as RealizedandUnRealizedInvestment ,cast ( cast ( isnull( Realized,0.00)  as decimal(30,2)) as nvarchar(max) )  as Realized , cast ( cast ( isnull( UnRealized,0.00)  as decimal(30,2)) as nvarchar(max) )  as UnRealized
   from   OverallTotalValue   
  
Union all  
  
 select   
        Attribute , cast ( cast (  isnull( [RealizedandUnRealizedInvestment],0.00 )  as decimal(30,2)) as nvarchar(max) )  as RealizedandUnRealizedInvestment , cast ( cast ( isnull( Realized,0.00)  as decimal(30,2)) as nvarchar(max) )  as Realized , cast ( cast ( isnull( UnRealized,0.00)  as decimal(30,2)) as nvarchar(max) )   as UnRealized
   from   TotalGain   
  
Union all  
  
 select   
        Attribute ,cast ( cast (  isnull( [RealizedandUnRealizedInvestment],0.00 )  as decimal(30,2)) as nvarchar(max) ) as RealizedandUnRealizedInvestment , '0.00' as Realized , '0.00'  as UnRealized
   from   MOIC  
  
Union all  
  
 select   
        Attribute , cast ( cast (  isnull( [RealizedandUnRealizedInvestment],0.00 )  as decimal(30,2)) as nvarchar(max) ) as RealizedandUnRealizedInvestment , cast ( cast ( isnull( Realized,0.00)  as decimal(30,2)) as nvarchar(max) )   as Realized , cast ( cast ( isnull( UnRealized,0.00)  as decimal(30,2)) as nvarchar(max) )   as UnRealized
   from   TotalGrossIRR  

  
 ----- To delete data from  OPGC.OPGCResultGIRR Table  
  


--insert into [OPGC].[OPGCResultGIRR_History] ( FundId , ScenarioId , InvestmentID , GIRR, SnapshotDate , Modifiedon ,  ModifiedBy , InvestmentName)
--select  A.FundId , A.ScenarioId , A.InvestmentID , A.GIRR, A.SnapshotDate , GETDATE() , 'Select Total Investment Details' ,B.InvestmentName
--from OPGC.OPGCResultGIRR A
--Left Join [OPGC].[OpgcInvestment] B
--on A.InvestmentID = B.InvestmentId and B.Isdeleted = 0


 DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @SnapshotDate  
  

  
End  
  
  

