SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OPGCResultGIRR](
	[FundId] [int] NULL,
	[ScenarioId] [int] NULL,
	[InvestmentID] [int] NULL,
	[GIRR] [decimal](18, 2) NULL,
	[SnapshotDate] [datetime] NULL
) ON [PRIMARY]

