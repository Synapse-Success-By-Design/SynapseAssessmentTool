SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_DashBoardSummary_DropDown] --1
(
	@FundId INT,
	@userAlias NVARCHAR(100)
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Appointment Details

Uses   
      [USP_Select_Appointment_GetAppointmentDetails]	    SP

Populates
      [WWMG].[ConfirmedScheduleDetails]			Table
	  [WWMG].[LocationDetails]					Table
	  [WWMG].[UserFamilyDetails]				Table
	  [WWMG].[FamilyDetails_Relations]			Table
**************************************************************************/
BEGIN TRY

SELECT DISTINCT T1.DDLID,T1.DDLName,T1.DDLType FROM 
	(
--	SELECT 
--			B.FundId AS DDLID,
--			B.[FundName​] AS DDLName,
--			0 AS IsDeleted,
--			'Fund Name' AS DDLType,
--			0 AS ParentID
--		FROM [OPGC].[OpgcInvestmentCashFlow] A
--		JOIN [OPGC].[OpgcFund] B
--		ON A.FundId =b.FundId
--		WHERE A.FundId =@FundId --AND B.Isdeleted =0

--UNION

		SELECT 
			C.CountryId AS DDLID,
			C.CountryName AS DDLName,
			C.IsDeleted AS IsDeleted,
			'Country' AS DDLType,
			0 AS ParentID
		FROM [OPGC].[OpgcInvestmentCashFlow] A
		JOIN [OPGC].[OpgcInvestment] B
		ON A.InvestmentId =B.InvestmentId
		JOIN [OPGC].[OpgcCountry] C
		ON B.CountryId =C.CountryId
		WHERE A.FundId =@FundId AND B.Isdeleted =0
	UNION
	SELECT 
			C.[IndustryId​] AS DDLID,
			C.[IndustryName​] AS DDLName,
			C.IsDeleted AS IsDeleted,
			'Industry' AS DDLType,
			0 AS ParentID
			   --,CONVERT(BIT,0) AS IsDefault
		FROM [OPGC].[OpgcInvestmentCashFlow] A
		JOIN [OPGC].[OpgcInvestment] B
		ON A.InvestmentId =B.InvestmentId
		JOIN [OPGC].[OpgcIndustry] C
		ON B.IndustryId =C.[IndustryId​]
		WHERE A.FundId =@FundId and B.Isdeleted =0

	) T1
	   
		ORDER BY t1.DDLType ASC			   




END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END


