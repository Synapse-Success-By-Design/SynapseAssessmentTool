SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [OPGC].[OpgcFundCashFlowType](
	[FundCashFlowTypeId] [int] IDENTITY(1,1) NOT NULL,
	[FundCashFlowTypeName] [nvarchar](50) NOT NULL,
	[Isdeleted] [bit] NULL,
	[CreatedBy] [nvarchar](250) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](250) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[FundCashFlowTypeId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [OPGC].[OpgcFundCashFlowType] ADD  DEFAULT ((0)) FOR [Isdeleted]
ALTER TABLE [OPGC].[OpgcFundCashFlowType] ADD  CONSTRAINT [df_OpgcInvestmentCashFlowType_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
