SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_LPPerformance_NetIRRComparision] --'admin',28,1649,1647
(
	 @userAlias NVARCHAR(100)
    ,@FundId  INT  
    ,@ScenarioId INT = NULL
	,@ActiveScenarioId INT
    --,@IndustryId INT = NULL,
    -- @CountryId  INT = NULL
 
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--**************************************************************************
BEGIN TRY

DECLARE @BaseLineScenarioID INT --= (SELECT ScenarioId FROM [OPGC].[OpgcScenario] WHERE FundID = @FundId AND IsBaseline = 1 and Isdeleted = 0  and Isdeleted = 0)
set @BaseLineScenarioID = @ActiveScenarioId


DECLARE @investmentCashflow as table (
 FundID int
,ScenarioID Int
,InvestmentCashFlowtypeID int
,InvestmentID INT
,Equity Decimal (18,2)
,Eventdate DateTime
,IsBaseline Int
)


DECLARE @resultcount INT

DECLARE @Test [OPGC].[GIRRTable]
DECLARE @snapshotdatecurrentGIRR Datetime = GEtdate ();




If coalesce ( @ScenarioId,'') = '' 

begin


INSERT INTO @investmentCashflow

SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 1 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
		,Max(CAST(isbaseline AS INT)) isbaseline 
FROM [OPGC].[OpgcFundCashFlow] o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1
WHERE o.FundId = @FundId and O.FundCashflowTypeId in (1) and o.ScenarioId = @BaseLineScenarioID and o.Isdeleted = 0
GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)
UNION ALL
SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 1 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
		,Max(CAST(isbaseline AS INT)) isbaseline 
FROM [OPGC].[OpgcFundCashFlow] o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1
WHERE o.FundId = @FundId and O.FundCashflowTypeId in (2) and o.ScenarioId = @BaseLineScenarioID and o.Isdeleted = 0
GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId , CAST(o.EventDate as Date)



-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




;with CurrentscenariodataNet as (
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, -SUM(Equity) Equity FROM @investmentCashflow
WHERE-- IsBaseline = 1 and 
InvestmentCashFlowtypeID in (1) 
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
UNION ALL
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @investmentCashflow
WHERE --IsBaseline = 1 and 
InvestmentCashFlowtypeID in (2) 
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
)



INSERT  @Test
SELECT  Equity , EventDate FROM CurrentscenariodataNet
WHERE FundID = @FundId and ScenarioId = @BaseLineScenarioID

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @FundId , @BaseLineScenarioID, 1 , 
       -- Case When CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,
		cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
		@snapshotdatecurrentGIRR


 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;

SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @BaseLineScenarioID  and SnapshotDate = @snapshotdatecurrentGIRR and InvestmentID = 1)

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @FundId , @BaseLineScenarioID, 1 , 0.0 AS GIRR , @snapshotdatecurrentGIRR
END

DELETE FROM @Test

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


;with BaslineNetGIRR as (
SELECT FundId , ScenarioId , InvestmentID , GIRR , SnapshotDate
FROM OPGC.OPGCResultGIRR
where InvestmentID = 1
)


select A.FundId ,F.[FundName​] as FundName,A.ScenarioId as BaselineScenarioId , cast ( 0 as int ) as CompareScenarioId , A.GIRR as BaslineNetIRR , cast ( 0 as decimal(18,2) ) as CompareNetIRR
from BaslineNetGIRR A
INNER JOIN [OPGC].[OpgcFund] F
ON A.FundId=F.FundId

--insert into [OPGC].[OPGCResultGIRR_History] ( FundId , ScenarioId , InvestmentID , GIRR, SnapshotDate , Modifiedon ,  ModifiedBy , InvestmentName)
--select  A.FundId , A.ScenarioId , A.InvestmentID , A.GIRR, A.SnapshotDate , GETDATE() , 'LP Perfomance Graph' ,B.InvestmentName
--from OPGC.OPGCResultGIRR A
--Left Join [OPGC].[OpgcInvestment] B
--on A.InvestmentID = B.InvestmentId and B.Isdeleted = 0

DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR


end

else
begin





INSERT INTO @investmentCashflow

SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 1 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
		,Max(CAST(isbaseline AS INT)) isbaseline 
FROM [OPGC].[OpgcFundCashFlow] o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1
WHERE o.FundId = @FundId and O.FundCashflowTypeId in (1) and o.ScenarioId = @BaseLineScenarioID and o.Isdeleted = 0
GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId ,   CAST(o.EventDate as Date)
UNION ALL
SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 1 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
		,Max(CAST(isbaseline AS INT)) isbaseline 
FROM [OPGC].[OpgcFundCashFlow] o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 1
WHERE o.FundId = @FundId and O.FundCashflowTypeId in (2) and o.ScenarioId = @BaseLineScenarioID and o.Isdeleted = 0
GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId , CAST(o.EventDate as Date)

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
UNION ALL

SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 2 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
		,Max(CAST(isbaseline AS INT)) isbaseline 
FROM [OPGC].[OpgcFundCashFlow] o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 0
WHERE o.FundId = @FundId and O.FundCashflowTypeId in (1) and o.ScenarioId = @ScenarioId and o.Isdeleted = 0
GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId , CAST(o.EventDate as Date)
UNION ALL
SELECT o.FundId,o.ScenarioId,o.FundCashflowTypeId as InvestmentCashflowTypeId, 2 as investmentID , Sum(o.ValueAmount) Equity, CAST(o.EventDate as Date) EventDate
		,Max(CAST(isbaseline AS INT)) isbaseline 
FROM [OPGC].[OpgcFundCashFlow] o
INNER JOIN opgc.OpgcScenario S ON S.FundID = o.FundId and S.ScenarioId = o.ScenarioId --and S.IsBaseline = 0
WHERE o.FundId = @FundId and O.FundCashflowTypeId in (2) and o.ScenarioId = @ScenarioId and o.Isdeleted = 0
GROUP BY o.FundId,o.ScenarioId,o.FundCashflowTypeId , CAST(o.EventDate as Date)

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




;with CurrentscenariodataNet as (
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, -SUM(Equity) Equity FROM @investmentCashflow
WHERE --IsBaseline = 1 
--and 
InvestmentCashFlowtypeID in (1) 
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
UNION ALL
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @investmentCashflow
WHERE --IsBaseline = 1 and 
InvestmentCashFlowtypeID in (2) 
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
)



INSERT  @Test
SELECT  Equity , EventDate FROM CurrentscenariodataNet
WHERE FundID = @FundId and ScenarioId = @BaseLineScenarioID

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @FundId , @BaseLineScenarioID, 1 , 
       --Case When CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,
	  cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
	   @snapshotdatecurrentGIRR


 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;

SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @BaseLineScenarioID  and SnapshotDate = @snapshotdatecurrentGIRR and InvestmentID = 1)

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @FundId , @BaseLineScenarioID, 1 , 0.0 AS GIRR , @snapshotdatecurrentGIRR
END

DELETE FROM @Test

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

;with SelectedscenariodataNet as (
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, -SUM(Equity) Equity FROM @investmentCashflow
WHERE --IsBaseline = 0 and 
InvestmentCashFlowtypeID in (1) 
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
UNION ALL
SELECT FundID,ScenarioID,CAST(Eventdate AS DATE ) Eventdate, SUM(Equity) Equity FROM @investmentCashflow
WHERE --IsBaseline = 0 and
InvestmentCashFlowtypeID in (2) 
GROUP BY FundID,ScenarioID,CAST(Eventdate AS DATE )
)
INSERT  @Test
SELECT  Equity , EventDate FROM SelectedscenariodataNet
WHERE FundID = @FundId and ScenarioId = @ScenarioId

  SET XACT_ABORT ON; 
        BEGIN TRY
        BEGIN TRANSACTION;
INSERT INTO OPGC.OPGCResultGIRR
 SELECT @FundId , @ScenarioId , 2 ,
        --Case When CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT) < 0 Then 0.00 Else CAST(ROUND([OPGC].[CalcGIRR](@Test, 0.1)*100,2) AS FLOAT) End  AS GIRR,
	cast ( (isnull([OPGC].[CalcGIRR_Goalseek](@Test),1)  - 1) *100 as decimal(18,2)) as GIRR,
		@snapshotdatecurrentGIRR


 COMMIT TRANSACTION ;  
END TRY

BEGIN CATCH 


IF @@trancount > 0 ROLLBACK TRANSACTION



END CATCH ;

SET @resultcount = (SELECT COUNT(*) FROM OPGC.OPGCResultGIRR Where ScenarioID = @ScenarioId  and SnapshotDate = @snapshotdatecurrentGIRR and InvestmentID = 2 )

IF @resultcount = 0
BEGIN 
INSERT INTO OPGC.OPGCResultGIRR
SELECT @FundId, @ScenarioID , 2 , 0.0 AS GIRR, @snapshotdatecurrentGIRR

END

;with BaslineNetGIRR as (
SELECT FundId , ScenarioId , InvestmentID , GIRR , SnapshotDate
FROM OPGC.OPGCResultGIRR
where InvestmentID = 1
)
, CompareNetGIRR as (
SELECT FundId , ScenarioId , InvestmentID , GIRR , SnapshotDate
FROM OPGC.OPGCResultGIRR
where InvestmentID = 2
)

select A.FundId ,F.[FundName​] as FundName,A.ScenarioId as BaselineScenarioId , isnull(B.ScenarioId,0) as CompareScenarioId , A.GIRR as BaslineNetIRR , 

CASE WHEN @ScenarioId = @ActiveScenarioId THEN A.GIRR
ELSE isnull(B.GIRR,0.00) END as CompareNetIRR
from BaslineNetGIRR A
Left join CompareNetGIRR B
on A.FundId = B.FundId
INNER JOIN [OPGC].[OpgcFund] F
ON A.FundId=F.FundId


--insert into [OPGC].[OPGCResultGIRR_History] ( FundId , ScenarioId , InvestmentID , GIRR, SnapshotDate , Modifiedon ,  ModifiedBy , InvestmentName)
--select  A.FundId , A.ScenarioId , A.InvestmentID , A.GIRR, A.SnapshotDate , GETDATE() , 'LP Perfomance Graph' ,B.InvestmentName
--from OPGC.OPGCResultGIRR A
--Left Join [OPGC].[OpgcInvestment] B
--on A.InvestmentID = B.InvestmentId and B.Isdeleted = 0

DELETE FROM OPGC.OPGCResultGIRR WHERE SnapshotDate = @snapshotdatecurrentGIRR


end

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END

