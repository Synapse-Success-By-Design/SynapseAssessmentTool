SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE  PROCEDURE [dbo].[Usp_InsertUpdateOPGCUserSecurityGroup]  
(  
       @UDTOPGCSecurityGroup  [OPGC].[UDTOPGCSecurityGroup]  READONLY,  
       @NewUsersAdded Nvarchar(Max) output,  
       @NumRowsAdded int    output,  
       @InactivatedUsers Nvarchar(Max) output,  
       @NumRowsUpdated int output  
    )  
AS  
BEGIN  
  
       SET NOCOUNT ON;  

-------New User Names


       SELECT @NewUsersAdded= COALESCE(@NewUsersAdded + ',', '')  + [alias]  
       FROM @UDTOPGCSecurityGroup where EmailID not in (SELECT EmailId  FROM [OPGC].[OpgcUser])  

       SELECT @NewUsersAdded = 'New Users to be Added are ' + @NewUsersAdded;  

---------------Existing User ------------------------------

DECLARE @ExistingUserId AS TABLE
(
Userid INT
)

 SELECT 
 OpgcUserId
 from [OPGC].[OpgcUser] WHERE EmailId IN (SELECT EmailID FROM @UDTOPGCSecurityGroup)

 UPDATE [OPGC].[OpgcUserRolePermission]
 SET   OpgcUserRoleId = CASE WHEN A.UserGroup ='Super Admin' THEN 1 
	   WHEN A.UserGroup ='Executive' THEN 2 END,
	   ModifiedBy = 'System',
	   ModifiedOn = getdate(),
	   IsDeleted = a.UserStatus
	   FROM @UDTOPGCSecurityGroup A where OpgcUserId in (select Userid from @ExistingUserId)

---------------------------------------------------------------------
 

DECLARE @Newuser AS TABLE
  (
  EmailID NVARCHAR(250),
  Alias NVARCHAR(200)
  )

  SELECT 
  Emailid,
  Alias
  FROM @UDTOPGCSecurityGroup WHERE EmailID not in (select EmailId from [OPGC].[OpgcUser] )


  INSERT INTO [OPGC].[OpgcUser]
  (
  EmailId,
  DisplayName,
  CreatedBy,
  CreatedOn,
  ModifiedBy,
  ModifiedOn,
  IsDeleted
  )

  SELECT 
  Emailid,
  Alias,
  'System',
  GETDATE(),
  NULL,
  NULL,
  0
  FROM @Newuser
  
  DECLARE @OpgcNewuserID AS TABLE 
  (
  UserId INT,
  EmailID NVARCHAR(250)
  )
  
  SELECT 
  OpgcUserId,
  EmailId
  from [OPGC].[OpgcUser] WHERE EmailId IN (SELECT EmailID FROM @Newuser)

  INSERT INTO [OPGC].[OpgcUserRolePermission]
  (
  OpgcUserId,
  OpgcUserRoleId,
  IsDeleted,
  CreatedBy,
  CreatedOn,
  ModifiedBy,
  ModifiedOn
  )

  select 
  B.UserId,
  CASE WHEN A.UserGroup ='Super Admin' THEN 1 
	   WHEN A.UserGroup ='Executive' THEN 2 END AS OpgcUserRoleId,
  0,
  'System',
  GETDATE (),
  NULL,
  NULL
  from @UDTOPGCSecurityGroup A
  join @OpgcNewuserID B on A.EmailID=B.EmailID


	select @NumRowsUpdated = @@ROWCOUNT   


-----Inactive User Names

       SELECT @InactivatedUsers= COALESCE(@InactivatedUsers + ',', '') + DisplayName from [OPGC].[OpgcUser] A  
       WHERE [DisplayName] NOT IN (SELECT [Alias] FROM @UDTOPGCSecurityGroup  B WHERE A.DisplayName = B.[Alias] AND A.[IsDeleted] = 1 )  
  
       SELECT @InactivatedUsers = 'In-Activated Members are ' + @InactivatedUsers;  
  
END

