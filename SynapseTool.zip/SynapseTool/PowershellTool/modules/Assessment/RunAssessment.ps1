﻿
#Function to get absolute path from relative path measured starting from PSScriptRoot
Function Get-AbsolutePath {
    [CmdletBinding()] 
    param( 
        [Parameter(Position = 0, Mandatory = $true)] [string]$Path
    ) 

    if ([System.IO.Path]::IsPathRooted($Path) -eq $false) {
        return [IO.Path]::GetFullPath( (Join-Path -Path $PSScriptRoot -ChildPath $Path) )
    }
    else {
        return $Path
    }
}

#Application Logging, writes to console by default. Additionally, writes to a log file based on boolean parameter "GenerateLogFileInSameDir" from config
Function Write-Log {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True)]
        [string]
        $Message,

        [Parameter(Mandatory = $False)]
        [string]
        $WriteToFile,
	
        [Parameter(Mandatory = $False)]
        [string]
        $LogFileLocation,
	
        [Parameter(Mandatory = $False)]
        [ValidateSet("INFO", "WARN", "ERROR", "FATAL", "VERBOSE")]
        [String]
        $Level = "INFO"
    )

    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Line = "$Stamp $Level $Message"
    If ($WriteToFile -eq "1") {
        Add-Content -Path $LogFileLocation -Value $Line
    }
	
    if ($Level -eq "ERROR") {
        Write-Host $Line -ForegroundColor Red
    }
	
    elseif ($Level -eq "WARN") {
        Write-Host $Line -ForegroundColor Yellow
    }
	
    elseif ($Level -eq "VERBOSE") {
	
    }
	
    else {
        Write-Host $Line
    }
}

#Helper function to remove invalid file name characters
Function Remove-InvalidFileNameChars {
    param(
        [Parameter(Mandatory = $true,
            Position = 0,
            ValueFromPipeline = $true,
            ValueFromPipelineByPropertyName = $true)]
        [String]$Name
    )

    $invalidChars = [IO.Path]::GetInvalidFileNameChars() -join ''
    $re = "[{0}]" -f [RegEx]::Escape($invalidChars)
    return ($Name -replace $re)
}



##########################################################################################################


#Regex based check on content of sql extracted objects against rules defined in AssessmentRules.csv
Function checkUnsupportedTypes {    
    Param(
        [string]$query = "",
        [string]$fileName = "",
        [string]$objectType = "",
        [PSCustomObject]$rules,
        [string]$dbName,
        [string] $WriteToFile,
        [string] $LogFileLoc
    )

    $queryLines = $query -split "`r`n"

    $results = @()

    $regexOptions = [Text.RegularExpressions.RegexOptions]'IgnoreCase, CultureInvariant'
    # Line by Line file check to match regex 
    <#
    for ($i=0; $i -lt $queryLines.Count; $i+=1) {
        $queryLine = $queryLines[$i]
        # Ignore comment lines
        if ($queryLine.TrimStart().StartsWith("--")) {
            continue
        }
        foreach ($rule in $rules) {
            $matches1 = [regex]::Matches($queryLine, $rule.RegularExpression, $regexOptions)

            if ($matches1.Count -gt 0) {
                $results += [PSCustomObject]@{RuleName=$rule.RuleName;
                    RuleCategory = $rule.RuleCategory;
                    SqlObjectType = $objectType;
                    ObjectType = $rule.ObjectType;
                    RuleApplicability = $rule.RuleApplicability;
                    RegularExpression = $rule.RegularExpression;
                    HelpLink = $rule.HelpLink;
                    Reason = $rule.Reason;
                    Category = $rule.Category;
                    Recommendation = $rule.Recommendation;
                    LineNumber=$i+1;
                    FailedText=$queryLine;
                    FileName = $fileName;
					DatabaseName = $dbName;
                }
            }
        }

    }
        #>
    #Using 
    $regexOptions1 = [Text.RegularExpressions.RegexOptions]'IgnoreCase, CultureInvariant, MultiLine'
    # Another loop through the whole definition to check for match on multiple lines
    foreach ($rule in $rules) {

        $matches2 = [regex]::Matches($query, $rule.RegularExpression, $regexOptions1)

        if ($matches2.Count -gt 0) {

            $lineNum = ($query.Substring(0, $matches2[0].Index + 1) | Measure-Object -Line).Lines

            if ($rule.RuleName -eq 'CrossDBQuery') {
                # cross test pattern flag
                $crossDBpattern = '[^a-zA-Z0-9_]'
                $db1 = $matches2.Groups[2].Value -replace $crossDBpattern, ''
                $db2 = $matches2.Groups[4].Value -replace $crossDBpattern, ''

                if ($db1.ToUpper() -ne $db2.ToUpper()) {
                    $results += [PSCustomObject]@{RuleName = $rule.RuleName;
                        RuleCategory                       = $rule.RuleCategory;
                        SqlObjectType                      = $objectType;
                        ObjectType                         = $rule.ObjectType;
                        RuleApplicability                  = $rule.RuleApplicability;
                        RegularExpression                  = $rule.RegularExpression;
                        HelpLink                           = $rule.HelpLink;
                        Reason                             = $rule.Reason;
                        Category                           = $rule.Category;
                        Recommendation                     = $rule.Recommendation;
                        LineNumber                         = $lineNum;
                        FailedText                         = $matches2.Value;
                        FileName                           = $fileName;
                        DatabaseName                       = $dbName;
                    }
                }
            }
            else {
                $results += [PSCustomObject]@{RuleName = $rule.RuleName;
                    RuleCategory                       = $rule.RuleCategory;
                    SqlObjectType                      = $objectType;
                    ObjectType                         = $rule.ObjectType;
                    RuleApplicability                  = $rule.RuleApplicability;
                    RegularExpression                  = $rule.RegularExpression;
                    HelpLink                           = $rule.HelpLink;
                    Reason                             = $rule.Reason;
                    Category                           = $rule.Category;
                    Recommendation                     = $rule.Recommendation;
                    LineNumber                         = $lineNum;
                    FailedText                         = $matches2.Value;
                    FileName                           = $fileName;
                    DatabaseName                       = $dbName;
                }
            }
        }
    }
	    

    return $results
}

##########################################################################################################

Function ExportObjectDDLs() {
    [CmdletBinding()] 
    param( 
        [Parameter(Position = 1, Mandatory = $true)] [array]$Objects, 
        [Parameter(Position = 2, Mandatory = $true)] [string]$OutputDatabaseFolder,
        [Parameter(Position = 3, Mandatory = $true)] [string]$Subfolder,
        [Parameter(Position = 4, Mandatory = $true)] [string]$ObjectType,
        [Parameter(Position = 5, Mandatory = $true)] [string]$GenerateLogFileInSameDir,
        [Parameter(Position = 6, Mandatory = $true)] [string]$LogFileLoc
    ) 

    $currObjects = $Objects | Where-Object { $_.type_desc -eq $ObjectType }
    foreach ($object in $currObjects) {
        $fileName = Remove-InvalidFileNameChars $object.file_name
	
        $outputFolderPath = Join-Path -Path $OutputDatabaseFolder -ChildPath $Subfolder
		
        if (!(Test-Path $outputFolderPath)) {
            New-Item -Path $outputFolderPath -ItemType Directory -Force | Out-Null
        }

        $outputfilePath = Join-Path -Path $outputFolderPath -ChildPath $fileName
        $object.definition | Out-File -LiteralPath $outputfilePath
    }
}

##########################################################################################################

Function ExtractObjects {    
    Param(
        [Parameter(Position = 1, Mandatory = $true)] [string]$UseIntegrated,
        [Parameter(Position = 2, Mandatory = $true)] [string]$SqlServerName,
        [Parameter(Position = 3, Mandatory = $false)] [string[]]$dbNames,
        [Parameter(Position = 4, Mandatory = $true)] [string]$OutputBaseFolder,
        [Parameter(Position = 5, Mandatory = $false)] [string]$DefaultDB,
        [Parameter(Position = 6, Mandatory = $false)] [string[]]$ExcludedDBNames,
        [Parameter(Position = 7, Mandatory = $false)] [string]$GenerateLogFileInSameDir,
        [Parameter(Position = 8, Mandatory = $false)] [string]$LogFileLoc,
        [Parameter(Position = 9, Mandatory = $false)] [string]$dbExtractionStatusPath,
        [Parameter(Position = 10, Mandatory = $false)] [string]$InventoryOutputFilePath,
		[Parameter(Position = 11, Mandatory = $false)] [string]$ExtractSPDetails,
		[Parameter(Position = 12, Mandatory = $false)] [string]$RetryFailedDBsMode
    )
	
    if ( ($UseIntegrated.ToUpper() -eq "YES") -or ($UseIntegrated.ToUpper() -eq "Y") ) {
        $UseIntegratedSecurity = $true
    }
    else {
        Write-Log "Need Login Information..."  $GenerateLogFileInSameDir $LogFileLoc
        $UseIntegratedSecurity = $false
        $UserName = Read-Host -prompt "Enter the User Name to connect to the SQL Server"
  
        if ([string]::IsNullOrWhiteSpace($UserName)) {
            Write-Log "A user name must be entered"  $GenerateLogFileInSameDir $LogFileLoc "ERROR"
            break
        }
        $Password = Read-Host -prompt "Enter the Password to connect to the SQL Server"
        if ([string]::IsNullOrWhiteSpace($Password)) {
            Write-Log "A password must be entered."  $GenerateLogFileInSameDir $LogFileLoc "ERROR"
            break
        }
    }
	
    try {

        if ($dbNames.length -eq 0 -or $dbNames -eq $null) {
            $dbListQuery = "DECLARE @dbNames nvarchar(max)
select @dbNames = COALESCE(@dbNames+',','')+name from sys.databases WITH(NOLOCK)
select @dbNames AS dbList"
            if ($UseIntegratedSecurity) {
                $result = Invoke-Sqlcmd -Query $dbListQuery -ServerInstance $SqlServerName -database $defaultDB -ApplicationIntent ReadOnly -MaxCharLength ([int]::MaxValue)
            }
            else {   
                $result = Invoke-Sqlcmd -Query $dbListQuery -ServerInstance $SqlServerName -database $defaultDB -ApplicationIntent ReadOnly -Username $UserName -Password $Password -MaxCharLength ([int]::MaxValue)
            }
            foreach ($row in $result) {
                $dbNames1 = $row.Item(0)
            }
            $dbNames = $dbNames1 -Split ","
            Write-Log "Number of databases found: $dbNames.length" $GenerateLogFileInSameDir $LogFileLoc
            Write-Log "List of DBs from server:$dbNames1" $GenerateLogFileInSameDir $LogFileLoc
        }

        $processedDBNames = "";
        $excludedDBsCount = 0;
        $totalDBsCount = $dbNames.length;
        $failedDBsCount = 0;

        foreach ($row in $dbNames) {
 
            if ($row -in $ExcludedDBNames) {
                Write-Log "Skipping excluded db: $row" $GenerateLogFileInSameDir $LogFileLoc
                $excludedDBsCount += 1
                continue
            }
            Write-Log "Extracting objects for $row" $GenerateLogFileInSameDir $LogFileLoc
            $dbExtractionStatusFilePath = $dbExtractionStatusPath + "\" + $row + ".txt"
            $SourceDatabase = $row
            $SQLObjectsextractorFolder = Get-AbsolutePath "..\..\..\SQLObjectsExtractor";
            $SQLObjectsextractorExe = Join-Path $SQLObjectsextractorFolder -ChildPath "SQLObjectsExtractor.exe";
            #$OutputDatabaseFolder = Join-Path -Path $OutputBaseFolder -ChildPath $SourceDatabase
            
            if ($UseIntegratedSecurity) {
                $startTime1 = (Get-Date)
                Write-Log "Extracting $row objects using SQLObjectsExtractor.exe" $GenerateLogFileInSameDir $LogFileLoc
                & $SQLObjectsextractorExe "DBMode" 1 $SourceDatabase $SqlServerName $OutputBaseFolder $GenerateLogFileInSameDir $LogFileLoc $dbExtractionStatusPath $InventoryOutputFilePath $ExtractSPDetails
		
                $endTime1 = (Get-Date)
                $ElapsedTime1 = ($endTime1 - $startTime1).ToString('''Duration: ''hh'' hour ''mm'' min ''ss'' sec''')
                Write-Log "Time taken to extract sql objects for $row using SQLObjectsExtractor.exe: $ElapsedTime1" $GenerateLogFileInSameDir $LogFileLoc
		
                if (Test-Path $dbExtractionStatusFilePath) {
                    Write-Log "Found failure indicator file at $dbExtractionStatusFilePath" $GenerateLogFileInSameDir $LogFileLoc "ERROR"
                    Write-Log "An error occured while trying to extract objects for $row using SQLObjectsExtractor.exe" $GenerateLogFileInSameDir $LogFileLoc "ERROR"
                    $failedDBsCount += 1
                }
            }
            else {   
                $startTime1 = (Get-Date)
                & $SQLObjectsextractorExe "DBMode" 0 $SourceDatabase $SqlServerName $OutputBaseFolder $GenerateLogFileInSameDir $LogFileLoc $dbExtractionStatusPath $InventoryOutputFilePath $ExtractSPDetails $UserName $Password
                $endTime1 = (Get-Date)
                $ElapsedTime1 = ($endTime1 - $startTime1).ToString('''Duration: ''mm'' min ''ss'' sec''')
                Write-Log "Time taken to extract sql objects for $row using SQLObjectsExtractor.exe: $ElapsedTime1" $GenerateLogFileInSameDir $LogFileLoc
		
                if (Test-Path $dbExtractionStatusFilePath) {
                    Write-Log "Found failure indicator file at $dbExtractionStatusFilePath" $GenerateLogFileInSameDir $LogFileLoc "ERROR"
                    Write-Log "An error occured while trying to extract objects for $row using SQLObjectsExtractor.exe" $GenerateLogFileInSameDir $LogFileLoc "ERROR"
                    $failedDBsCount += 1
                }
            }
            $processedDBNames = $processedDBNames + "," + $row;
            $extractedDBsCount += 1
            Write-Log "Extracted $extractedDBsCount out of $totalDBsCount, Excluded $excludedDBsCount, Failed $failedDBsCount " $GenerateLogFileInSameDir $LogFileLoc 
        }    
    }
    catch [Exception] {
        Write-Warning $_.Exception.Message
    }
}

##########################################################################################################

Function CollectInventory {    
    Param(
        [Parameter(Position = 1, Mandatory = $true)] [string]$UseIntegrated,
        [Parameter(Position = 2, Mandatory = $true)] [string]$SqlServerName,
        [Parameter(Position = 3, Mandatory = $false)] [string[]]$dbNames,
        [Parameter(Position = 4, Mandatory = $true)] [string]$OutputBaseFolder,
        [Parameter(Position = 5, Mandatory = $false)] [string]$DefaultDB,
        [Parameter(Position = 6, Mandatory = $false)] [string[]]$ExcludedDBNames,
        [Parameter(Position = 7, Mandatory = $false)] [string]$GenerateLogFileInSameDir,
        [Parameter(Position = 8, Mandatory = $false)] [string]$LogFileLoc,
        [Parameter(Position = 10, Mandatory = $false)] [string]$InventoryScriptsRoot,
        [Parameter(Position = 11, Mandatory = $false)] [string]$OutputFolder,
        [Parameter(Position = 12, Mandatory = $false)] [string]$InventoryOutputFilePath
    )

    if ( ($UseIntegrated.ToUpper() -eq "YES") -or ($UseIntegrated.ToUpper() -eq "Y") ) {
        $UseIntegratedSecurity = $true
    }
    else {
        Write-Log "Need Login Information..."  $GenerateLogFileInSameDir $LogFileLoc
        $UseIntegratedSecurity = $false
        $UserName = Read-Host -prompt "Enter the User Name to connect to the SQL Server"
  
        if ([string]::IsNullOrWhiteSpace($UserName)) {
            Write-Log "A user name must be entered"  $GenerateLogFileInSameDir $LogFileLoc "ERROR"
            break
        }
        $Password = Read-Host -prompt "Enter the Password to connect to the SQL Server"
        if ([string]::IsNullOrWhiteSpace($Password)) {
            Write-Log "A password must be entered."  $GenerateLogFileInSameDir $LogFileLoc "ERROR"
            break
        }
    }
	


    if ($dbNames.length -eq 0 -or $dbNames -eq $null) {
        $dbListQuery = "DECLARE @dbNames nvarchar(max)
select @dbNames = COALESCE(@dbNames+',','')+name from sys.databases WITH(NOLOCK)
select @dbNames AS dbList"
        if ($UseIntegratedSecurity) {
            $result = Invoke-Sqlcmd -Query $dbListQuery -ServerInstance $SqlServerName -database $defaultDB -ApplicationIntent ReadOnly -MaxCharLength ([int]::MaxValue)
        }
        else {   
            $result = Invoke-Sqlcmd -Query $dbListQuery -ServerInstance $SqlServerName -database $defaultDB -ApplicationIntent ReadOnly -Username $UserName -Password $Password -MaxCharLength ([int]::MaxValue)
        }
        foreach ($row in $result) {
            $dbNames1 = $row.Item(0)
        }
        $dbNames = $dbNames1 -Split ","
        Write-Log "Number of databases found: $dbNames.length" $GenerateLogFileInSameDir $LogFileLoc
        Write-Log "List of DBs from server:$dbNames1" $GenerateLogFileInSameDir $LogFileLoc
    }

    $processedDBNames = "";
    $excludedDBsCount = 0;
    $totalDBsCount = $dbNames.length;

    foreach ($row in $dbNames) {
 
        if ($row -in $ExcludedDBNames) {
            Write-Log "Skipping excluded db: $row" $GenerateLogFileInSameDir $LogFileLoc
            $excludedDBsCount += 1
            continue
        }
        Write-Log "Collecting DB Inventory for $row, using inventory scripts present under $InventoryScriptsRoot" $GenerateLogFileInSameDir $LogFileLoc

        $SourceDatabase = $row


        foreach ($file in Get-ChildItem -LiteralPath $InventoryScriptsRoot -Filter *.sql) {
            $queryName = $file.Name
            Write-Log "Executing $queryName" $GenerateLogFileInSameDir $LogFileLoc "VERBOSE"
            $query = [System.IO.File]::ReadAllText($file.FullName) 
            if ($UseIntegratedSecurity) {
                $result = Invoke-Sqlcmd -Query $query -ServerInstance $SqlServerName -database $SourceDatabase -ApplicationIntent ReadOnly -OutputAs DataSet -MaxCharLength ([int]::MaxValue)
            }
            else {   
                $result = Invoke-Sqlcmd -Query $query -ServerInstance $SqlServerName -database $SourceDatabase -ApplicationIntent ReadOnly -OutputAs DataSet -Username $UserName -Password $Password -MaxCharLength ([int]::MaxValue)
            }
            if ($result -and $result.Tables) {
                $result.Tables[0].Rows | Select * -ExcludeProperty RowError, RowState, Table, ItemArray, HasErrors | Export-Excel -Path $InventoryOutputFilePath -WorksheetName $queryName -AutoSize -Append
            }
        }
        Write-Log "Inventory collected for $row and output written to $InventoryOutputFilePath" 
    }

}

##########################################################################################################

########################################################################################
#
# Main Program Starts here
#
########################################################################################
#Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
Import-Module -Name SqlServer
$startTime = (Get-Date)
$inputFilesPath = Get-AbsolutePath "..\..\..\Input"
$outputFolder = Get-AbsolutePath "..\..\..\Output"
$inventoryOutputFilePath = Get-AbsolutePath "$outputFolder\InventoryandAssessmentReport.xlsx"
$ScriptPath = $PSScriptRoot
$defaultJsonConfigFileName = "config.json"
$dbExtractionStatusPath = "$outputFolder\FailedToExtract"
$inventoryScriptsRoot = "$PSScriptRoot\InventoryScripts"
$logFileLoc = "$PSScriptRoot\ToolLogs_" + (Get-Date -f yyyy-MM-dd_HH-mm) + ".log"

$JsonConfigFileFullPath = Join-Path -Path $ScriptPath -ChildPath $defaultJsonConfigFileName
if (!(Test-Path $JsonConfigFileFullPath )) {
    Write-Log "Could not find Config file: $JsonConfigFileFullPath" "0" $LogFileLoc "ERROR"
    break 
}

$JsonConfig = Get-Content -Path $JsonConfigFileFullPath | ConvertFrom-Json 
$configFileName = $JsonConfig.ConfigFileName
$inputServerName = $JsonConfig.ServerName
$inputDBs = $JsonConfig.ListOfDBsToScan
$exceptionList = $JsonConfig.ListOfDBsToSkip
$useIntegrated = $JsonConfig.IntegratedSecurity
$skipExtraction = $JsonConfig.SkipExtraction
$defaultDB = $JsonConfig.DefaultDBToConnect
$skipInputFolderCleanup = $JsonConfig.SkipInputFolderCleanup
$generateLogFileInSameDir = $JsonConfig.GenerateLogFileInSameDir
$skipInventoryCollection = $JsonConfig.SkipInventoryCollection
$skipAssessment = $JsonConfig.SkipAssessment
$extractSPDetails = $JsonConfig.ExtractSPDetails
$RetryFailedDBsMode= $JsonConfig.RetryFailedDBsMode
$inputDBNames = @()
$excludedDBNames = @()
$failedDBList = @()
$failedDBs = ""

if($RetryFailedDBsMode -eq "0"){
if (Test-Path $outputFolder) {

    Write-Log "Cleaning Output folder" $generateLogFileInSameDir $logFileLoc
    Remove-Item $outputFolder -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $outputFolder



if (!(Test-Path $dbExtractionStatusPath )) {
    New-Item -ItemType Directory -Force -Path $dbExtractionStatusPath
}
else {
    Get-ChildItem -Path $dbExtractionStatusPath -Include *.* -File -Recurse | foreach { $_.Delete() }
}



$configFilePath = Join-Path -Path $ScriptPath -ChildPath $configFileName
if (!(Test-Path $configFilePath )) {
    Write-Log "Could not find Config file: $configFilePath " $generateLogFileInSameDir $logFileLoc "ERROR"
    break 
}

if ((Test-Path $inputFilesPath) -And $skipInputFolderCleanup -eq "0") {

    Write-Log "Cleaning input folder" $generateLogFileInSameDir $logFileLoc
    Remove-Item $inputFilesPath -Recurse -Force
}

if ($exceptionList -eq "" -or $exceptionList -eq $null) {
}
else {
    $excludedDBNames = $exceptionList -Split ",";
}

if ($inputServerName -eq "" -or $inputServerName -eq $null) {
    Write-Log "Server name is mandatory" $generateLogFileInSameDir $logFileLoc "ERROR"
    break
}
	

if ($inputDBs -eq "" -or $inputDBs -eq $null) {
    if ($defaultDB -eq "" -or $defaultDB -eq $null) {
        Write-Log "Default DB is mandatory to get list of all databases" $GenerateLogFileInSameDir $LogFileLoc "ERROR"
        break
    }
}
else {	
    $inputDBNames = $inputDBs -Split ",";
}


if ($useIntegrated -eq "" -or $useIntegrated -eq $null) {
    Write-Log "Auth type is mandatory" $GenerateLogFileInSameDir $LogFileLoc "ERROR"
    break
}  
  
if ($skipInventoryCollection -eq "1") { 
    Write-Log "Skipping Inventory collection based on SkipInventoryCollection value defined in config.json" $generateLogFileInSameDir $logFileLoc
}
else {
    CollectInventory -UseIntegrated $useIntegrated -SqlServerName $inputServerName -dbNames $inputDBNames -OutputBaseFolder $inputFilesPath -DefaultDB $defaultDB -ExcludedDBNames $excludedDBNames -GenerateLogFileInSameDir $generateLogFileInSameDir -LogFileLoc $logFileLoc -InventoryScriptsRoot $inventoryScriptsRoot -OutputFolder $outputFolder -InventoryOutputFilePath $inventoryOutputFilePath

}

	

if ($skipExtraction -eq "0") {
    ExtractObjects -UseIntegrated $useIntegrated -SqlServerName $inputServerName -dbNames $inputDBNames -OutputBaseFolder $inputFilesPath -DefaultDB $defaultDB -ExcludedDBNames $excludedDBNames -GenerateLogFileInSameDir $generateLogFileInSameDir -LogFileLoc $logFileLoc -dbExtractionStatusPath $dbExtractionStatusPath -InventoryOutputFilePath $inventoryOutputFilePath -ExtractSPDetails $extractSPDetails -RetryFailedDBsMode $RetryFailedDBsMode
}
else {
    Write-Log "Skipping objects extraction based on SkipExtraction value defined in config.json" $generateLogFileInSameDir $logFileLoc
}

$failedDBList = @(
    $(Get-ChildItem -File -Path $dbExtractionStatusPath | Select -ExpandProperty Name)
)
foreach ($item in $failedDBList) {
    if ($failedDBs -eq "") {
        $failedDBs = $item.Replace(".txt", "")
    }
    else {
        $failedDBs = $failedDBs + "," + $item.Replace(".txt", "")
    }
}


if ($skipAssessment -eq "0") {
    $configCsvFile = Import-Csv $configFilePath 

 
    $unsupportedDataTypesTotal = @()
    $totalFiles = 0
    $totalFilesUnsupportedDataTypes = 0
    $validationResults = @()
    $validationResultsAll = @()
    $outputDir = ""
    $rulesFolder = Get-AbsolutePath "..\..\.."
    $rulesFile = Join-Path -Path $rulesFolder -ChildPath "AssessmentRules.csv"


    $rules = Import-Csv -Path $rulesFile
    $rulesCount = $rules.count
    Write-Log "Total rules : $rulesCount" $generateLogFileInSameDir $logFileLoc

    $rules = $rules | Where-Object { $_.RegularExpression -ne "" }
    $rulesCount = $rules.count
    Write-Log "Total rules with non-blank regex : $rulesCount" $generateLogFileInSameDir $logFileLoc

    Write-Log " " $generateLogFileInSameDir $logFileLoc
    Write-Log " " $generateLogFileInSameDir $logFileLoc
    Write-Log "***************************************************************************************************************************************************************" $generateLogFileInSameDir $logFileLoc

    foreach ($configRow in $configCsvFile) {
        if ($configRow.Active -eq '1') {
            $databaseName = $configRow.SourceDatabaseName  
            $sourceDir = Get-AbsolutePath $configRow.SourceDirectory
            $outputDir = $outputFolder
            $targetDir = $outputDir + "\" + $configRow.ObjectType
            $defaultSchema = $configRow.DefaultSchema
            $validationResults = @()
            $objectFiles = 0
            $objType = $configRow.ObjectType

            Write-Log "Started assessment for all $objType present under : $sourceDir" $generateLogFileInSameDir $logFileLoc

            $objectrules = $rules | Where-Object { $_.RuleApplicability -eq "All" -or $_.RuleApplicability -eq $configRow.ObjectType }
            $objectrulesCount = $objectrules.count

            Write-Log "Total applicable rules for $objType :$objectrulesCount" $generateLogFileInSameDir $logFileLoc
            if (!(Test-Path -Path $sourceDir)) {
                continue
            }
		
            Get-ChildItem -Path $sourceDir -Directory | ForEach-Object {
                $dbName = $_.Name
                Write-Log  "Assessing $dbName objects" $WriteToFile $LogFileLoc 
                if ($dbName + ".txt" -in $failedDBList) {
                    Write-Log "Skipping assessment for db Failed to extract : $dbName" $generateLogFileInSameDir $logFileLoc
                }
                else {
                    foreach ($file in Get-ChildItem -LiteralPath $_.FullName -Filter *.sql) {
                        $totalFiles += 1
                        $objectFiles += 1
                        $sourceFilePath = $file.FullName
                        $content = Get-Content -LiteralPath $SourceFilePath -Raw

                        $newContent = $content

                        # Check for unsupported data types
                        $validationResults += CheckUnsupportedTypes -Query $newContent -fileName $file.Name -ObjectType $configRow.ObjectType -Rules $objectrules -DBName $dbName   
                    }
                }
            }
		
		

            Write-Log "Number of Files scanned : $objectFiles" $generateLogFileInSameDir $logFileLoc

        

            # if there are unsupported data types found we add a comment to the script
            if ($validationResults.count -gt 0) {
                $outputFileName = $configRow.ObjectType + "_ValidationResults.xlsx"
                # Create target folder if it does not exist
                $targetFilePath = Join-Path -Path $targetDir -ChildPath $outputFileName
                $targetFolder = [IO.Path]::GetDirectoryName($targetFilePath)
                if (!(Test-Path $targetFolder)) {
                    New-item -Path $targetFolder -ItemType Dir | Out-Null
                }
                $validationResults | Export-Excel -Path $targetFilePath -AutoSize
                Write-Log "$objType assessment report written to : $targetFilePath" $generateLogFileInSameDir $logFileLoc
                $validationResultsAll += $validationResults
            }

            Write-Log "***************************************************************************************************************************************************************" $generateLogFileInSameDir $logFileLoc
        }
    }


    $style = New-ExcelStyle -BackgroundColor LightBlue -FontSize 12 -Bold -Range "A1:H1"

    $ExcelParams = @{
        Path              = $inventoryOutputFilePath
        IncludePivotTable = $true
        PivotRows         = @('DatabaseName', 'Category', 'Reason')
        PivotTableName    = 'Assessment Summary'
        PivotColumns      = 'SqlObjectType'
        PivotData         = @{'FileName' = 'count' }
        AutoFilter        = $true
        AutoSize          = $true
        ClearSheet        = $true
        WorkSheetName     = "Assessment Report"
        Style             = $style
    }

    $validationResultsAll | Select-Object DatabaseName, SqlObjectType, FileName, LineNumber, FailedText, Category, Reason, Recommendation | Export-Excel @ExcelParams
    #$validationResultsAll | Select-Object SqlObjectType, FileName, LineNumber, FailedText, Category, Reason, Recommendation | Export-Excel -Path $assessmentReportOutputPath -AutoFilter -AutoSize -ClearSheet -WorksheetName "FullReport" -Style $style;

    $endTime = (Get-Date)
    $ElapsedTime = ($endTime - $startTime).ToString('''Duration: ''mm'' min ''ss'' sec''')

    Write-Log " " $generateLogFileInSameDir $logFileLoc
    Write-Log " " $generateLogFileInSameDir $logFileLoc
    Write-Log "***********************************Assessment Summary ********************************************************" $generateLogFileInSameDir $logFileLoc
    Write-Log "Time Taken: $ElapsedTime" $generateLogFileInSameDir $logFileLoc
    Write-Log "Total Scanned Objects : $totalFiles" $generateLogFileInSameDir $logFileLoc
    Write-Log "Complete Report of Assessment written to : $inventoryOutputFilePath" $generateLogFileInSameDir $logFileLoc
    Write-Log "FailedDBs: $failedDBs" $generateLogFileInSameDir $logFileLoc
    Write-Log "Detailed Logs: $logFileLoc"
    Write-Log "**************************************************************************************************************" $generateLogFileInSameDir $logFileLoc

    <# $totalOccurencesUnsupportedDataTypes = ($unsupportedDataTypesTotal | Measure-Object -Property count -Sum).Sum
if ($totalOccurencesUnsupportedDataTypes -eq $null) {
    $totalOccurencesUnsupportedDataTypes = 0

}
$ProgramFinishTime = Get-Date

Write-Log "Total Files Analyzed:$totalFiles" $generateLogFileInSameDir $logFileLoc
Write-Log "Total Files w/ Unsupported Data Types:$totalFilesUnsupportedDataTypes" $generateLogFileInSameDir $logFileLoc
Write-Log "Total Unsupported Data Types Occurences:$totalOccurencesUnsupportedDataTypes" $generateLogFileInSameDir $logFileLoc

$unsupportedDataTypesReport = $unsupportedDataTypesTotal | Group-Object name | %{
    New-Object PSObject -Property @{
        DataType = $_.Name
        Count = ($_.Group | Measure-Object Count -Sum).Sum
    }
}
$unsupportedDataTypesReport | Format-Table #-Property Name, Count  -HideTableHeaders

Write-Log "Program Start Time:$ProgramStartTime" $generateLogFileInSameDir $logFileLoc
Write-Log "Program Finish Time:$ProgramFinishTime" $generateLogFileInSameDir $logFileLoc
Write-Log "Program Elapsed Time:($ProgramFinishTime-$ProgramStartTime)" $generateLogFileInSameDir $logFileLoc
#>
}
}
else {
if (Test-Path $outputFolder) {
Write-Log "Skipping output folder cleanup as RetryFailedDbsMode not equal to zero in config"
if(Test-Path $dbExtractionStatusPath){
$failedDBList = @(
    $(Get-ChildItem -File -Path $dbExtractionStatusPath | Select -ExpandProperty Name)
)
foreach ($item in $failedDBList) {
    if ($failedDBs -eq "") {
        $failedDBs = $item.Replace(".txt", "")
    }
    else {
        $failedDBs = $failedDBs + "," + $item.Replace(".txt", "")
    }
}
}
}
else{

}
}