SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Select_Forecast_Fund_MonthlyComparision] --'',2,NULL  
(  
  @userAlias NVARCHAR(100)  
    ,@FundId  INT  
    ,@ScenarioId INT --= Null  
)  
  
As  
BEGIN  

  
BEGIN TRY  
  
  
  
DECLARE @BaseLineScenarioID INT = (SELECT ScenarioId FROM [OPGC].[OpgcScenario] WHERE FundID =@FundId AND IsBaseline=1 and Isdeleted = 0)  
  
DECLARE @CurrentDate DATETIME = GETDATE()  
DECLARE @TTMDate DATETIME = DATEADD (MM,-12,@CurrentDate)  
DECLARE @validateCount INT = (SELECT COUNT(*) FROM  [OPGC].[OpgcFundCashFlow] WHERE FundID =@FundId AND ScenarioId = @BaseLineScenarioID and FundCashflowTypeId  in (3,4,5) and Isdeleted = 0)
DECLARE @ComparescenarioName Nvarchar (500) = (SELECT ScenarioName  FROM OPGC.OpgcScenario WHERE ScenarioId = @ScenarioId and Isdeleted = 0)
  
  
If coalesce ( @ScenarioId,'') = ''  and @validateCount > 0
begin  
  
;with BaselineFund as   
(  
select S.FundId , S.ScenarioId , FundCashflowTypeId   
,IIF(ISNULL(sum (ValueAmount),0) = 0,0,cast (( sum (ValueAmount ) /12  ) as decimal (30,2) )) Expense  
      , 0 as Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 --and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =3   
where S.FundId = @FundId  and S.ScenarioId = @BaseLineScenarioID  and S.Isdeleted = 0 and O.FundCashflowTypeId in (3,5) and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
  
union all   
  
select S.FundId , S.ScenarioId , FundCashflowTypeId ,  0 as Expense  
,IIF(ISNULL(sum (ValueAmount),0) = 0,0,cast (( sum (ValueAmount ) /12  ) as decimal (30,2) )) Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 --and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =4   
where S.FundId = @FundId  and S.ScenarioId = @BaseLineScenarioID  and S.Isdeleted = 0 and O.FundCashflowTypeId =4 and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
--and EventDate >  DATEADD( YYYY,-1,GETDATE())  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
)  
  
  
, TotalBaseline as   
(  
  
select A.FundId , A.ScenarioId , max(B.ScenarioName) as ScenarioName ,  sum (A.Expense) as Expense , sum ( A.Fees ) as Fees , sum ( A.Expense + A.Fees ) as Total  
from BaselineFund A  
inner join [OPGC].[OpgcScenario] B  
on A.FundId = B.FundID and A.ScenarioId = B.ScenarioId   
group by A.FundId , A.ScenarioId  
  
)  
  
  
select A.FundId ,   
       A.ScenarioName as BaselineScenario ,  
    NULL as CompareScenario,   
    A.Expense as BaselineAvgMonthlyExpense,  
    A.Fees as BaselineAvgMonthlyFees ,   
    A.Total as BaselineAvgMonthlyTotal,   
    cast ( 0 as decimal(30,2) ) as CompareAvgMonthlyExpense,  
    cast ( 0 as decimal(30,2) ) as CompareAvgMonthlyFees,   
    cast ( 0 as decimal(30,2) ) as CompareAvgMonthlyTotal  
from  TotalBaseline A  
  
end  

If coalesce ( @ScenarioId,'') = ''  and @validateCount = 0
begin 

;with BaselineFund as   
(  
select S.FundId , S.ScenarioId , FundCashflowTypeId   
,0.00 Expense  
      , 0.00 as Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 -- and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =3   
where S.FundId = @FundId  and S.ScenarioId = @BaseLineScenarioID  and S.Isdeleted = 0 --and O.FundCashflowTypeId =3 and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
  
union all   
  
select S.FundId , S.ScenarioId , FundCashflowTypeId ,  0.00 as Expense  
,0.00 Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 --and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =4   
where S.FundId = @FundId  and S.ScenarioId = @BaseLineScenarioID  and S.Isdeleted = 0 --and O.FundCashflowTypeId =4 and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
--and EventDate >  DATEADD( YYYY,-1,GETDATE())  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
)  
  
  
, TotalBaseline as   
(  
  
select A.FundId , A.ScenarioId , max(B.ScenarioName) as ScenarioName ,  sum (A.Expense) as Expense , sum ( A.Fees ) as Fees , sum ( A.Expense + A.Fees ) as Total  
from BaselineFund A  
LEFT join [OPGC].[OpgcScenario] B  
on A.FundId = B.FundID and A.ScenarioId = B.ScenarioId   
group by A.FundId , A.ScenarioId  
  
)

select A.FundId ,   
       A.ScenarioName as BaselineScenario ,  
    NULL as CompareScenario,   
    A.Expense as BaselineAvgMonthlyExpense,  
    A.Fees as BaselineAvgMonthlyFees ,   
    A.Total as BaselineAvgMonthlyTotal,   
    cast ( 0 as decimal(30,2) ) as CompareAvgMonthlyExpense,  
    cast ( 0 as decimal(30,2) ) as CompareAvgMonthlyFees,   
    cast ( 0 as decimal(30,2) ) as CompareAvgMonthlyTotal  
from  TotalBaseline A  
  
end  

  
IF coalesce ( @ScenarioId,'') != ''  AND @validateCount > 0    
BEGIN  
  
;with BaselineFund as   
(  
select S.FundId , S.ScenarioId , FundCashflowTypeId   
,IIF(ISNULL(sum (ValueAmount),0) = 0,0,cast (( sum (ValueAmount ) /12  ) as decimal (30,2) )) Expense  
      , 0 as Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 -- and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =3   
where S.FundId = @FundId  and S.ScenarioId = @BaseLineScenarioID  and S.Isdeleted = 0 and O.FundCashflowTypeId in (3,5) and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
  
union all   
  
select S.FundId , S.ScenarioId , FundCashflowTypeId ,  0 as Expense  
,IIF(ISNULL(sum (ValueAmount),0) = 0,0,cast (( sum (ValueAmount ) /12  ) as decimal (30,2) )) Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 --and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =4   
where S.FundId = @FundId  and S.ScenarioId = @BaseLineScenarioID  and S.Isdeleted = 0 and O.FundCashflowTypeId =4 and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
--and EventDate >  DATEADD( YYYY,-1,GETDATE())  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
)  
  
  
, TotalBaseline as   
(  
  
select A.FundId , A.ScenarioId , max(B.ScenarioName) as ScenarioName ,  sum (A.Expense) as Expense , sum ( A.Fees ) as Fees , sum ( A.Expense + A.Fees ) as Total  
from BaselineFund A  
LEFT join [OPGC].[OpgcScenario] B  
on A.FundId = B.FundID and A.ScenarioId = B.ScenarioId   
group by A.FundId , A.ScenarioId  
  
),  
CompareFund as   
(  
select S.FundId , S.ScenarioId , FundCashflowTypeId   
,IIF(ISNULL(sum (ValueAmount),0) = 0,0,cast (( sum (ValueAmount ) /12  ) as decimal (30,2) )) Expense  
      , 0 as Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 --and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =3   
where S.FundId = @FundId  and S.ScenarioId = @ScenarioId  and S.Isdeleted = 0 and O.FundCashflowTypeId in (3,5) and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
  
union all   
  
select S.FundId , S.ScenarioId , FundCashflowTypeId ,  0 as Expense  
,IIF(ISNULL(sum (ValueAmount),0) = 0,0,cast (( sum (ValueAmount ) /12  ) as decimal (30,2) )) Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 --and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =4   
where S.FundId = @FundId  and S.ScenarioId = @ScenarioId  and S.Isdeleted = 0 and O.FundCashflowTypeId =4 and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
and EventDate >  DATEADD( YYYY,-1,GETDATE())  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
),  
  
TotalCompare as   
(  
  
select A.FundId , A.ScenarioId , max(A.ScenarioName) as ScenarioName ,  sum (B.Expense) as Expense , sum ( B.Fees ) as Fees , sum ( B.Expense + B.Fees ) as Total  
from [OPGC].[OpgcScenario] A  
LEFT join CompareFund B  
on A.FundId = B.FundID and A.ScenarioId = B.ScenarioId   
WHERE A.FundID = @FundId AND A.ScenarioId = @ScenarioId  
group by A.FundId , A.ScenarioId  
  
)  
  
select B.FundId ,   
       B.ScenarioName as BaselineScenario ,  
    ISNULL(C.ScenarioName,@ComparescenarioName) as CompareScenario,   
    isnull(B.Expense,0.00) as BaselineAvgMonthlyExpense,  
    isnull(B.Fees,0.00) as BaselineAvgMonthlyFees ,   
    isnull(B.Total,0.00) as BaselineAvgMonthlyTotal,   
    isnull(C.Expense,0.00) as CompareAvgMonthlyExpense,  
    isnull(C.Fees,0.00) as CompareAvgMonthlyFees,   
    isnull(C.Total,0.00) as CompareAvgMonthlyTotal  
FROM TotalBaseline B  
LEFT JOIN TotalCompare C ON C.FundID = B.FundID  
  
END  
  
IF coalesce ( @ScenarioId,'') != ''  AND @validateCount = 0    
BEGIN    
;with BaselineFund as   
(  
select S.FundId , S.ScenarioId , FundCashflowTypeId   
,0.00 Expense  
      , 0.00 as Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 -- and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =3   
where S.FundId = @FundId  and S.ScenarioId = @BaseLineScenarioID  and S.Isdeleted = 0 --and O.FundCashflowTypeId =3 and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
  
union all   
  
select S.FundId , S.ScenarioId , FundCashflowTypeId ,  0.00 as Expense  
,0.00 Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 --and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =4   
where S.FundId = @FundId  and S.ScenarioId = @BaseLineScenarioID  and S.Isdeleted = 0 --and O.FundCashflowTypeId =4 and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
--and EventDate >  DATEADD( YYYY,-1,GETDATE())  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
)  
  
  
, TotalBaseline as   
(  
  
select A.FundId , A.ScenarioId , max(B.ScenarioName) as ScenarioName ,  sum (A.Expense) as Expense , sum ( A.Fees ) as Fees , sum ( A.Expense + A.Fees ) as Total  
from BaselineFund A  
LEFT join [OPGC].[OpgcScenario] B  
on A.FundId = B.FundID and A.ScenarioId = B.ScenarioId   
group by A.FundId , A.ScenarioId  
  
),  
CompareFund as   
(  
select S.FundId , S.ScenarioId , FundCashflowTypeId   
,IIF(ISNULL(sum (ValueAmount),0) = 0,0,cast (( sum (ValueAmount ) /12  ) as decimal (30,2) )) Expense  
      , 0 as Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 --and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =3   
where S.FundId = @FundId  and S.ScenarioId = @ScenarioId  and S.Isdeleted = 0 and O.FundCashflowTypeId in (3,5) and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
  
union all   
  
select S.FundId , S.ScenarioId , FundCashflowTypeId ,  0 as Expense  
,IIF(ISNULL(sum (ValueAmount),0) = 0,0,cast (( sum (ValueAmount ) /12  ) as decimal (18,2) )) Fees  
from OPGC.OpgcScenario S  
LEFT JOIN  [OPGC].[OpgcFundCashFlow] O ON O.FundId = S.FundID AND O.ScenarioId = S.ScenarioId AND O.Isdeleted = 0 --and EventDate >  DATEADD( YYYY,-1,GETDATE()) and FundCashflowTypeId =4   
where S.FundId = @FundId  and S.ScenarioId = @ScenarioId  and S.Isdeleted = 0 and O.FundCashflowTypeId =4 and O.EventDate BETWEEN CAST (@TTMDate AS DATE) and CAST (@CurrentDate AS DATE)  
and EventDate >  DATEADD( YYYY,-1,GETDATE())  
group by S.FundId , S.ScenarioId , O.FundCashflowTypeId  
),  
  
TotalCompare as   
(  
  
select A.FundId , A.ScenarioId , max(A.ScenarioName) as ScenarioName ,  sum (B.Expense) as Expense , sum ( B.Fees ) as Fees , sum ( B.Expense + B.Fees ) as Total  
from [OPGC].[OpgcScenario] A  
LEFT join CompareFund B  
on A.FundId = B.FundID and A.ScenarioId = B.ScenarioId   
WHERE A.FundID = @FundId AND A.ScenarioId = @ScenarioId  
group by A.FundId , A.ScenarioId  
  
)  

select B.FundId ,   
       B.ScenarioName as BaselineScenario ,  
    ISNULL(C.ScenarioName, @ComparescenarioName) as CompareScenario,   
    isnull(B.Expense,0.00) as BaselineAvgMonthlyExpense,  
    isnull(B.Fees,0.00) as BaselineAvgMonthlyFees ,   
    isnull(B.Total,0.00) as BaselineAvgMonthlyTotal,   
    isnull(C.Expense,0.00) as CompareAvgMonthlyExpense,  
    isnull(C.Fees,0.00) as CompareAvgMonthlyFees,   
    isnull(C.Total,0.00) as CompareAvgMonthlyTotal  
FROM TotalBaseline B  
LEFT JOIN TotalCompare C ON C.FundID = B.FundID  

END  
  
  
  
END TRY  
BEGIN CATCH  
 DECLARE @ErrorNumber INT  
 DECLARE @Severity  INT  
 DECLARE @State   INT   
 DECLARE @Procedure  NVARCHAR(250)  
 DECLARE @LineNumber  INT  
 DECLARE @Message  NVARCHAR(MAX)  
 DECLARE @Originator NVARCHAR(250)   
 SELECT   
  @ErrorNumber = ERROR_NUMBER(),  
  @Severity = ERROR_SEVERITY(),  
  @State = ERROR_STATE(),   
  @Procedure = ERROR_PROCEDURE(),  
  @LineNumber = ERROR_LINE(),   
  @Message = ERROR_MESSAGE()     
 EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message,   
       'Database', null, null,null    RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages            
END CATCH  
END  
  
