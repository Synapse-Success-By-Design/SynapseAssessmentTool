CREATE TYPE [OPGC].[GIRRTablev1] AS TABLE(
	[PAmount] [decimal](18, 2) NOT NULL,
	[PDate] [date] NOT NULL
)
