CREATE TYPE [OPGC].[GIRRTable] AS TABLE(
	[Value] [decimal](29, 9) NOT NULL,
	[Date] [datetime] NOT NULL
)
