SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [OPGC].[USP_Update_Forecast_EditInvestment]  --'raghul','SQA_CTS',4,'HealthCare Clinic Japan','xyz',1
(
	  @userAlias NVARCHAR(250)
	 ,@InvestmentName NVARCHAR(250)
	 ,@InvestmentId INT,
	  --,@IndustryId INT,
	  @IndustryName Nvarchar(100),
	  @Address NVARCHAR(700),
	  @LocationId INT
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

BEGIN TRY

DECLARE @ErrorText NVARCHAR(MAX) =''

DECLARE @IfInvestmentNameExist INT = (SELECT COUNT(*) FROM [OPGC].[OpgcInvestment] WHERE InvestmentName =@InvestmentName and Isdeleted = 0 )

DECLARE @CurrentInvestmentName NVARCHAR(200) =(SELECT InvestmentName FROM [OPGC].[OpgcInvestment] WHERE InvestmentId =@InvestmentId and Isdeleted = 0 )

declare @IndsutryIdExist int =  (select count([IndustryId​]) from [OPGC].[OpgcIndustry] where [IndustryName​] = case when @IndustryName is null then 'Not Available' else @IndustryName End and Isdeleted = 0 )


IF @IfInvestmentNameExist >0 and @CurrentInvestmentName != @InvestmentName
BEGIN
SET @ErrorText = 'Investment Name Already Exists'
RAISERROR (@ErrorText, 16, 1)
END

else
begin

If @IndsutryIdExist = 0
begin

insert into [OPGC].[OpgcIndustry] ([IndustryName​],[CreatedBy​],[CreatedOn​])
select 
@IndustryName,
@userAlias,
getdate()

declare @IndsutryIdresult int = (select [IndustryId​] from [OPGC].[OpgcIndustry] where [IndustryName​] = @IndustryName and Isdeleted = 0)

UPDATE [OPGC].[OpgcInvestment]
SET InvestmentName = @InvestmentName
   ,[Address] = @Address
   ,CountryId = case when @LocationId is null then 1001 else @LocationId end
   ,IndustryId = @IndsutryIdresult
   ,ModifiedBy = @userAlias
   ,ModifiedOn = getdate()
where InvestmentId = @InvestmentId and Isdeleted = 0

end

else

begin

declare @IndsutryIdresultExist int = (select [IndustryId​] from [OPGC].[OpgcIndustry] where [IndustryName​] =  case when @IndustryName is null then 'Not Available' else @IndustryName End and Isdeleted = 0 )

UPDATE [OPGC].[OpgcInvestment]
SET InvestmentName = @InvestmentName
   ,[Address] = @Address
   ,CountryId = case when @LocationId is null then 1001 else @LocationId end
   ,IndustryId = @IndsutryIdresultExist
   ,ModifiedBy = @userAlias
   ,ModifiedOn = getdate()
where InvestmentId = @InvestmentId and Isdeleted = 0

end


end

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END        
END CATCH
END


