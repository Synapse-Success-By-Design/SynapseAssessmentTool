SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [OPGC].[USP_Select_Forecast_Fund_CommittedandAvailableCapital] --'',2 ,25
(
	 @userAlias NVARCHAR(100)
    ,@FundId  INT
    ,@ScenarioId INT 
)

As
BEGIN
--======================================================= 
 --Author         :    <AEGIS Team>    
 --Create Date    :    18/03/2021 
 --Description    :   Select the Get Appointment Details
--=========================================================== 
 --History                  
 --Author         :         Date         Description 

--============================================================ 

/*************************************************************************
Purpose
      Display the Appointment Details


Uses   
      [USP_Select_Appointment_GetAppointmentDetails]	    SP

Populates
      [WWMG].[ConfirmedScheduleDetails]			Table
	  [WWMG].[LocationDetails]					Table
	  [WWMG].[UserFamilyDetails]				Table
	  [WWMG].[FamilyDetails_Relations]			Table
**************************************************************************/
BEGIN TRY

select  FundId , ScenarioId ,  CommittedCapital , ManagementFeePercent ,  LPPreferredReturnPercent , GPPreferredReturnPercent , LPFinalSharePercent,
        case when ManualStepdownDate is not null then ManualStepdownDate else DATEADD(yy,5,FundInceptionDate) end as ManualStepdownDate

from [OPGC].[OpgcScenario] where FundID = @FundId and ScenarioId = @ScenarioId and Isdeleted = 0

------------------------------------------------------------------------

--with CapitalValue as
--(
--select FundId , ScenarioId , FundCashflowTypeId , sum (Valueamount) as CommitedCapital  , 0.00 as AvailableCapital
--from [OPGC].[OpgcFundCashFlow] 
--where FundId = @FundId  and ScenarioId = @ScenarioId and FundCashflowTypeId =1 and Isdeleted = 0
--group by FundId , ScenarioId , FundCashflowTypeId
--union all
--select FundId , ScenarioId , FundCashflowTypeId   ,0.00 as CommitedCapital,sum (Valueamount) as AvailableCapital  
--from [OPGC].[OpgcFundCashFlow]
--where FundId = @FundId  and ScenarioId = @ScenarioId and FundCashflowTypeId =2  and Isdeleted = 0
--group by FundId , ScenarioId , FundCashflowTypeId
--)

--select  FundId , ScenarioId , Sum(CommitedCapital) as CommitedCapital , Sum(AvailableCapital) as AvailableCapital
--from CapitalValue
--group by FundId , ScenarioId 


--With CommitedCapital as
--(
--select FundId , ScenarioId , FundCashflowTypeId , sum (Valueamount) as CommitedCapital  
--from [OPGC].[OpgcFundCashFlow] 
--where FundId = @FundId  and ScenarioId = @ScenarioId and FundCashflowTypeId =1 and Isdeleted = 0
--group by FundId , ScenarioId , FundCashflowTypeId
--)
--, AvailableCapital as
--(
--select FundId , ScenarioId , FundCashflowTypeId   ,sum (Valueamount) as AvailableCapital  
--from [OPGC].[OpgcFundCashFlow]
--where FundId = 2  and ScenarioId = 1534 and FundCashflowTypeId =2  and Isdeleted = 0
--group by FundId , ScenarioId , FundCashflowTypeId
--)

--select A.FundId ,
--       A.ScenarioId ,
--	   isnull(A.CommitedCapital,0.00) as CommitedCapital  , 
--	   isnull(B.AvailableCapital,0.00) as AvailableCapital
--from CommitedCapital A
--Left join AvailableCapital B
--on A.FundId = B.FundId and A.ScenarioId = B.ScenarioId


END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
	RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages          
END CATCH
END

