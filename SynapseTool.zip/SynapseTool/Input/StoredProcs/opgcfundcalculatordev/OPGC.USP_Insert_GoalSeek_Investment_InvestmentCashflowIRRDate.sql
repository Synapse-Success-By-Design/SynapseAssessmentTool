SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE  PROCEDURE [OPGC].[USP_Insert_GoalSeek_Investment_InvestmentCashflowIRRDate] --'',1415
(  

@UserAlias      nvarchar(250),
@GSInvestmentId int
)

as

Begin


BEGIN TRY


DECLARE @ErrorText NVARCHAR(MAX) =''

declare @fundid int = ( select FundId from [OPGC].[OpgcGoalSeekInvestmentcashflowType]  where GsInvestmentId = @GSInvestmentId and Isdeleted = 0)

Declare @ExitValueCheck date = ( select ExitDate from [OPGC].[OpgcGoalSeekInvestmentcashflowType]  where  GsInvestmentId = @GSInvestmentId and Isdeleted = 0)

declare @CalcIRR decimal(30,2) = ( select CalcIRR  from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where GsInvestmentId = @GSInvestmentId and Isdeleted = 0 ) 

declare @InvesmentId int = ( select InvestmentId  from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where GsInvestmentId = @GSInvestmentId and Isdeleted = 0 )

declare @ScenarioId int = ( select ScenarioId  from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where GsInvestmentId = @GSInvestmentId and Isdeleted = 0 )

declare @ExitDate date = ( select ExitDate  from [OPGC].[OpgcGoalSeekInvestmentcashflowType] where GsInvestmentId = @GSInvestmentId and Isdeleted = 0 )

declare @InitialDate date = ( select EventDate  from [OPGC].[OpgcInvestmentCashFlow] where FundId = @fundid and ScenarioId = @ScenarioId and InvestmentId = @InvesmentId and InvestmentCashflowTypeId = 1 and Isdeleted = 0 )



If @ExitValueCheck is null 
begin
--SET @ErrorText = 'Unable to Calculate Exit Date.  Please change Target Fund Gross IRR or Exit Value'
SET @ErrorText = 'Exit date before initial investment date. Please change Target Fund Gros IRR or Exit Value'
RAISERROR (@ErrorText, 16, 1)

end

If @CalcIRR  is not  Null
begin
--SET @ErrorText = 'Calculated Exit Value is 0. There is a mismatch between Target IRR and Calculated Fund Gross IRR'
SET @ErrorText = 'The Overall Fund Gross IRR value is not matching with Target Fund Gross IRR . Please change Target Fund Gross IRR or Exit Value'
RAISERROR (@ErrorText, 16, 1)
end

 if @InitialDate > @ExitDate 
begin
SET @ErrorText = 'Date is less than Initial Invesment Date , Please change Date'
RAISERROR (@ErrorText, 16, 1)
end 


else
begin

insert into  [OPGC].[OpgcInvestmentCashFlow] 
(
 FundId
,ScenarioId
,InvestmentCashflowTypeId
,InvestmentId
,Equity
,EventDate
,IsActual
,IsHypothetical
,RecallableUntil
,Tag
,Isdeleted
,CreatedBy
,CreatedOn

)

select 
 FundId
,ScenarioId
,InvestmentcashflowtypeId
,InvestmentId
,Exitvalue
,ExitDate
,0
,1
,NULL
,NULL
,0
,@UserAlias
,GETDATE()
from [OPGC].[OpgcGoalSeekInvestmentcashflowType] 
where GsInvestmentId = @GSInvestmentId


update [OPGC].[OpgcGoalSeekInvestmentcashflowType]
set IsApplied = 1
where GsInvestmentId = @GSInvestmentId

end



-------------------------------------------------------------update fot OPGC.OPGCFund Table with Baselinescenario investmnents------------------------------------------------------------
DECLARE @BaselineScenarioid INT 
SET @BaselineScenarioid = (SELECT ScenarioId from OPGC.OpgcScenario WHERE FundID = @fundid AND IsBaseline = 1 and Isdeleted = 0)
DECLARE @Investment Decimal (30,2) = (SELECT SUM(Equity) FROM OPGC.OpgcInvestmentCashFlow WHERE Fundid = @fundid and ScenarioId = @BaselineScenarioid and InvestmentCashflowTypeId in (1,2) and Isdeleted = 0)
DECLARE @totalInvestment Decimal (30,2), @realizedinvestment Decimal (30,2), @Unrealizedinvestment Decimal (30,2)
;with Investment as  
(  
select FundId , ScenarioId , InvestmentId  , sum(Equity) as InitialInvestment , 0 as ExitValue   
  from [OPGC].[OpgcInvestmentCashFlow]   
  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
  group by FundId , ScenarioId , InvestmentId   
  union all   
  select FundId , ScenarioId , InvestmentId  , 0 as IntialInvestment , sum(Equity) as ExitValue     
  from [OPGC].[OpgcInvestmentCashFlow]   
  where InvestmentCashflowTypeId in (3,5,7) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
  group by FundId , ScenarioId , InvestmentId   
  )  
, TotalIvestment as  
(  
  select FundId , ScenarioId , InvestmentId  , sum( InitialInvestment) as Investment , sum (ExitValue)  as ExitVAlue   
  from Investment A  
   group by FundId , ScenarioId , InvestmentId   
),
Realizedvalidation as(
SELECT FundId , ScenarioId , InvestmentId  ,  Investment ,  ExitVAlue ,
CASE WHEN ExitVAlue > Investment THEN 1 ELSE 0 END AS IsRealized
FROM TotalIvestment
),
------------------Investmet by Eventdate-----------------------------
Investmentbyeventdate AS (
select FundId , ScenarioId , InvestmentId  , CAST(EventDate AS DATE) EventDate,sum(Equity) as InitialInvestment , 0 as ExitValue   
  from [OPGC].[OpgcInvestmentCashFlow]   
  where InvestmentCashflowTypeId in (1,2,4,6) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
  group by FundId , ScenarioId , InvestmentId ,CAST(EventDate AS DATE)  
  union all   
  select FundId , ScenarioId , InvestmentId  , CAST(EventDate AS DATE) EventDate,0 as IntialInvestment , sum(Equity) as ExitValue     
  from [OPGC].[OpgcInvestmentCashFlow]   
  where InvestmentCashflowTypeId in (3,5,7) and FundId = @fundId and ScenarioId = @BaselineScenarioid and Isdeleted=0  
  group by FundId , ScenarioId , InvestmentId,CAST(EventDate AS DATE)
  ),
  TotalInvestmentbyeventdate AS (
  select FundId , ScenarioId , InvestmentId  ,  EventDate,sum(InitialInvestment) as Investment ,  SUM(ExitValue) ExitValue
  FROM Investmentbyeventdate
  GROUP BY FundId , ScenarioId , InvestmentId  ,  EventDate
  ),
  Categorization as (
  SELECT T.FundId , T.ScenarioId , T.InvestmentId  ,  T.EventDate,
  CASE WHEN R.IsRealized = 1 THEN T.Investment *-1 ELSE 0 End AS Realizedinvestment,
  CASE WHEN R.IsRealized = 0 THEN T.Investment *-1 ELSE 0 End AS UnRealizedinvestment,
  CASE WHEN R.IsRealized = 1 THEN T.ExitValue  ELSE 0 End AS RealizedExitValue,
  CASE WHEN R.IsRealized = 0 THEN T.ExitValue  ELSE 0 End AS UnRealizedExitValue
  FROM TotalInvestmentbyeventdate T
  INNER JOIN Realizedvalidation R On T.FundId = R.FundId and  T.ScenarioId  = R.ScenarioId and  T.InvestmentId =  R.InvestmentId
  ),FinalResul As(
  SELECT FundId,SUM(Realizedinvestment)*-1 Realizedinvestment, SUM(UnRealizedinvestment)*-1 UnRealizedinvestment , Sum(Realizedinvestment+UnRealizedinvestment)*-1 as TotalInvestment
		FROM Categorization
		GROUP BY FundId
		)
		SELECT @totalInvestment = TotalInvestment,
			   @realizedinvestment = Realizedinvestment,
			   @Unrealizedinvestment = UnRealizedinvestment
			   FROM FinalResul

If (Select count(InvestmentCashflowTypeId) FROM OPGC.OpgcInvestmentCashFlow WHERE fundId = @fundid and ScenarioId = @BaselineScenarioid and InvestmentCashflowTypeId = 3 AND Isdeleted = 0) >=1
BEGIN

UPDATE OPGC.OpgcFund
SET [TotalInvestment​] = IIF(COALESCE([TotalInvestment​],0.00) = 0.00,@totalInvestment,[TotalInvestment​]),
	[TotalRealized​] = IIF(COALESCE([TotalRealized​],0.00) = 0.00,@realizedinvestment,[TotalRealized​]),
	[TotalUnrealized​] = IIF(COALESCE([TotalUnrealized​],0.00) = 0.00,@Unrealizedinvestment,[TotalUnrealized​])
	WHERE Fundid = @fundid


END 


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  

END TRY
BEGIN CATCH
	DECLARE @ErrorNumber INT
	DECLARE @Severity  INT
	DECLARE @State   INT 
	DECLARE @Procedure  NVARCHAR(250)
	DECLARE @LineNumber  INT
	DECLARE @Message  NVARCHAR(MAX)
	DECLARE @Originator NVARCHAR(250)	
	SELECT 
		@ErrorNumber = ERROR_NUMBER(),
		@Severity = ERROR_SEVERITY(),
		@State = ERROR_STATE(), 
		@Procedure = ERROR_PROCEDURE(),
		@LineNumber = ERROR_LINE(), 
		@Message = ERROR_MESSAGE()   
	EXEC [OPGC].[USP_OPGC_Insert_ErrorLog] @ErrorNumber, @Severity, @State,@Procedure, @LineNumber, @Message, 
							'Database', null, null,null		
IF @ErrorText <> ''
BEGIN
RAISERROR (@ErrorText, 16, 1)
END
ELSE
BEGIN
RAISERROR ('Sorry an error occured', 16, 1) --Error Handling Messages
END   
END CATCH
END
